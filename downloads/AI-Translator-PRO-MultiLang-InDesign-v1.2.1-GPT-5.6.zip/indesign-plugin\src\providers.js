(function () {
  const DEFAULT_MODELS = {
    openai: ["gpt-5.6-sol", "gpt-5.6-terra", "gpt-5.6-luna"],
    anthropic: ["claude-opus-4-8", "claude-sonnet-4-6", "claude-haiku-4-5"],
    gemini: ["gemini-2.5-pro", "gemini-2.5-flash", "gemini-2.0-flash"],
    mock: ["mock-echo"]
  };

  const MODEL_LABELS = {
    "gpt-5.6-sol": "GPT-5.6 Sol - Highest quality",
    "gpt-5.6-terra": "GPT-5.6 Terra - Balanced",
    "gpt-5.6-luna": "GPT-5.6 Luna - Fastest"
  };

  const OPENAI_MODEL_MIGRATIONS = {
    "gpt-5.6": "gpt-5.6-sol",
    "gpt-5.5": "gpt-5.6-sol",
    "gpt-5.4": "gpt-5.6-sol",
    "gpt-5-mini": "gpt-5.6-terra",
    "gpt-5.4-mini": "gpt-5.6-terra",
    "gpt-4.1": "gpt-5.6-terra",
    "gpt-4.1-mini": "gpt-5.6-terra",
    "gpt-4o": "gpt-5.6-terra",
    "gpt-4o-mini": "gpt-5.6-terra"
  };

  function getDefaultModel(provider) {
    return (DEFAULT_MODELS[provider] || DEFAULT_MODELS.openai)[0];
  }

  function normalizeModel(provider, model) {
    const requested = String(model || "").trim();
    if (provider === "openai" && OPENAI_MODEL_MIGRATIONS[requested]) {
      return OPENAI_MODEL_MIGRATIONS[requested];
    }
    return requested || getDefaultModel(provider);
  }

  function getModelLabel(provider, model) {
    return provider === "openai" && MODEL_LABELS[model] ? MODEL_LABELS[model] : model;
  }

  async function translateBatch(providerName, input) {
    const provider = createProvider(providerName);
    return await provider.translateBatch(input);
  }

  function createProvider(providerName) {
    if (providerName === "anthropic") return new AnthropicProvider();
    if (providerName === "gemini") return new GeminiProvider();
    if (providerName === "mock") return new MockProvider();
    return new OpenAIProvider();
  }

  function buildSystemPrompt(input) {
    const glossaryLines = window.AIT_Glossary.toPromptLines(input.glossary || []);
    const quality = input.qualityMode || "layout-tight";
    const layoutRule = quality === "premium"
      ? "Use high-quality professional localization. Keep meaning complete, tone natural, terminology consistent, and layout length controlled."
      : quality === "balanced"
        ? "Balance accuracy, natural target-language flow, and compact layout length."
        : "Layout is fixed in Adobe InDesign. Keep the translation compact and close to the source length wherever possible without losing meaning — but compactness must never produce broken grammar, truncated sentences, or telegraphic style. A slightly longer, correct sentence always beats a shorter, broken one.";

    return [
      "You are a senior professional translator producing print-ready copy inside Adobe InDesign documents.",
      "Translate every supplied unit into the target language only.",
      "QUALITY BAR: the translation must read as if it was originally written by an educated native speaker of the target language — flawless grammar, natural word order, idiomatic phrasing, and a register, tone, and terminology that stay consistent across every unit of the document.",
      "Each translated unit must be a complete, grammatical rendering of its entire source unit, from the first word to the last. Never output a sentence fragment. Never drop, abbreviate, or cut words at the start or end of a unit.",
      "Mirror the capitalization style of each source unit: ALL CAPS stays ALL CAPS, Title Case maps to the target language's natural equivalent for headings, sentence case stays sentence case following the target language's own capitalization rules (e.g. German noun capitalization, French accent rules).",
      "Use correct target-language punctuation and typographic conventions (quotation marks, decimal separators, spacing before punctuation where the language requires it).",
      "Never sacrifice grammatical correctness or natural phrasing for brevity.",
      "These units are paragraphs from one continuous document (headings, body copy, bullet list items). Translate each so it reads coherently in that role: headings like headings, bullets like parallel bullets with consistent grammatical form.",
      "Return valid JSON only. No markdown, no comments, no explanations, no surrounding text.",
      "The returned JSON must contain exactly one translated text for every input id.",
      "Never merge units, split units, drop units, duplicate source text, or leave source language attached before/after the translation.",
      "Do not copy the source text unless it is a brand name, product code, URL, email, unit, placeholder, or a term the glossary says to keep.",
      "Preserve IDs exactly. Preserve placeholders like [[[AIT_PH_0000]]] exactly.",
      "Preserve XML-like style tags such as <r id=\"0\">...</r> exactly if they appear, and translate only the human text inside them.",
      "Preserve manual line breaks, bullet/numbering intent, units, product codes, URLs, emails, variables, and bracketed tokens.",
      "Use the user context and glossary as mandatory terminology guidance when terms appear.",
      layoutRule,
      `Industry/tone: ${input.industry || "General business"}.`,
      input.context ? `Client/project context: ${input.context}` : "",
      glossaryLines ? `Glossary, mandatory when terms appear:\n${glossaryLines}` : ""
    ].filter(Boolean).join("\n");
  }

  function buildUserPrompt(input) {
    return JSON.stringify({
      task: "translate_indesign_units",
      source_language: input.sourceLanguageName || input.sourceLang || "auto detect",
      target_language: `${input.targetLanguage.name} (${input.targetLanguage.code})`,
      contract: {
        return_json_only: true,
        required_shape: { translations: [{ id: "same id as input", text: "target language translation only" }] },
        must_return_all_ids: true,
        preserve_placeholders_exactly: true,
        no_source_language_duplicates: true
      },
      units: input.units.map(u => ({ id: u.id, text: u.preparedText }))
    });
  }

  function parseTranslations(raw, expectedIds) {
    const text = window.AIT_Protectors.stripFences(raw);
    let parsed;
    try { parsed = JSON.parse(text); }
    catch (err) {
      const first = text.indexOf("{");
      const last = text.lastIndexOf("}");
      if (first >= 0 && last > first) parsed = JSON.parse(text.slice(first, last + 1));
      else throw new Error("Provider did not return valid JSON.");
    }
    const arr = Array.isArray(parsed) ? parsed : parsed.translations;
    if (!Array.isArray(arr)) throw new Error("Provider JSON missing translations array.");
    const map = {};
    for (const item of arr) {
      if (!item || typeof item.id === "undefined") continue;
      map[String(item.id)] = typeof item.text === "string" ? item.text : String(item.text || "");
    }
    const missing = expectedIds.filter(id => !(id in map));
    if (missing.length) throw new Error(`Provider JSON missing translated unit IDs: ${missing.slice(0, 8).join(", ")}${missing.length > 8 ? "..." : ""}`);
    return map;
  }

  function extractOpenAIText(data) {
    if (typeof data.output_text === "string") return data.output_text;
    const chunks = [];
    for (const item of data.output || []) {
      for (const part of item.content || []) {
        if ((part.type === "output_text" || part.type === "text") && part.text) chunks.push(part.text);
      }
    }
    return chunks.join("\n");
  }

  async function fetchWithRetry(url, options, retries, label) {
    let lastError;
    for (let attempt = 0; attempt <= retries; attempt++) {
      try {
        const res = await fetch(url, options);
        if (res.ok) return res;
        const body = await res.text().catch(() => "");
        const retryable = [408, 409, 425, 429, 500, 502, 503, 504].includes(res.status);
        const err = new Error(`${label} request failed (${res.status}): ${body.slice(0, 1000)}`);
        if (!retryable || attempt === retries) throw err;
        lastError = err;
      } catch (err) {
        lastError = err;
        if (attempt === retries) throw err;
      }
      const wait = Math.min(16000, 900 * Math.pow(2, attempt)) + Math.round(Math.random() * 400);
      await sleep(wait);
    }
    throw lastError;
  }

  function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

  class OpenAIProvider {
    async translateBatch(input) {
      if (!input.apiKey) throw new Error("Missing OpenAI API key.");
      const system = buildSystemPrompt(input);
      const user = buildUserPrompt(input);
      const model = normalizeModel("openai", input.model || getDefaultModel("openai"));
      const payload = {
        model,
        input: [
          { role: "system", content: [{ type: "input_text", text: system }] },
          { role: "user", content: [{ type: "input_text", text: user }] }
        ],
        max_output_tokens: Math.min(14000, Math.max(2048, Math.round(input.units.reduce((s, u) => s + String(u.preparedText || "").length, 0) * 2.2)))
      };
      // The previous default (GPT-4.1) was non-reasoning. GPT-5.6 defaults to
      // medium, so preserve the translation plugin's latency/cost baseline.
      if (/^gpt-5\.6(?:-|$)/i.test(model)) payload.reasoning = { effort: "none" };
      else if (/^gpt-4/i.test(model)) payload.temperature = 0.1;

      // If the API still rejects a parameter for this model, strip it and retry.
      for (let attempt = 0; attempt < 4; attempt++) {
        try {
          const res = await fetchWithRetry("https://api.openai.com/v1/responses", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${input.apiKey}`
            },
            body: JSON.stringify(payload)
          }, 5, "OpenAI");
          const data = await res.json();
          return parseTranslations(extractOpenAIText(data), input.units.map(u => u.id));
        } catch (err) {
          const unsupported = /Unsupported parameter: '([^']+)'/.exec(err && err.message ? err.message : "");
          if (unsupported && Object.prototype.hasOwnProperty.call(payload, unsupported[1])) {
            delete payload[unsupported[1]];
            continue;
          }
          throw err;
        }
      }
      throw new Error("OpenAI request failed: could not find a parameter set this model accepts.");
    }
  }

  class AnthropicProvider {
    async translateBatch(input) {
      if (!input.apiKey) throw new Error("Missing Anthropic API key.");
      // No temperature: sampling parameters are removed on claude-opus-4-7+ (400 if sent).
      const payload = {
        model: input.model || getDefaultModel("anthropic"),
        max_tokens: Math.min(14000, Math.max(2048, Math.round(input.units.reduce((s, u) => s + String(u.preparedText || "").length, 0) * 2.2))),
        system: buildSystemPrompt(input),
        messages: [{ role: "user", content: buildUserPrompt(input) }]
      };
      const res = await fetchWithRetry("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": input.apiKey,
          "anthropic-version": "2023-06-01"
        },
        body: JSON.stringify(payload)
      }, 5, "Anthropic");
      const data = await res.json();
      const raw = (data.content || []).map(p => p.text || "").join("\n");
      return parseTranslations(raw, input.units.map(u => u.id));
    }
  }

  class GeminiProvider {
    async translateBatch(input) {
      if (!input.apiKey) throw new Error("Missing Gemini API key.");
      const model = encodeURIComponent(input.model || getDefaultModel("gemini"));
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;
      const payload = {
        systemInstruction: { parts: [{ text: buildSystemPrompt(input) }] },
        contents: [{ role: "user", parts: [{ text: buildUserPrompt(input) }] }],
        generationConfig: { responseMimeType: "application/json", temperature: 0.1 }
      };
      const res = await fetchWithRetry(url, {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-goog-api-key": input.apiKey },
        body: JSON.stringify(payload)
      }, 5, "Gemini");
      const data = await res.json();
      const raw = (data.candidates || []).flatMap(c => (c.content && c.content.parts) || []).map(p => p.text || "").join("\n");
      return parseTranslations(raw, input.units.map(u => u.id));
    }
  }

  class MockProvider {
    async translateBatch(input) {
      await sleep(120);
      const map = {};
      for (const unit of input.units) {
        map[unit.id] = `[${input.targetLanguage.name}] ${unit.preparedText}`;
      }
      return map;
    }
  }

  function estimateCost(units, selectedLanguages) {
    const chars = units.reduce((sum, unit) => sum + String(unit.originalText || "").length, 0);
    const approxTokensPerLanguage = Math.ceil(chars / 3.6);
    const totalApproxTokens = approxTokensPerLanguage * Math.max(1, selectedLanguages.length);
    return { chars, approxTokensPerLanguage, totalApproxTokens };
  }

  window.AIT_Providers = {
    DEFAULT_MODELS,
    getDefaultModel,
    normalizeModel,
    getModelLabel,
    translateBatch,
    estimateCost,
    buildSystemPrompt
  };
})();
