const fs = require('fs');
const path = require('path');
const child_process = require('child_process');

const root = path.resolve(__dirname, '..');
const version = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8')).version;
const out = path.resolve(root, '..', `ai-translator-pro-multilang-v${version}-gpt-5.6.zip`);
try { fs.rmSync(out, { force: true }); } catch (_) {}

if (process.platform === 'win32') {
  const ps = [
    '-NoProfile',
    '-Command',
    `Compress-Archive -Path '${root}' -DestinationPath '${out}' -Force`
  ];
  child_process.execFileSync('powershell.exe', ps, { stdio: 'inherit' });
} else {
  child_process.execFileSync('zip', ['-r', out, path.basename(root), '-x', '*.DS_Store'], { cwd: path.dirname(root), stdio: 'inherit' });
}
console.log(`Created ${out}`);
