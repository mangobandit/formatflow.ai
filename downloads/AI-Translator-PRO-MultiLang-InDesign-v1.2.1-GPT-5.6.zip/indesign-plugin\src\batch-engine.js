(function () {
  const DEFAULT_CHUNK_CHARS = 3200;

  function makeChunks(units, maxChars) {
    const chunks = [];
    let current = [];
    let chars = 0;
    for (const unit of units) {
      const len = String(unit.preparedText || "").length;
      if (current.length && chars + len > maxChars) {
        chunks.push(current);
        current = [];
        chars = 0;
      }
      current.push(unit);
      chars += len;
    }
    if (current.length) chunks.push(current);
    return chunks;
  }

  // Document-level integrity gate, run on the complete translation map before a
  // single character is written. `repairable` units get re-sent once; if any
  // remain incomplete the language is aborted (nothing is saved).
  function validateTranslationMap(units, map) {
    const repairable = [];
    const warnings = [];
    for (const unit of units) {
      const t = map[unit.id];
      const source = String(unit.textForTranslation || "");
      if (typeof t !== "string" || (!t.trim() && source.trim())) {
        repairable.push(unit);
        continue;
      }
      const sFirst = source.replace(/^\s+/, "").charAt(0);
      const tFirst = t.replace(/^\s+/, "").charAt(0);
      // Cased scripts only by construction: uppercase source start + lowercase
      // translation start is the signature of a clipped first word.
      if (sFirst && tFirst && sFirst.toLowerCase() !== sFirst && tFirst.toUpperCase() !== tFirst) {
        warnings.push(`${unit.id}: translation starts lowercase while source starts uppercase — possible clipped first word.`);
      }
      if (source.length > 60 && t.trim().length < source.length * 0.25) {
        warnings.push(`${unit.id}: translation suspiciously short compared to source.`);
      }
    }
    return { repairable, warnings };
  }

  function validateAfterTranslation(chunk, map) {
    const warnings = [];
    for (const unit of chunk) {
      const translated = map[unit.id] || "";
      if (unit.mode === "tagged-runs") {
        const parsed = window.AIT_Protectors.parseTaggedRuns(translated);
        if (parsed.length !== unit.runs.length) {
          warnings.push(`${unit.id}: style-run tag count changed (${parsed.length}/${unit.runs.length}); using paragraph fallback where needed.`);
        }
        parsed.forEach(item => {
          const run = unit.runs[item.index];
          if (!run) return;
          const check = window.AIT_Protectors.validatePlaceholders(item.text, run.placeholders);
          if (!check.ok) warnings.push(`${unit.id}: placeholder missing in style run ${item.index}.`);
        });
      } else {
        const check = window.AIT_Protectors.validatePlaceholders(translated, unit.placeholders);
        if (!check.ok) warnings.push(`${unit.id}: placeholder missing.`);
      }
    }
    return warnings;
  }

  function makeReport(settings, docName) {
    return {
      app: "AI Translator PRO MultiLang",
      version: "1.2.1-gpt-5.6-file-first",
      createdAt: new Date().toISOString(),
      document: docName,
      provider: settings.provider,
      model: settings.model,
      sourceLanguage: settings.sourceLanguageName,
      industry: settings.industry,
      qualityMode: settings.qualityMode,
      workflow: "copy-original-first-then-open-and-translate-copy",
      languages: []
    };
  }

  function makeLanguageReport(language) {
    return {
      language: language.name,
      code: language.code,
      status: "queued",
      units: 0,
      characters: 0,
      chunks: 0,
      skippedCount: 0,
      skipped: [],
      startedAt: null,
      finishedAt: null,
      warnings: [],
      errors: []
    };
  }

  async function translateOneLanguage(settings, sourceDoc, language, langReport, hooks, totalLangs, langIndex) {
    const log = hooks.log || function () {};
    const progress = hooks.progress || function () {};
    const cancelled = hooks.cancelled || function () { return false; };

    let workDoc = null;
    let outFile = null;
    let savedOk = false;

    try {
      langReport.status = "copying_original";
      langReport.startedAt = new Date().toISOString();
      log(`\n▶ ${language.name}: making clean copy first...`);
      outFile = await window.AIT_InDesignDom.createUntranslatedLanguageCopy(settings.outputFolder, sourceDoc, language.name);
      langReport.outputFile = outFile.name || `${window.AIT_InDesignDom.getDocumentBaseName(sourceDoc)} - ${language.name}.indd`;

      if (cancelled()) throw new Error("Batch cancelled by user.");

      langReport.status = "opening_copy";
      workDoc = await window.AIT_InDesignDom.openDocumentFile(outFile);
      window.AIT_InDesignDom.activateDocument(workDoc);
      log(`  Copy opened: ${langReport.outputFile}`);

      const extraction = window.AIT_InDesignDom.extractUnitsFromDocument(workDoc, settings.scope, settings);
      const units = extraction.units;
      const skipped = extraction.skipped;
      if (!units.length) throw new Error("No translatable text found in the copied document.");

      langReport.units = units.length;
      langReport.skippedCount = skipped.length;
      langReport.skipped = skipped.map(s => ({ reason: s.reason, sourceLabel: s.sourceLabel, chars: String(s.originalText || "").length }));
      langReport.characters = units.reduce((sum, u) => sum + String(u.originalText || "").length, 0);
      const chunks = makeChunks(units, settings.chunkChars || DEFAULT_CHUNK_CHARS);
      langReport.chunks = chunks.length;
      langReport.status = "translating";
      log(`  Text units: ${units.length}; skipped locked/empty: ${skipped.length}; characters: ${langReport.characters.toLocaleString()}; chunks: ${chunks.length}`);

      const fullMap = {};
      for (let i = 0; i < chunks.length; i++) {
        if (cancelled()) throw new Error("Batch cancelled by user.");
        const chunk = chunks[i];
        const glossary = window.AIT_Glossary.filterGlossaryForText(settings.glossary, chunk.map(u => u.originalText).join("\n"));
        const chunkMap = await window.AIT_Providers.translateBatch(settings.provider, Object.assign({}, settings, {
          targetLanguage: language,
          sourceLanguageName: settings.sourceLanguageName,
          units: chunk,
          glossary
        }));
        Object.assign(fullMap, chunkMap);
        const warnings = validateAfterTranslation(chunk, chunkMap);
        langReport.warnings.push.apply(langReport.warnings, warnings);
        warnings.forEach(w => log(`  ⚠ ${w}`));
        const withinLanguage = (i + 1) / chunks.length;
        const overall = (langIndex + withinLanguage) / totalLangs;
        progress(overall, `${language.name}: chunk ${i + 1}/${chunks.length}`);
        log(`  ${language.name}: chunk ${i + 1}/${chunks.length} complete.`);
      }

      if (cancelled()) throw new Error("Batch cancelled by user.");

      // Gate 1: the translation map must be complete and sane before any write.
      langReport.status = "validating";
      let integrity = validateTranslationMap(units, fullMap);
      if (integrity.repairable.length) {
        log(`  ${integrity.repairable.length} unit(s) missing or empty — requesting repair translation...`);
        const repairChunks = makeChunks(integrity.repairable, settings.chunkChars || DEFAULT_CHUNK_CHARS);
        for (const repairChunk of repairChunks) {
          const repairGlossary = window.AIT_Glossary.filterGlossaryForText(settings.glossary, repairChunk.map(u => u.originalText).join("\n"));
          const repairMap = await window.AIT_Providers.translateBatch(settings.provider, Object.assign({}, settings, {
            targetLanguage: language,
            sourceLanguageName: settings.sourceLanguageName,
            units: repairChunk,
            glossary: repairGlossary
          }));
          Object.assign(fullMap, repairMap);
        }
        integrity = validateTranslationMap(units, fullMap);
      }
      if (integrity.repairable.length) {
        throw new Error(`Translation incomplete after repair attempt (${integrity.repairable.slice(0, 8).map(u => u.id).join(", ")}${integrity.repairable.length > 8 ? "..." : ""}). Stopped before writing anything.`);
      }
      integrity.warnings.forEach(w => { langReport.warnings.push(w); log(`  ⚠ ${w}`); });

      langReport.status = "applying_translation";
      const applyResults = window.AIT_InDesignDom.applyTranslations(units, fullMap, settings, language, workDoc);
      const applyErrors = applyResults.filter(r => !r.ok).map(r => `${r.id}: ${r.error || "apply failed"}`);
      langReport.errors.push.apply(langReport.errors, applyErrors);
      applyErrors.forEach(e => log(`  ⚠ Apply warning: ${e}`));

      // Gate 2: re-read every translated block from the document and compare it
      // to exactly what should have been written. A failed verification means
      // the copy is corrupt — it is NOT saved.
      langReport.status = "verifying";
      const verification = window.AIT_InDesignDom.verifyApplied(units, fullMap, workDoc, settings);
      if (verification.failed.length) {
        const sample = verification.failed.slice(0, 5).map(f => `${f.id} ("${f.actual}" ≠ "${f.expected}")`).join("; ");
        throw new Error(`Post-apply verification failed for ${verification.failed.length} of ${verification.checked} text blocks: ${sample}. The copy was NOT saved.`);
      }
      log(`  ✓ Verified ${verification.checked} text block(s) intact after apply.`);

      const overset = window.AIT_InDesignDom.countOversetStories(workDoc);
      langReport.oversetCount = overset.count;
      langReport.oversetDetails = overset.details;
      if (overset.count > 0) log(`  ⚠ ${overset.count} overset story/frame(s). Check layout after translation.`);

      langReport.status = "saving_copy";
      await window.AIT_InDesignDom.saveDocument(workDoc);
      savedOk = true;
      langReport.status = applyErrors.length ? "saved_with_apply_warnings" : "saved";
      langReport.finishedAt = new Date().toISOString();
      log(`  ✓ Saved translated copy: ${langReport.outputFile}`);
    } catch (err) {
      langReport.status = "failed";
      langReport.finishedAt = new Date().toISOString();
      langReport.errors.push(err.message || String(err));
      log(`  ✕ ${language.name} failed: ${err.message || err}`);
    } finally {
      const keepOpen = savedOk && settings.keepOpen !== false;
      try {
        // Close WITHOUT saving: on success the doc was already saved; on failure
        // this guarantees a corrupted copy is never persisted to disk.
        if (workDoc && !keepOpen) await window.AIT_InDesignDom.closeDocument(workDoc, false);
        else if (workDoc && keepOpen) log(`  Translated copy left open in InDesign: ${langReport.outputFile}`);
      } catch (closeErr) {
        langReport.warnings.push(`Could not close copied document automatically: ${closeErr.message || closeErr}`);
        log(`  ⚠ Could not close copied document automatically: ${closeErr.message || closeErr}`);
      }
      try { window.AIT_InDesignDom.activateDocument(sourceDoc); } catch (_) {}
    }
    return (savedOk && settings.keepOpen !== false) ? workDoc : null;
  }

  async function runBatch(settings, hooks) {
    hooks = hooks || {};
    const log = hooks.log || function () {};
    const progress = hooks.progress || function () {};
    const cancelled = hooks.cancelled || function () { return false; };

    if (settings.scope === "selection") {
      throw new Error("Selection mode is not enabled for the safer file-first workflow yet. Use Whole document so the original is never edited.");
    }

    const sourceDoc = window.AIT_InDesignDom.getActiveDocument();
    const baseName = window.AIT_InDesignDom.getDocumentBaseName(sourceDoc);
    const selectedLanguages = settings.targetLanguages || [];
    if (!selectedLanguages.length) throw new Error("Select at least one target language.");
    if (!settings.outputFolder) throw new Error("Choose an output folder first.");

    const report = makeReport(settings, sourceDoc.name || baseName);

    log(`Document: ${sourceDoc.name || baseName}`);
    log("Workflow: clean-copy first. The open original document will not be translated or restored afterwards.");
    log(`Languages: ${selectedLanguages.map(l => l.name).join(", ")}`);

    let lastKeptOpen = null;
    for (let langIndex = 0; langIndex < selectedLanguages.length; langIndex++) {
      if (cancelled()) throw new Error("Batch cancelled by user.");
      const language = selectedLanguages[langIndex];
      const langReport = makeLanguageReport(language);
      report.languages.push(langReport);
      const keptDoc = await translateOneLanguage(settings, sourceDoc, language, langReport, hooks, selectedLanguages.length, langIndex);
      if (keptDoc) lastKeptOpen = keptDoc;
    }

    if (settings.saveReport && settings.outputFolder) {
      try {
        const files = await window.AIT_InDesignDom.writeReportFiles(settings.outputFolder, baseName, report);
        log(`\nReport saved: ${files.map(f => f.name).join(", ")}`);
      } catch (err) {
        log(`\n⚠ Could not save report: ${err.message || err}`);
      }
    }

    if (lastKeptOpen) {
      try {
        window.AIT_InDesignDom.activateDocument(lastKeptOpen);
        log("\nShowing the translated copy.");
      } catch (_) {}
    }

    progress(1, "Complete");
    log("\n✓ Batch complete. Original document was not edited.");
    return report;
  }

  function estimate(settings) {
    const extraction = window.AIT_InDesignDom.extractUnits(settings.scope, settings);
    return Object.assign(window.AIT_Providers.estimateCost(extraction.units, settings.targetLanguages || []), {
      units: extraction.units.length,
      skipped: extraction.skipped.length,
      chunkChars: settings.chunkChars || DEFAULT_CHUNK_CHARS,
      estimatedChunksPerLanguage: makeChunks(extraction.units, settings.chunkChars || DEFAULT_CHUNK_CHARS).length
    });
  }

  window.AIT_BatchEngine = { runBatch, estimate, makeChunks };
})();
