# GPT-5.6 update report

## Current usage inventory

- OpenAI translation is a stateless, text-only call to `POST /v1/responses`.
- The system prompt enforces print-ready translation, placeholder preservation, glossary use, compact InDesign layout, and strict JSON output.
- The parser requires one translated string for every input unit ID.
- The previous default was GPT-4.1 with low temperature; GPT-5-family selections omitted explicit reasoning.
- Anthropic, Gemini, and the offline mock provider use independent adapters.

## Target mapping

- New default: `gpt-5.6-sol` for highest-quality professional translation.
- Balanced option: `gpt-5.6-terra`.
- Fast option: `gpt-5.6-luna`.
- Saved GPT-5.5 and GPT-5.4 flagship values migrate to Sol.
- Saved GPT-5 mini, GPT-5.4 mini, GPT-4.1, GPT-4.1 mini, GPT-4o, and GPT-4o mini values migrate to Terra.
- Unknown custom model values remain custom rather than being silently replaced.

## Changes made

- Replaced the OpenAI picker defaults with the GPT-5.6 family and added friendly labels.
- Added saved-setting migration and request-time normalization.
- Added `reasoning: { effort: "none" }` to GPT-5.6 Responses requests and omitted sampling temperature.
- Updated plugin, manifest, UI, batch-report, and package versions to 1.2.1.
- Added provider contract tests for every GPT-5.6 tier.
- Added fresh-per-write InDesign paragraph resolution and a regression test for leading-text clipping after neighbouring paragraph changes.

## Compatibility checks

- Endpoint: Responses API retained; no Chat Completions or function-tool compatibility issue.
- State: calls remain stateless; no persisted reasoning or replay behavior was added.
- Caching: no cache configuration existed and none was added.
- Multimodal: the route is text-only; image/PDF detail behavior is not involved.
- Output contract: strict translation-ID JSON parsing is unchanged.
- Context and cost: the existing chunk limits remain unchanged; users select Sol, Terra, or Luna by quality/cost role.
- Mixed providers: Anthropic, Gemini, and Mock routing are unchanged.

## Prompt changes

None. The existing translation prompt and structured-output contract were preserved because no prompt regression was established.

## Validation

- `npm run validate` checks syntax, manifest alignment, and GPT-5.6 integration markers.
- `npm test` exercises all three GPT-5.6 request payloads and validates JSON parsing.
- A live OpenAI smoke test should be run inside Adobe UXP Developer Tool because Adobe's network and secure-storage runtime cannot be reproduced by Node alone.

## Unchanged sites

- Anthropic and Gemini model lists and request adapters.
- InDesign copy-first document workflow, glossary handling, placeholder protection, layout modes, retries, secure storage, and batch reporting.

## Remaining host validation

- Load version 1.2.1 in Adobe UXP Developer Tool.
- Run one short copied InDesign document through each GPT-5.6 tier.
- Confirm overset reporting, secure key recall, output filenames, and translated ID completeness in the actual InDesign host.
