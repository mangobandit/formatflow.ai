(function () {
  const $ = id => document.getElementById(id);
  let outputFolder = null;
  let glossary = [];
  let running = false;
  let cancelling = false;
  let sessionApiKey = "";
  let selectedLanguageCodes = new Set();

  document.addEventListener("DOMContentLoaded", init);

  async function init() {
    try {
      applyTheme();
      renderSourceLanguages();
      renderLanguages();
      hydrateModelList();
      bindEvents();
      await restoreSettings();
      watchThemeChanges();
      log("Ready.");
    } catch (err) {
      fail(err);
    }
  }

  // Returns true (dark) / false (light) from InDesign's UI brightness setting, or null if unavailable.
  function detectInDesignDarkness() {
    try {
      const indesign = require("indesign");
      const app = indesign.app || indesign;
      const prefs = app && app.generalPreferences;
      const brightness = prefs ? prefs.uiBrightnessPreference : undefined;
      if (typeof brightness === "number") return brightness < 0.5;
    } catch (_) {}
    return null;
  }

  function applyTheme() {
    const select = $("theme");
    const mode = select ? select.value : "auto";
    let dark = true;
    if (mode === "dark") dark = true;
    else if (mode === "light") dark = false;
    else {
      const hostDark = detectInDesignDarkness();
      if (hostDark !== null) dark = hostDark;
      else if (window.matchMedia) dark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    }
    document.documentElement.setAttribute("data-theme", dark ? "dark" : "light");
  }

  function watchThemeChanges() {
    try {
      if (window.matchMedia) {
        const mq = window.matchMedia("(prefers-color-scheme: dark)");
        if (typeof mq.addEventListener === "function") mq.addEventListener("change", applyTheme);
        else if (typeof mq.addListener === "function") mq.addListener(applyTheme);
      }
    } catch (_) {}
    // Re-check InDesign brightness when the user returns to the panel.
    window.addEventListener("focus", applyTheme);
    document.addEventListener("visibilitychange", applyTheme);
  }

  function bindEvents() {
    document.querySelectorAll(".tab-btn").forEach(btn => {
      btn.addEventListener("click", () => switchTab(btn.getAttribute("data-tab")));
    });
    $("resetForm").addEventListener("click", resetForm);
    $("provider").addEventListener("change", async () => { hydrateModelList(); await restoreApiKeyForProvider(); });
    // Persist the key the moment it's entered — no separate Save click needed.
    $("apiKey").addEventListener("change", persistApiKey);
    $("rememberKey").addEventListener("change", persistApiKey);
    $("theme").addEventListener("change", applyTheme);
    $("saveSettings").addEventListener("click", saveSettings);
    $("chooseFolder").addEventListener("click", chooseFolder);
    $("loadGlossary").addEventListener("click", loadGlossary);
    $("selectCore").addEventListener("click", () => selectPreset("core20"));
    $("selectEuro").addEventListener("click", () => selectPreset("europe"));
    $("selectAfrica").addEventListener("click", () => selectPreset("africa"));
    $("selectAsia").addEventListener("click", () => selectPreset("asia"));
    $("selectMiddleEast").addEventListener("click", () => selectPreset("middleEast"));
    $("selectAmericas").addEventListener("click", () => selectPreset("americas"));
    $("clearLangs").addEventListener("click", clearLanguages);
    $("languageSearch").addEventListener("input", renderLanguages);
    $("estimate").addEventListener("click", estimate);
    $("translate").addEventListener("click", translateBatch);
    $("cancel").addEventListener("click", () => { cancelling = true; log("Cancellation requested. Finishing current request safely..."); });
  }

  function renderSourceLanguages() {
    const select = $("sourceLang");
    select.innerHTML = "";
    window.AIT_LANGUAGES.filter(l => l.sourceOnly || l.code === "en" || !/^en-/.test(l.code)).forEach(lang => {
      const opt = document.createElement("option");
      opt.value = lang.code;
      opt.textContent = lang.name;
      select.appendChild(opt);
    });
    select.value = "auto";
  }

  function renderLanguages() {
    const container = $("languageGroups");
    const query = ($("languageSearch").value || "").trim().toLowerCase();
    container.innerHTML = "";

    const groups = new Map();
    for (const lang of window.AIT_TARGET_LANGUAGES) {
      if (query && !lang.name.toLowerCase().includes(query) && !lang.code.toLowerCase().includes(query)) continue;
      const region = lang.region || "Other";
      if (!groups.has(region)) groups.set(region, []);
      groups.get(region).push(lang);
    }

    const ordered = Array.from(groups.keys()).sort((a, b) => {
      const ai = window.AIT_LANGUAGE_REGION_ORDER.indexOf(a);
      const bi = window.AIT_LANGUAGE_REGION_ORDER.indexOf(b);
      if (ai === -1 && bi === -1) return a.localeCompare(b);
      if (ai === -1) return 1;
      if (bi === -1) return -1;
      return ai - bi || a.localeCompare(b);
    });

    for (const region of ordered) {
      const langs = groups.get(region).sort((a, b) => a.name.localeCompare(b.name));
      const section = document.createElement("section");
      section.className = "lang-group";

      const head = document.createElement("div");
      head.className = "lang-group-head";
      const title = document.createElement("h3");
      title.textContent = region;
      const actions = document.createElement("div");
      // Divs, not <button> — UXP forces native pill chrome on buttons.
      const addBtn = document.createElement("div");
      addBtn.className = "mini-btn";
      addBtn.textContent = "Tick all";
      addBtn.addEventListener("click", () => selectCodes(langs.map(l => l.code), true));
      const removeBtn = document.createElement("div");
      removeBtn.className = "mini-btn";
      removeBtn.textContent = "Untick";
      removeBtn.addEventListener("click", () => selectCodes(langs.map(l => l.code), false));
      actions.appendChild(addBtn);
      actions.appendChild(removeBtn);
      head.appendChild(title);
      head.appendChild(actions);
      section.appendChild(head);

      const grid = document.createElement("div");
      grid.className = "language-grid";
      for (const lang of langs) {
        const label = document.createElement("label");
        const input = document.createElement("input");
        input.type = "checkbox";
        input.value = lang.code;
        input.checked = selectedLanguageCodes.has(lang.code);
        input.addEventListener("change", () => {
          if (input.checked) selectedLanguageCodes.add(lang.code);
          else selectedLanguageCodes.delete(lang.code);
          updateSelectedCount();
        });
        label.appendChild(input);
        label.appendChild(document.createTextNode(`${lang.name}${lang.rtl ? " ↔" : ""}`));
        grid.appendChild(label);
      }
      section.appendChild(grid);
      container.appendChild(section);
    }

    updateSelectedCount();
  }

  function hydrateModelList() {
    const provider = $("provider").value;
    const models = window.AIT_Providers.DEFAULT_MODELS[provider] || [];
    const select = $("model");
    const previous = select.value;
    select.innerHTML = "";
    models.forEach(model => {
      const opt = document.createElement("option");
      opt.value = model;
      opt.textContent = window.AIT_Providers.getModelLabel(provider, model);
      select.appendChild(opt);
    });
    if (previous && models.includes(previous)) select.value = previous;
    else select.value = window.AIT_Providers.getDefaultModel(provider);
  }

  // Selects a model in the dropdown, adding it as a custom option if it isn't
  // one of the provider defaults (e.g. a model saved in an earlier session).
  function setModelValue(value) {
    const select = $("model");
    if (!value) return;
    const exists = Array.prototype.some.call(select.options, opt => opt.value === value);
    if (!exists) {
      const opt = document.createElement("option");
      opt.value = value;
      opt.textContent = `${value} (custom)`;
      select.appendChild(opt);
    }
    select.value = value;
  }

  async function restoreSettings() {
    const settings = window.AIT_Storage.readSettings();
    $("provider").value = settings.provider || "openai";
    hydrateModelList();
    setModelValue(window.AIT_Providers.normalizeModel(
      $("provider").value,
      settings.model || window.AIT_Providers.getDefaultModel($("provider").value)
    ));
    $("sourceLang").value = settings.sourceLang || "auto";
    $("industry").value = settings.industry || "Industrial packaging";
    $("qualityMode").value = settings.qualityMode || "layout-tight";
    $("context").value = settings.context || "";
    $("preserveCharStyles").checked = settings.preserveCharStyles === true;
    $("protectPlaceholders").checked = settings.protectPlaceholders !== false;
    $("skipLocked").checked = settings.skipLocked !== false;
    $("rtlSupport").checked = settings.rtlSupport !== false;
    $("saveReport").checked = settings.saveReport !== false;
    $("keepOpen").checked = settings.keepOpen !== false;
    $("rememberKey").checked = settings.rememberKey !== false; // remember by default
    $("theme").value = settings.theme || "auto";
    applyTheme();
    if (Array.isArray(settings.selectedLanguageCodes)) {
      selectedLanguageCodes = new Set(settings.selectedLanguageCodes);
      renderLanguages();
    }
    await restoreApiKeyForProvider();
  }

  async function persistApiKey() {
    try {
      sessionApiKey = $("apiKey").value.trim();
      const result = await window.AIT_Storage.saveApiKey($("provider").value, sessionApiKey, $("rememberKey").checked);
      renderSecureHint(result);
      if (result.remembered) log("API key saved for this machine.");
    } catch (err) { fail(err); }
  }

  async function restoreApiKeyForProvider() {
    const provider = $("provider").value;
    if (!$("rememberKey").checked) {
      $("apiKey").value = sessionApiKey || "";
      return;
    }
    const result = await window.AIT_Storage.loadApiKey(provider);
    $("apiKey").value = result.value || "";
    renderSecureHint(result);
  }

  function renderSecureHint(result) {
    const hint = $("secureHint");
    if (result && result.value && result.secure) hint.textContent = "API key loaded from host secure storage. Keys are never logged.";
    else if (result && result.value && result.fallback) hint.textContent = "Warning: host secure storage was unavailable; key was loaded from local plugin storage.";
    else hint.textContent = "Keys are never logged. If host secure storage is unavailable, the plugin falls back to local plugin storage and warns you.";
  }

  async function saveSettings() {
    const settings = collectUiSettings(false);
    settings.selectedLanguageCodes = Array.from(selectedLanguageCodes);
    window.AIT_Storage.writeSettings(settings);
    sessionApiKey = $("apiKey").value.trim();
    const keyResult = await window.AIT_Storage.saveApiKey(settings.provider, sessionApiKey, settings.rememberKey);
    renderSecureHint(keyResult);
    log("Settings saved.");
  }

  async function chooseFolder() {
    try {
      outputFolder = await window.AIT_InDesignDom.chooseOutputFolder();
      $("folderName").textContent = outputFolder.name || "Selected folder";
      log(`Output folder selected: ${outputFolder.name || "folder"}`);
    } catch (err) { fail(err); }
  }

  async function loadGlossary() {
    try {
      const uxp = require("uxp");
      const file = await uxp.storage.localFileSystem.getFileForOpening({ types: ["csv", "txt"] });
      if (!file) return;
      const text = await file.read();
      glossary = window.AIT_Glossary.parseCsv(text);
      $("glossaryName").textContent = `${file.name} (${glossary.length} terms)`;
      log(`Glossary loaded: ${glossary.length} terms.`);
    } catch (err) { fail(err); }
  }

  function selectPreset(name) {
    selectedLanguageCodes = new Set(window.AIT_LANGUAGE_PRESETS[name] || []);
    renderLanguages();
  }

  function selectCodes(codes, checked) {
    for (const code of codes) {
      if (checked) selectedLanguageCodes.add(code);
      else selectedLanguageCodes.delete(code);
    }
    renderLanguages();
  }

  function clearLanguages() {
    selectedLanguageCodes.clear();
    renderLanguages();
  }

  function switchTab(tabId) {
    if (!tabId) return;
    document.querySelectorAll(".tab-page").forEach(page => {
      page.classList.toggle("active", page.id === tabId);
    });
    document.querySelectorAll(".tab-btn").forEach(btn => {
      btn.classList.toggle("active", btn.getAttribute("data-tab") === tabId);
    });
  }

  function resetForm() {
    if (running) return;
    selectedLanguageCodes.clear();
    $("languageSearch").value = "";
    $("context").value = "";
    glossary = [];
    $("glossaryName").textContent = "No glossary loaded";
    renderLanguages();
    setProgress(0, "Ready.");
    clearLog();
    log("Form reset. Provider, model, API key, and saved settings kept.");
  }

  function getSelectedLanguages() {
    return window.AIT_TARGET_LANGUAGES.filter(lang => selectedLanguageCodes.has(lang.code));
  }

  function updateSelectedCount() {
    $("selectedCount").textContent = `${selectedLanguageCodes.size} selected`;
  }

  function selectedScope() {
    const checked = document.querySelector("input[name='scope']:checked");
    return checked ? checked.value : "document";
  }

  function collectUiSettings(includeApiKey) {
    const source = window.AIT_getLanguage($("sourceLang").value);
    const settings = {
      provider: $("provider").value,
      model: window.AIT_Providers.normalizeModel(
        $("provider").value,
        $("model").value.trim() || window.AIT_Providers.getDefaultModel($("provider").value)
      ),
      sourceLang: $("sourceLang").value,
      sourceLanguageName: source.name || $("sourceLang").value,
      industry: $("industry").value,
      qualityMode: $("qualityMode").value,
      context: $("context").value.trim(),
      preserveCharStyles: $("preserveCharStyles").checked,
      protectPlaceholders: $("protectPlaceholders").checked,
      skipLocked: $("skipLocked").checked,
      rtlSupport: $("rtlSupport").checked,
      saveReport: $("saveReport").checked,
      keepOpen: $("keepOpen").checked,
      rememberKey: $("rememberKey").checked,
      theme: $("theme").value,
      scope: selectedScope(),
      glossary,
      targetLanguages: getSelectedLanguages(),
      outputFolder,
      chunkChars: 3200
    };
    if (includeApiKey) settings.apiKey = $("apiKey").value.trim() || sessionApiKey;
    return settings;
  }

  async function estimate() {
    if (running) return;
    try {
      const settings = collectUiSettings(false);
      if (!settings.targetLanguages.length) throw new Error("Select at least one target language first.");
      const estimate = window.AIT_BatchEngine.estimate(settings);
      log(`Estimate: ${estimate.units} text units, ${estimate.skipped} skipped, ${estimate.chars.toLocaleString()} chars per language, ${estimate.estimatedChunksPerLanguage} chunks per language, approx ${estimate.totalApproxTokens.toLocaleString()} total tokens across ${settings.targetLanguages.length} language(s).`);
    } catch (err) { fail(err); }
  }

  async function translateBatch() {
    if (running) return;
    running = true;
    cancelling = false;
    setBusy(true);
    setProgress(0, "Starting...");

    try {
      const settings = collectUiSettings(true);
      if (!settings.targetLanguages.length) throw new Error("Select at least one target language.");
      if (!settings.outputFolder) {
        outputFolder = await window.AIT_InDesignDom.chooseOutputFolder();
        settings.outputFolder = outputFolder;
        $("folderName").textContent = outputFolder.name || "Selected folder";
      }
      if (settings.provider !== "mock" && !settings.apiKey) throw new Error(`Missing API key for ${settings.provider}. Open Settings and add it.`);
      await saveSettings();
      clearLog();
      await window.AIT_BatchEngine.runBatch(settings, {
        log,
        progress: setProgress,
        cancelled: () => cancelling
      });
    } catch (err) { fail(err); }
    finally {
      setBusy(false);
      running = false;
    }
  }

  function setBusy(value) {
    $("translate").disabled = value;
    $("estimate").disabled = value;
    $("resetForm").disabled = value;
    $("cancel").disabled = !value;
  }

  function setProgress(value, status) {
    const pct = Math.max(0, Math.min(100, Math.round(value * 100)));
    $("bar").style.width = `${pct}%`;
    $("percentText").textContent = `${pct}%`;
    if (status) $("statusText").textContent = status;
  }

  function clearLog() { $("log").textContent = ""; }

  function log(message) {
    const box = $("log");
    const prefix = box.textContent ? "\n" : "";
    box.textContent += `${prefix}${message}`;
    box.scrollTop = box.scrollHeight;
  }

  function fail(err) {
    const msg = err && err.message ? err.message : String(err);
    log(`ERROR: ${msg}`);
    setProgress(0, "Error");
    console.error(err);
  }
})();
