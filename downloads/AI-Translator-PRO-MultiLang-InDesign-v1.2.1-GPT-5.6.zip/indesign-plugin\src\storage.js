(function () {
  const SETTINGS_KEY = "aitpro_settings_v1";
  const API_KEY_PREFIX = "aitpro_api_key_";

  function tryUxP() {
    try { return require("uxp"); } catch (_) { return null; }
  }

  async function setSecure(key, value) {
    const uxp = tryUxP();
    const secure = uxp && uxp.storage && uxp.storage.secureStorage;
    if (secure && typeof secure.setItem === "function") {
      await secure.setItem(key, value);
      return { secure: true, fallback: false };
    }
    localStorage.setItem(key, value);
    return { secure: false, fallback: true };
  }

  async function getSecure(key) {
    const uxp = tryUxP();
    const secure = uxp && uxp.storage && uxp.storage.secureStorage;
    if (secure && typeof secure.getItem === "function") {
      const val = await secure.getItem(key);
      if (val) return { value: val, secure: true, fallback: false };
    }
    return { value: localStorage.getItem(key) || "", secure: false, fallback: true };
  }

  async function removeSecure(key) {
    const uxp = tryUxP();
    const secure = uxp && uxp.storage && uxp.storage.secureStorage;
    if (secure && typeof secure.removeItem === "function") {
      try { await secure.removeItem(key); } catch (_) {}
    }
    localStorage.removeItem(key);
  }

  function readSettings() {
    try { return JSON.parse(localStorage.getItem(SETTINGS_KEY) || "{}"); }
    catch (_) { return {}; }
  }

  function writeSettings(settings) {
    const safe = Object.assign({}, settings);
    delete safe.apiKey;
    delete safe.outputFolder;     // UXP host object — not JSON-serializable
    delete safe.glossary;         // reloaded from CSV each session
    delete safe.targetLanguages;  // derived from selectedLanguageCodes
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(safe));
  }

  function apiKeyId(provider) {
    return `${API_KEY_PREFIX}${provider || "openai"}`;
  }

  async function saveApiKey(provider, apiKey, remember) {
    const key = apiKeyId(provider);
    if (!remember || !apiKey) {
      await removeSecure(key);
      return { remembered: false, secure: false, fallback: false };
    }
    const result = await setSecure(key, apiKey);
    return { remembered: true, secure: result.secure, fallback: result.fallback };
  }

  async function loadApiKey(provider) {
    return await getSecure(apiKeyId(provider));
  }

  window.AIT_Storage = {
    readSettings,
    writeSettings,
    saveApiKey,
    loadApiKey,
    removeApiKey: async (provider) => removeSecure(apiKeyId(provider))
  };
})();
