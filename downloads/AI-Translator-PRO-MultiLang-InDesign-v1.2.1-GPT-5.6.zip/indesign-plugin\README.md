# AI Translator PRO MultiLang — v1.2.1 GPT-5.6 file-first build

Adobe InDesign UXP plugin for multi-language document translation.

## OpenAI models in v1.2.1

- GPT-5.6 Sol is the default for the highest translation quality.
- GPT-5.6 Terra balances quality and cost.
- GPT-5.6 Luna is the fastest, lowest-cost GPT-5.6 option.
- Saved GPT-5.5, GPT-5.4, GPT-4.1, GPT-4o, and mini selections migrate automatically to the matching GPT-5.6 tier.
- OpenAI requests use the Responses API with reasoning explicitly set to `none` to preserve the plugin's previous translation latency and cost behavior.
- API keys remain bring-your-own-key and are never included in the plugin package.

## Important v1.1 workflow change

This build uses a safe **copy-original-first** workflow.

For each selected target language, the plugin:

1. Creates a clean copy of the open source document in the output folder.
2. Opens that copied `.indd` file.
3. Translates inside the copied file only.
4. Saves the copied file.
5. Closes the copied file and returns to the original document.

The open original document is no longer translated live.

## Multi-language batching

Choose multiple target languages using the region tick boxes or quick presets:

- Core 20
- Europe
- Africa
- Asia
- Middle East
- Americas

Output naming example:

- `OriginalFileName - French.indd`
- `OriginalFileName - Spanish.indd`
- `OriginalFileName - German.indd`

## Translation quality changes

- Re-resolves every InDesign paragraph immediately before writing so changed text lengths cannot clip the start of another translated block.
- Includes a regression test for the post-apply verification failure fixed in 1.2.1.
- Smaller translation chunks for better reliability.
- Layout-tight mode is now the default.
- Stronger prompt rules prevent source-text duplication.
- Experimental character-style runs are off by default because style-run translation can cause duplicated fragments when InDesign splits sentences across ranges.

## How to install

1. Unzip this package.
2. Open Adobe UXP Developer Tool.
3. Add the plugin by selecting `manifest.json`.
4. Open InDesign.
5. Load the plugin.
6. Open the panel from the Plugins menu.
7. Choose output folder, languages, API provider/key, and run.

## First test recommendation

Run one language first on a short document and inspect:

- text quality
- overset warnings
- glyph/font support for CJK, Arabic, Hebrew, Hindi, etc.
- any locked layers or frames skipped by the report

Then run the full batch.
