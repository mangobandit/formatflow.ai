(function () {
  const patterns = [
    /https?:\/\/[^\s<>()"']+/gi,
    /www\.[^\s<>()"']+/gi,
    /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi,
    /\b[A-Z]{2,}[-_\/][A-Z0-9][-A-Z0-9_\/]{2,}\b/g,
    /\b[A-Z]{2,}\d{2,}[A-Z0-9-]*\b/g,
    /\b\d+(?:[.,]\d+)?\s?(?:kg|g|mg|lb|lbs|oz|mm|cm|m|km|in|ft|yd|l|ml|gal|°C|°F|bar|psi|kPa|MPa|%)\b/gi,
    /\{[^{}]{1,120}\}/g,
    /\[[^\[\]]{1,120}\]/g,
    /<[^<>]{1,160}>/g,
    /%[a-z0-9_.-]+%/gi,
    /\$\{[^}]+\}/g
  ];

  function protectText(input) {
    const text = String(input == null ? "" : input);
    const placeholders = [];
    let output = text;

    for (const pattern of patterns) {
      output = output.replace(pattern, match => {
        if (!match || match.length > 300) return match;
        if (match.indexOf("AIT_PH_") !== -1) return match; // never re-protect an existing placeholder token
        const id = `[[[AIT_PH_${String(placeholders.length).padStart(4, "0")}]]]`;
        placeholders.push({ id, value: match });
        return id;
      });
    }
    return { text: output, placeholders };
  }

  function restoreText(text, placeholders) {
    let output = String(text == null ? "" : text);
    const list = placeholders || [];
    // Restore in reverse insertion order so any nested tokens resolve inner-first.
    for (let i = list.length - 1; i >= 0; i--) {
      const item = list[i];
      output = output.split(item.id).join(item.value);
      output = output.split(item.id.replace(/\[/g, "\\[").replace(/\]/g, "\\]")).join(item.value);
    }
    return output;
  }

  function validatePlaceholders(text, placeholders) {
    const missing = [];
    const value = String(text || "");
    for (const item of placeholders || []) {
      if (!value.includes(item.id)) missing.push(item.id);
    }
    return { ok: missing.length === 0, missing };
  }

  function escapeXmlText(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  function unescapeXmlText(value) {
    return String(value == null ? "" : value)
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace(/&amp;/g, "&");
  }

  function makeTaggedRuns(runs) {
    return runs.map((run, i) => `<r id="${i}">${escapeXmlText(run.protectedText || run.text || "")}</r>`).join("");
  }

  function parseTaggedRuns(text) {
    const out = [];
    const source = String(text || "");
    const re = /<r\s+id=["']?(\d+)["']?\s*>([\s\S]*?)<\/r>/gi;
    let match;
    while ((match = re.exec(source))) {
      out.push({ index: Number(match[1]), text: unescapeXmlText(match[2]) });
    }
    return out;
  }

  function normalizeWhitespace(original, translated) {
    const o = String(original == null ? "" : original);
    let t = String(translated == null ? "" : translated);
    const leading = (o.match(/^\s+/) || [""])[0];
    const trailing = (o.match(/\s+$/) || [""])[0];
    t = t.trim();
    return leading + t + trailing;
  }

  function stripFences(text) {
    let out = String(text == null ? "" : text).trim();
    out = out.replace(/^```(?:json|xml|html|text)?\s*/i, "").replace(/\s*```$/i, "").trim();
    return out;
  }

  window.AIT_Protectors = {
    protectText,
    restoreText,
    validatePlaceholders,
    makeTaggedRuns,
    parseTaggedRuns,
    normalizeWhitespace,
    stripFences,
    escapeXmlText,
    unescapeXmlText
  };
})();
