(function () {
  let app = null;
  let uxp = null;
  let fs = null;
  let indesignModule = null;

  // Lazily (re)acquire host APIs on every use: capturing them once at script load
  // breaks after plugin reloads, when the host module can load before InDesign is ready.
  function loadHostApis() {
    if (!app) {
      try {
        indesignModule = require("indesign");
        app = indesignModule.app || indesignModule;
      } catch (_) {
        // UI can load in a browser for visual inspection; document actions require InDesign UXP.
      }
    }
    if (!fs) {
      try {
        uxp = require("uxp");
        fs = uxp.storage && uxp.storage.localFileSystem;
      } catch (_) {}
    }
  }
  loadHostApis();

  function requireInDesign() {
    loadHostApis();
    if (!app) throw new Error("InDesign API is not available. Open this panel inside Adobe InDesign.");
    return app;
  }

  function requireFileSystem() {
    loadHostApis();
    if (!fs) throw new Error("UXP file system is not available. Load this as an InDesign UXP plugin.");
    return fs;
  }

  async function chooseOutputFolder() {
    return await requireFileSystem().getFolder();
  }

  function getActiveDocument() {
    const indesignApp = requireInDesign();
    // Prefer activeDocument directly — documents.length can misreport 0 in UXP
    // even while a document is open (e.g. right after a plugin reload).
    let doc = null;
    try { doc = indesignApp.activeDocument; } catch (_) {}
    if (doc) return doc;
    let docsArr = [];
    try { docsArr = collectionToArray(indesignApp.documents); } catch (_) {}
    if (docsArr.length) return docsArr[0];
    throw new Error("No InDesign document is open.");
  }

  function getCollectionLength(collection) {
    if (!collection) return 0;
    if (typeof collection.length === "number") return collection.length;
    if (typeof collection.count === "function") {
      try { return collection.count(); } catch (_) {}
    }
    return 0;
  }

  function getDocumentBaseName(doc) {
    const name = (doc && doc.name) || "Translated Document";
    return name.replace(/\.indd$/i, "").replace(/\.idml$/i, "");
  }

  function safeFilePart(value) {
    return String(value || "").replace(/[\\/:*?"<>|]/g, "-").replace(/\s+/g, " ").trim().slice(0, 120) || "Output";
  }

  function collectionToArray(collection) {
    if (!collection) return [];
    if (Array.isArray(collection)) return collection;
    if (typeof collection.getElements === "function") {
      try { return collection.getElements(); } catch (_) {}
    }
    if (collection.everyItem && typeof collection.everyItem === "function") {
      try { return collection.everyItem().getElements(); } catch (_) {}
    }
    const out = [];
    let count = getCollectionLength(collection);
    for (let i = 0; i < count; i++) {
      try { out.push(collection.item(i)); } catch (_) {
        try { out.push(collection[i]); } catch (__) {}
      }
    }
    return out.filter(Boolean);
  }

  function stringContents(obj) {
    try { return typeof obj.contents === "string" ? obj.contents : ""; }
    catch (_) { return ""; }
  }

  function textIsTranslatable(text) {
    if (!text) return false;
    const clean = String(text).replace(/[\s\r\n\t\uFEFF]+/g, "");
    return clean.length > 0;
  }

  function isLocked(obj) {
    let current = obj;
    for (let i = 0; i < 8 && current; i++) {
      try { if (current.locked === true) return true; } catch (_) {}
      try { if (current.itemLayer && current.itemLayer.locked === true) return true; } catch (_) {}
      try { current = current.parent; } catch (_) { current = null; }
    }
    try {
      const frames = collectionToArray(obj.parentStory && obj.parentStory.textContainers);
      if (frames.some(f => f.locked || (f.itemLayer && f.itemLayer.locked))) return true;
    } catch (_) {}
    return false;
  }

  function storyLabel(story, index) {
    try {
      const frames = collectionToArray(story.textContainers);
      const first = frames[0];
      if (first && first.name) return first.name;
    } catch (_) {}
    return `Story ${index + 1}`;
  }

  function getSelectedContainers() {
    const indesignApp = requireInDesign();
    const selection = collectionToArray(indesignApp.selection);
    const containers = [];
    for (const item of selection) {
      if (!item) continue;
      if (item.paragraphs || item.textStyleRanges || typeof item.contents === "string") containers.push(item);
      else if (item.parentStory) containers.push(item.parentStory);
      else if (item.texts) containers.push(item);
    }
    return containers;
  }

  function getStoryContainers(doc, scope) {
    if (!doc) doc = getActiveDocument();
    if (scope === "selection") {
      const selected = getSelectedContainers();
      if (selected.length) return selected;
      throw new Error("Selection scope needs selected text/frame in the currently active document. For file-first batch translation, use Whole document for now.");
    }
    return collectionToArray(doc.stories);
  }

  function collectParagraphs(container) {
    if (!container) return [];
    try {
      if (container.paragraphs) {
        const p = collectionToArray(container.paragraphs);
        if (p.length) return p;
      }
    } catch (_) {}
    try {
      if (container.parentStory && container.parentStory.paragraphs) return collectionToArray(container.parentStory.paragraphs);
    } catch (_) {}
    if (typeof container.contents === "string") return [container];
    return [];
  }

  function extractStyleRuns(paragraph, protectPlaceholders) {
    const ranges = collectionToArray(paragraph.textStyleRanges);
    if (!ranges.length) return [];
    const runs = [];
    for (const range of ranges) {
      const original = stringContents(range);
      if (!original) continue;
      const protectedResult = protectPlaceholders
        ? window.AIT_Protectors.protectText(original)
        : { text: original, placeholders: [] };
      runs.push({ ref: range, originalText: original, protectedText: protectedResult.text, placeholders: protectedResult.placeholders });
    }
    return runs;
  }

  function makeUnit(paragraph, unitNumber, options, sourceLabel) {
    const originalText = stringContents(paragraph);
    if (!textIsTranslatable(originalText)) return null;
    if (options.skipLocked && isLocked(paragraph)) {
      return { skipped: true, reason: "locked", originalText, sourceLabel };
    }

    const hasFinalReturn = /\r$/.test(originalText);
    const textForTranslation = hasFinalReturn ? originalText.replace(/\r$/, "") : originalText;
    const charStyleMode = !!options.preserveCharStyles;
    let runs = [];
    let preparedText = "";
    let placeholders = [];
    let mode = "plain";

    // Paragraph-safe mode is the default. Translating independent style-runs causes duplicated fragments
    // when InDesign splits a sentence across several ranges, so style-runs are now opt-in/advanced only.
    if (charStyleMode) {
      runs = extractStyleRuns(paragraph, options.protectPlaceholders).filter(r => textIsTranslatable(r.originalText));
      if (runs.length > 1 && runs.length <= 40) {
        mode = "tagged-runs";
        preparedText = window.AIT_Protectors.makeTaggedRuns(runs);
      }
    }

    if (!preparedText) {
      const protectedResult = options.protectPlaceholders
        ? window.AIT_Protectors.protectText(textForTranslation)
        : { text: textForTranslation, placeholders: [] };
      preparedText = protectedResult.text;
      placeholders = protectedResult.placeholders;
    }

    return {
      id: `u${String(unitNumber).padStart(5, "0")}`,
      ref: paragraph,
      originalText,
      textForTranslation,
      preparedText,
      placeholders,
      runs,
      mode,
      hasFinalReturn,
      sourceLabel
    };
  }

  function padIndex(n, width) {
    return String(n).padStart(width || 3, "0");
  }

  function extractUnitsFromDocument(doc, scope, options) {
    const containers = getStoryContainers(doc, scope);
    const units = [];
    const skipped = [];
    let unitNumber = 0;
    containers.forEach((container, cIndex) => {
      const paragraphs = collectParagraphs(container);
      const label = container === (container && container.parentStory) ? storyLabel(container.parentStory, cIndex) : storyLabel(container, cIndex);

      paragraphs.forEach((paragraph, pIndex) => {
        const unit = makeUnit(paragraph, unitNumber, options, label);
        if (!unit) return;
        if (unit.skipped) skipped.push(unit);
        else {
          // Stable structural ID + position info: translations are mapped back by
          // this ID, and the paragraph is re-resolved fresh at apply/verify time.
          unit.id = `s${padIndex(cIndex)}-p${padIndex(pIndex, 4)}`;
          unit.containerIndex = cIndex;
          unit.paragraphIndex = pIndex;
          units.push(unit);
          unitNumber++;
        }
      });

      // Table cells are separate text objects — story.paragraphs does not include
      // them, so without this whole tables would silently stay untranslated.
      let tables = [];
      try { tables = collectionToArray(container.tables); } catch (_) {}
      tables.forEach((table, tIndex) => {
        let cells = [];
        try { cells = collectionToArray(table.cells); } catch (_) {}
        cells.forEach((cell, cellIndex) => {
          let cellParas = [];
          try { cellParas = collectionToArray(cell.paragraphs); } catch (_) {}
          cellParas.forEach((para, cpIndex) => {
            const unit = makeUnit(para, unitNumber, options, `${label} / table ${tIndex + 1}`);
            if (!unit) return;
            if (unit.skipped) skipped.push(unit);
            else {
              unit.id = `s${padIndex(cIndex)}-t${padIndex(tIndex)}-c${padIndex(cellIndex, 4)}-p${padIndex(cpIndex)}`;
              unit.tablePath = { story: cIndex, table: tIndex, cell: cellIndex, para: cpIndex };
              units.push(unit);
              unitNumber++;
            }
          });
        });
      });
    });
    return { units, skipped };
  }

  function extractUnits(scope, options) {
    return extractUnitsFromDocument(getActiveDocument(), scope, options);
  }

  function restoreUnits(units) {
    for (const unit of units || []) {
      try { unit.ref.contents = unit.originalText; } catch (_) {}
    }
    recompose();
  }

  // Builds the exact text that will be written for a unit — shared by apply and
  // post-apply verification so both always agree.
  function buildPlainOutput(unit, translated) {
    let output = window.AIT_Protectors.restoreText(translated, unit.placeholders);
    output = window.AIT_Protectors.normalizeWhitespace(unit.textForTranslation, output);
    if (unit.hasFinalReturn && !/\r$/.test(output)) output += "\r";
    return output;
  }

  function applyPlainTranslation(unit, translated, targetRef) {
    const output = buildPlainOutput(unit, translated);
    const ref = targetRef || unit.ref;
    try { ref.contents = output; return { ok: true, fallback: false }; }
    catch (err) { return { ok: false, error: err.message || String(err) }; }
  }

  function applyTaggedRunTranslation(unit, translated) {
    const parsed = window.AIT_Protectors.parseTaggedRuns(translated);
    if (!parsed.length || parsed.length !== unit.runs.length) {
      return applyPlainTranslation(unit, stripTagsToPlain(unit, translated, true));
    }

    const byIndex = {};
    parsed.forEach(item => { byIndex[item.index] = item.text; });

    try {
      for (let i = unit.runs.length - 1; i >= 0; i--) {
        const run = unit.runs[i];
        let output = byIndex[i];
        if (typeof output !== "string") throw new Error(`Missing style run ${i}`);
        output = window.AIT_Protectors.restoreText(output, run.placeholders);
        output = window.AIT_Protectors.normalizeWhitespace(run.originalText, output);
        run.ref.contents = output;
      }
      return { ok: true, fallback: false };
    } catch (err) {
      return applyPlainTranslation(unit, stripTagsToPlain(unit, translated, true));
    }
  }

  function stripTagsToPlain(unit, translated, restoreRunPlaceholders) {
    const parsed = window.AIT_Protectors.parseTaggedRuns(translated);
    if (!parsed.length) return String(translated || "").replace(/<\/?r\b[^>]*>/gi, "");
    const pieces = [];
    parsed.sort((a, b) => a.index - b.index).forEach(item => {
      let value = item.text;
      if (restoreRunPlaceholders && unit.runs[item.index]) {
        value = window.AIT_Protectors.restoreText(value, unit.runs[item.index].placeholders);
      }
      pieces.push(value);
    });
    return pieces.join("");
  }

  // Fresh paragraph resolver: re-enumerates the document for every lookup and
  // resolves each unit by structural position (story/table/cell indices). Cached
  // text references drift once contents change length — that drift was eating
  // the leading characters of later paragraphs.
  function makeResolver(doc) {
    return function resolve(unit, expectText) {
      let candidate = null;
      let stories = [];
      try { stories = collectionToArray(doc.stories); } catch (_) {}
      try {
        if (unit.tablePath) {
          const tables = collectionToArray(stories[unit.tablePath.story].tables);
          const cells = collectionToArray(tables[unit.tablePath.table].cells);
          const paragraphs = collectionToArray(cells[unit.tablePath.cell].paragraphs);
          candidate = paragraphs[unit.tablePath.para] || null;
        } else if (typeof unit.containerIndex === "number" && typeof unit.paragraphIndex === "number") {
          const paragraphs = collectionToArray(stories[unit.containerIndex].paragraphs);
          candidate = paragraphs[unit.paragraphIndex] || null;
        }
      } catch (_) {}
      if (candidate && typeof expectText === "string" && stringContents(candidate) !== expectText) candidate = null;
      return candidate;
    };
  }

  function applyTranslations(units, translationMap, options, targetLanguage, doc) {
    if (!doc) { try { doc = getActiveDocument(); } catch (_) { doc = null; } }
    const resolve = doc ? makeResolver(doc) : function () { return null; };

    const results = [];
    // Apply last-to-first: replacing contents changes text length, which shifts
    // later paragraph references in the same story (same reason style runs are
    // applied in reverse inside applyTaggedRunTranslation).
    for (let i = units.length - 1; i >= 0; i--) {
      const unit = units[i];
      const translated = translationMap[unit.id];
      let result;
      if (unit.mode === "tagged-runs" && options.preserveCharStyles) result = applyTaggedRunTranslation(unit, translated);
      else result = applyPlainTranslation(unit, translated, resolve(unit, unit.originalText));
      results.push(Object.assign({ id: unit.id, sourceLabel: unit.sourceLabel, mode: unit.mode }, result));
    }
    results.reverse();
    if (options.rtlSupport && targetLanguage && targetLanguage.rtl) applyRtl(doc, targetLanguage);
    recompose(doc);
    return results;
  }

  function textsEquivalent(a, b) {
    const norm = s => String(s == null ? "" : s)
      .replace(/\r$/, "")
      .replace(/[‘’]/g, "'")
      .replace(/[“”]/g, '"');
    return norm(a) === norm(b);
  }

  // Post-apply integrity check: re-reads every translated paragraph fresh from
  // the document and compares it against exactly what should have been written.
  // Catches shifted/clipped/partially-overwritten text before anything is saved.
  function verifyApplied(units, translationMap, doc, options) {
    if (!doc) doc = getActiveDocument();
    const resolve = makeResolver(doc);
    const failed = [];
    let checked = 0;
    for (const unit of units) {
      if (unit.mode === "tagged-runs" && options && options.preserveCharStyles) continue; // experimental path, not verified
      const translated = translationMap[unit.id];
      if (typeof translated !== "string") continue; // completeness is validated before apply
      const expected = buildPlainOutput(unit, translated);
      const target = resolve(unit) || unit.ref;
      let actual = "";
      try { actual = stringContents(target); } catch (_) { actual = ""; }
      checked++;
      if (!textsEquivalent(actual, expected)) {
        failed.push({ id: unit.id, expected: expected.slice(0, 60), actual: String(actual).slice(0, 60) });
      }
    }
    return { checked, failed };
  }

  function applyRtl(doc, targetLanguage) {
    if (!doc) doc = getActiveDocument();
    const stories = collectionToArray(doc.stories);
    for (const story of stories) {
      try {
        if (story.storyPreferences) {
          const opts = indesignModule && (indesignModule.StoryDirectionOptions || {});
          story.storyPreferences.storyDirection = (opts && (opts.RIGHT_TO_LEFT_DIRECTION || opts.rightToLeftDirection)) || 1379028068;
        }
      } catch (_) {}
      try {
        const paragraphs = collectionToArray(story.paragraphs);
        for (const p of paragraphs) {
          if (p.paragraphDirection !== undefined) p.paragraphDirection = 1379028068;
        }
      } catch (_) {}
    }
  }

  function recompose(doc) {
    try { (doc || getActiveDocument()).recompose(); } catch (_) {}
  }

  function countOversetStories(doc) {
    if (!doc) doc = getActiveDocument();
    let count = 0;
    const details = [];
    const stories = collectionToArray(doc.stories);
    stories.forEach((story, index) => {
      let over = false;
      try {
        const frames = collectionToArray(story.textContainers);
        over = frames.some(f => f && f.overflows === true);
      } catch (_) {}
      try { if (story.overflows === true) over = true; } catch (_) {}
      if (over) { count++; details.push(storyLabel(story, index)); }
    });
    return { count, details };
  }

  async function createUntranslatedLanguageCopy(outputFolder, sourceDoc, languageName) {
    if (!outputFolder) throw new Error("Choose an output folder first.");
    if (!sourceDoc) sourceDoc = getActiveDocument();
    const safeLanguage = safeFilePart(languageName);
    const base = safeFilePart(getDocumentBaseName(sourceDoc));
    const fileName = `${base} - ${safeLanguage}.indd`;
    const outFile = await outputFolder.createFile(fileName, { overwrite: true });

    if (typeof sourceDoc.saveACopy === "function") await sourceDoc.saveACopy(outFile, true);
    else if (typeof sourceDoc.saveACopyAs === "function") await sourceDoc.saveACopyAs(outFile);
    else throw new Error("This InDesign host does not expose saveACopy/saveACopyAs to UXP.");

    return outFile;
  }

  async function saveCopyForLanguage(outputFolder, doc, languageName) {
    return await createUntranslatedLanguageCopy(outputFolder, doc, languageName);
  }

  async function openDocumentFile(file) {
    const indesignApp = requireInDesign();
    const attempts = [file];
    try { if (file && file.nativePath) attempts.push(file.nativePath); } catch (_) {}
    try { if (file && file.fsName) attempts.push(file.fsName); } catch (_) {}
    let lastError;
    for (const candidate of attempts) {
      try {
        const opened = indesignApp.open(candidate);
        return opened || indesignApp.activeDocument;
      } catch (err) { lastError = err; }
    }
    throw new Error(`Could not open translated copy: ${lastError && lastError.message ? lastError.message : lastError}`);
  }

  function activateDocument(doc) {
    if (!doc) return;
    try { if (typeof doc.activate === "function") doc.activate(); return; } catch (_) {}
    try { requireInDesign().activeDocument = doc; } catch (_) {}
  }

  async function saveDocument(doc) {
    if (!doc) doc = getActiveDocument();
    try { if (typeof doc.save === "function") return await doc.save(); } catch (err) { throw err; }
    throw new Error("This InDesign host does not expose document.save().");
  }

  async function closeDocument(doc, saveChanges) {
    if (!doc) return;
    const mod = indesignModule || {};
    const saveOptions = mod.SaveOptions || {};
    const yes = saveOptions.YES || saveOptions.yes || saveOptions.SAVE_CHANGES || saveOptions.saveChanges || 2036691744;
    const no = saveOptions.NO || saveOptions.no || saveOptions.NO_CHANGES || saveOptions.noChanges || 1852776480;
    const opt = saveChanges ? yes : no;
    try { if (typeof doc.close === "function") return await doc.close(opt); } catch (_) {}
    try { if (typeof doc.close === "function") return await doc.close(); } catch (_) {}
  }

  async function writeReportFiles(outputFolder, baseName, report) {
    if (!outputFolder) return [];
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    const safeBase = safeFilePart(baseName);
    const jsonFile = await outputFolder.createFile(`${safeBase} - translation-report-${stamp}.json`, { overwrite: true });
    await jsonFile.write(JSON.stringify(report, null, 2));
    const csvFile = await outputFolder.createFile(`${safeBase} - translation-report-${stamp}.csv`, { overwrite: true });
    await csvFile.write(reportToCsv(report));
    return [jsonFile, csvFile];
  }

  function reportToCsv(report) {
    const rows = [["language", "status", "units", "characters", "overset_count", "output_file", "errors"]];
    for (const item of report.languages || []) {
      rows.push([
        item.language,
        item.status,
        item.units,
        item.characters,
        item.oversetCount,
        item.outputFile || "",
        (item.errors || []).join(" | ")
      ]);
    }
    return rows.map(row => row.map(csvCell).join(",")).join("\n");
  }

  function csvCell(value) {
    const s = String(value == null ? "" : value);
    return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  }

  window.AIT_InDesignDom = {
    chooseOutputFolder,
    getActiveDocument,
    getDocumentBaseName,
    collectionToArray,
    extractUnits,
    extractUnitsFromDocument,
    restoreUnits,
    applyTranslations,
    verifyApplied,
    countOversetStories,
    createUntranslatedLanguageCopy,
    openDocumentFile,
    activateDocument,
    saveDocument,
    closeDocument,
    saveCopyForLanguage,
    writeReportFiles,
    safeFilePart,
    recompose
  };
})();
