(function () {
  const DEFAULT_MODELS = {
    deepl: ["prefer_quality_optimized", "quality_optimized", "latency_optimized"],
    openai: ["gpt-6.1-sol", "gpt-6.1-terra", "gpt-6-luna", "gpt-6-astra"],
    anthropic: ["claude-sonnet-5-5", "claude-opus-5-5", "claude-haiku-5-5", "claude-fable-5-1"],
    gemini: ["gemini-3.8-flash", "gemini-3.5-flash-lite", "gemini-3.1-pro-preview"],
    ollama: ["aya-expanse", "qwen2.5", "llama3.3", "mistral"],
    mock: ["mock-echo"]
  };

  const MODEL_LABELS = {
    "gpt-6.1-sol": "GPT-6.1 Sol - quality and cost",
    "gpt-6.1-terra": "GPT-6.1 Terra - fast and efficient",
    "gpt-6-luna": "GPT-6 Luna - high-volume translation",
    "gpt-6-astra": "GPT-6 Astra - highest capability",
    "gpt-5.6-sol": "GPT-5.6 Sol — highest quality",
    "gpt-5.6-terra": "GPT-5.6 Terra — balanced",
    "gpt-5.6-luna": "GPT-5.6 Luna — fastest"
  };

  function getDefaultModel(provider) {
    return (DEFAULT_MODELS[provider] || DEFAULT_MODELS.deepl)[0];
  }

  function normalizeModel(provider, model) {
    const requested = String(model || "").trim();
    // Keep explicit model choices: silently upgrading a saved model can change
    // both its price and request contract. New installs use the current defaults.
    return requested || getDefaultModel(provider);
  }

  function getModelLabel(provider, model) {
    return provider === "openai" && MODEL_LABELS[model] ? MODEL_LABELS[model] : model;
  }

  async function getOpenAIModels(apiKey, localOnly) {
    if (localOnly) throw new Error("Private mode is ON - refusing to contact OpenAI.");
    if (!String(apiKey || "").trim()) throw new Error("Enter your OpenAI API key in Settings first.");
    const res = await fetchWithRetry("https://api.openai.com/v1/models", {
      method: "GET", headers: { Authorization: `Bearer ${apiKey.trim()}` }
    }, 2, "OpenAI model list");
    const data = await res.json();
    if (!data || !Array.isArray(data.data)) throw new Error("OpenAI returned an invalid model list. Existing models were kept.");
    // The models endpoint provides IDs, not endpoint/capability metadata. Offer
    // likely text models, excluding known specialised families. Custom IDs remain
    // available for models not covered here; availability is not a capability test.
    const ids = data.data.map(item => item && item.id).filter(id =>
      typeof id === "string" && /^(?:gpt-|chat-latest(?:-|$)|o[1-9](?:-|$))/.test(id) &&
      !/(?:audio|realtime|transcribe|tts|image|search|deep-research|codex|computer-use|instruct|moderation|embedding)/i.test(id)
    );
    const models = Array.from(new Set(ids)).sort();
    if (!models.length) throw new Error("No text model IDs were returned for this key. Existing models were kept; you can enter a custom model ID.");
    return models;
  }

  const LOCAL_PROVIDERS = ["ollama", "mock"]; // run on this machine; no text leaves
  const DEEPL_MAX_TEXTS_PER_REQUEST = 50;
  const DEEPL_MAX_BODY_BYTES = 118 * 1024; // DeepL hard limit is 128 KiB; leave headroom.

  const DEEPL_TARGET_CODE_MAP = {
    "en": "EN-US",
    "en-us": "EN-US",
    "en-gb": "EN-GB",
    "pt": "PT-PT",
    "pt-br": "PT-BR",
    "es": "ES",
    "es-419": "ES-419",
    "zh": "ZH-HANS",
    "zh-tw": "ZH-HANT",
    "no": "NB"
  };

  const DEEPL_SOURCE_CODE_MAP = {
    "en": "EN",
    "en-us": "EN",
    "en-gb": "EN",
    "pt": "PT",
    "pt-br": "PT",
    "es-419": "ES",
    "zh": "ZH",
    "zh-tw": "ZH",
    "no": "NB"
  };

  async function translateBatch(providerName, input) {
    // Hard privacy gate — every translation path (batch, repair, quick) funnels
    // through here, so this is the one place that can guarantee "nothing leaves
    // the machine". If Private mode is on, refuse any cloud provider BEFORE the
    // provider object is even created — no network call can happen.
    if (input && input.localOnly && LOCAL_PROVIDERS.indexOf(providerName) === -1) {
      throw new Error(
        `Private mode is ON — refusing to send text to "${providerName}" (a cloud provider). ` +
        `Choose Ollama (on-device) or turn off Private mode in Settings.`
      );
    }
    if (!input || !Array.isArray(input.units)) throw new Error("Translation units are required.");
    const ids = input.units.map(unit => unit && unit.id != null ? String(unit.id) : "");
    if (ids.some(id => !id) || new Set(ids).size !== ids.length) {
      throw new Error("Every translation unit must have a unique, nonempty ID.");
    }
    if (!ids.length) return Object.create(null);
    const provider = createProvider(providerName);
    const translations = await provider.translateBatch(input);
    for (const unit of input.units) {
      const translated = translations[String(unit.id)];
      if (typeof translated !== "string" || !translated.trim()) throw new Error(`Provider returned an empty translation for ${unit.id}.`);
      const tokens = value => (String(value || "").match(/\[\[\[AIT_(?:PH_\d+|PI_\d+)\]\]\]/g) || []).sort();
      if (JSON.stringify(tokens(unit.preparedText)) !== JSON.stringify(tokens(translated))) {
        throw new Error(`Provider changed protected placeholders in ${unit.id}. No translation was accepted.`);
      }
    }
    return translations;
  }

  async function getDeepLUsage(apiKey) {
    if (!apiKey) throw new Error("Missing DeepL API key.");
    const url = `${deeplBaseUrl(apiKey)}/v2/usage`;
    const res = await fetchWithRetry(url, {
      method: "GET",
      headers: {
        "Authorization": `DeepL-Auth-Key ${apiKey}`
      }
    }, 2, "DeepL usage");
    return await res.json();
  }

  function createProvider(providerName) {
    if (providerName === "deepl") return new DeepLProvider();
    if (providerName === "openai") return new OpenAIProvider();
    if (providerName === "anthropic") return new AnthropicProvider();
    if (providerName === "gemini") return new GeminiProvider();
    if (providerName === "ollama") return new OllamaProvider();
    if (providerName === "mock") return new MockProvider();
    throw new Error(`Unknown translation provider: ${providerName}. Choose a provider in Settings.`);
  }

  function buildSystemPrompt(input) {
    const glossaryLines = window.AIT_Glossary.toPromptLines(input.glossary || []);
    const quality = input.qualityMode || "layout-tight";
    const fitRule = "LENGTH RULE: the printed layout is fixed, so the translation must occupy roughly the same space as the source. Stay within ±10% of the source character count for short blocks (headings, labels, callouts, sidebar lines, table cells) and within +15% for body paragraphs. Languages like Dutch, German, and French naturally run longer than English — counter this with tight idiomatic phrasing, shorter synonyms, and no filler words. Compact AND grammatically flawless; never telegraphic, never truncated.";
    const layoutRule = quality === "premium"
      ? `Use high-quality professional localization. Keep meaning complete, tone natural, terminology consistent. ${fitRule}`
      : quality === "balanced"
        ? `Balance accuracy and natural target-language flow. ${fitRule}`
        : fitRule;

    return [
      "You are a senior professional translator producing print-ready copy inside Adobe InDesign documents.",
      "Translate every supplied unit into the target language only.",
      "QUALITY BAR: the translation must read as if it was originally written by an educated native speaker of the target language — flawless grammar, natural word order, idiomatic phrasing, and a register, tone, and terminology that stay consistent across every unit of the document.",
      "Each translated unit must be a complete, grammatical rendering of its entire source unit, from the first word to the last. Never output a sentence fragment. Never drop, abbreviate, or cut words at the start or end of a unit.",
      "Mirror the capitalization style of each source unit: ALL CAPS stays ALL CAPS, Title Case maps to the target language's natural equivalent for headings, sentence case stays sentence case following the target language's own capitalization rules (e.g. German noun capitalization, French accent rules).",
      "Use correct target-language punctuation and typographic conventions (quotation marks, decimal separators, spacing before punctuation where the language requires it).",
      "Never sacrifice grammatical correctness or natural phrasing for brevity.",
      "These units are paragraphs from one continuous document (headings, body copy, bullet list items). Translate each so it reads coherently in that role: headings like headings, bullets like parallel bullets with consistent grammatical form.",
      "Return valid JSON only. No markdown, no comments, no explanations, no surrounding text.",
      "The returned JSON must contain exactly one translated text for every input id.",
      "Never merge units, split units, drop units, duplicate source text, or leave source language attached before/after the translation.",
      "Do not copy the source text unless it is a brand name, product code, URL, email, unit, placeholder, or a term the glossary says to keep.",
      "Preserve IDs exactly. Preserve placeholders like [[[AIT_PH_0000]]] exactly.",
      "Preserve XML-like run tags and every attribute exactly, such as <r id=\"0\">...</r> and <r id=\"1\" link=\"true\">...</r>; translate only the human text inside them.",
      "A run marked link=\"true\" is clickable text. It must remain nonempty and contain a natural target-language anchor; never merge it into another run or move its words outside that run.",
      "Preserve manual line breaks, bullet/numbering intent, units, product codes, URLs, emails, variables, and bracketed tokens.",
      "Use the user context and glossary as mandatory terminology guidance when terms appear.",
      layoutRule,
      `Industry/tone: ${input.industry || "General business"}.`,
      input.context ? `Client/project context: ${input.context}` : "",
      glossaryLines ? `Glossary, mandatory when terms appear:\n${glossaryLines}` : ""
    ].filter(Boolean).join("\n");
  }

  function buildUserPrompt(input) {
    return JSON.stringify({
      task: "translate_indesign_units",
      source_language: input.sourceLanguageName || input.sourceLang || "auto detect",
      target_language: `${input.targetLanguage.name} (${input.targetLanguage.code})`,
      contract: {
        return_json_only: true,
        required_shape: { translations: [{ id: "same id as input", text: "target language translation only" }] },
        must_return_all_ids: true,
        preserve_placeholders_exactly: true,
        preserve_hyperlink_runs: true,
        no_source_language_duplicates: true
      },
      units: input.units.map(u => ({ id: u.id, text: u.preparedText }))
    });
  }

  function parseTranslations(raw, expectedIds) {
    const text = window.AIT_Protectors.stripFences(raw);
    let parsed;
    try { parsed = JSON.parse(text); }
    catch (err) {
      const first = text.indexOf("{");
      const last = text.lastIndexOf("}");
      if (first >= 0 && last > first) parsed = JSON.parse(text.slice(first, last + 1));
      else throw new Error("Provider did not return valid JSON.");
    }
    const arr = Array.isArray(parsed) ? parsed : parsed && parsed.translations;
    if (!Array.isArray(arr)) throw new Error("Provider JSON missing translations array.");
    const expected = new Set(expectedIds.map(String));
    const map = Object.create(null);
    for (const item of arr) {
      if (!item || item.id == null || typeof item.text !== "string" || !item.text.trim()) {
        throw new Error("Provider returned an invalid or empty translation unit.");
      }
      const id = String(item.id);
      if (!expected.has(id)) throw new Error(`Provider returned an unexpected translated unit ID: ${id}.`);
      if (Object.prototype.hasOwnProperty.call(map, id)) throw new Error(`Provider returned duplicate translated unit ID: ${id}.`);
      map[id] = item.text;
    }
    const missing = expectedIds.filter(id => !Object.prototype.hasOwnProperty.call(map, String(id)));
    if (missing.length) throw new Error(`Provider JSON missing translated unit IDs: ${missing.slice(0, 8).join(", ")}${missing.length > 8 ? "..." : ""}`);
    return map;
  }

  function extractOpenAIText(data) {
    if (data.status && data.status !== "completed") {
      const reason = data.incomplete_details && data.incomplete_details.reason;
      throw new Error(`OpenAI translation ${data.status}${reason ? ` (${reason})` : ""}. No partial translation was accepted.`);
    }
    if (typeof data.output_text === "string") return data.output_text;
    const chunks = [];
    for (const item of data.output || []) {
      for (const part of item.content || []) {
        if (part.type === "refusal") throw new Error("OpenAI declined this translation. No partial translation was accepted.");
        if ((part.type === "output_text" || part.type === "text") && part.text) chunks.push(part.text);
      }
    }
    return chunks.join("\n");
  }

  async function fetchWithRetry(url, options, retries, label, cancelled) {
    let lastError;
    for (let attempt = 0; attempt <= retries; attempt++) {
      if (typeof cancelled === "function" && cancelled()) throw new Error("Batch cancelled by user.");
      let res;
      try {
        res = await fetchWithTimeout(url, options, label);
      } catch (err) {
        lastError = err;
        if (attempt === retries) throw err;
      }
      if (res) {
        if (res.ok) return res;
        const body = await res.text().catch(() => "");
        const retryable = [408, 409, 425, 429, 500, 502, 503, 504, 529].includes(res.status);
        lastError = new Error(`${label} request failed (${res.status}): ${body.slice(0, 1000)}`);
        // Keep permanent failures outside the network-error catch. An invalid
        // key, model or parameter must fail once instead of retrying six times.
        if (!retryable || attempt === retries) throw lastError;
      }
      if (typeof cancelled === "function" && cancelled()) throw new Error("Batch cancelled by user.");
      const retryAfter = res && res.headers && res.headers.get ? res.headers.get("retry-after") : null;
      const retryMs = retryAfter == null ? 0 : (/^\d+(?:\.\d+)?$/.test(retryAfter)
        ? Number(retryAfter) * 1000 : Math.max(0, Date.parse(retryAfter) - Date.now()));
      const wait = Math.max(Math.min(60000, retryMs || 0), Math.min(16000, 900 * Math.pow(2, attempt)) + Math.round(Math.random() * 400));
      await sleep(wait);
    }
    throw lastError;
  }

  async function fetchWithTimeout(url, options, label) {
    const controller = typeof AbortController !== "undefined" ? new AbortController() : null;
    let timer;
    const request = controller ? Object.assign({}, options, { signal: controller.signal }) : options;
    try {
      return await Promise.race([
        fetch(url, request),
        new Promise((_, reject) => {
          timer = setTimeout(() => {
            if (controller) controller.abort();
            reject(new Error(`${label} request timed out after 120 seconds. Check the connection and provider status.`));
          }, 120000);
        })
      ]);
    } finally {
      clearTimeout(timer);
    }
  }

  function translationSchema(input) {
    return {
      type: "object", additionalProperties: false, required: ["translations"],
      properties: {
        translations: {
          type: "array", items: {
            type: "object", additionalProperties: false, required: ["id", "text"],
            properties: { id: { type: "string", enum: input.units.map(unit => String(unit.id)) }, text: { type: "string" } }
          }
        }
      }
    };
  }

  function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

  function normalizeCode(code) {
    return String(code || "").trim().replace(/_/g, "-");
  }

  function toDeepLTargetCode(language) {
    const code = normalizeCode(language && language.code);
    if (!code || code === "auto") throw new Error("DeepL needs a concrete target language.");
    return DEEPL_TARGET_CODE_MAP[code.toLowerCase()] || code.toUpperCase();
  }

  function toDeepLSourceCode(input) {
    const code = normalizeCode(input && input.sourceLang);
    if (!code || code === "auto") return "";
    return DEEPL_SOURCE_CODE_MAP[code.toLowerCase()] || code.toUpperCase();
  }

  function getDeepLModelType(model) {
    const allowed = DEFAULT_MODELS.deepl;
    return allowed.indexOf(model) !== -1 ? model : getDefaultModel("deepl");
  }

  function deeplBaseUrl(apiKey) {
    return String(apiKey || "").trim().toLowerCase().endsWith(":fx")
      ? "https://api-free.deepl.com"
      : "https://api.deepl.com";
  }

  function byteLength(value) {
    const text = String(value == null ? "" : value);
    if (typeof TextEncoder !== "undefined") return new TextEncoder().encode(text).length;
    return unescape(encodeURIComponent(text)).length;
  }

  function buildDeepLContext(input) {
    const lines = [];
    const quality = input.qualityMode || "layout-tight";
    lines.push("Translate for print-ready Adobe InDesign copy. Keep the meaning complete, natural, and concise enough to fit the original layout.");
    if (quality === "premium") lines.push("Use polished professional localization with consistent terminology and tone.");
    else if (quality === "balanced") lines.push("Balance accuracy, natural target-language flow, and compact phrasing.");
    else lines.push("Prefer compact idiomatic phrasing for headings, labels, callouts, table cells, and fixed-layout text.");
    if (input.industry) lines.push(`Industry/tone: ${input.industry}.`);
    if (input.context) lines.push(`Project context: ${input.context}`);
    const glossaryLines = window.AIT_Glossary.toPromptLines(input.glossary || []);
    if (glossaryLines) lines.push(`Terminology guidance:\n${glossaryLines}`);
    return lines.join("\n").slice(0, 10000);
  }

  function tokenTagsToXml(text) {
    return String(text == null ? "" : text)
      .replace(/\[\[\[(AIT_PH_\d{4}|AIT_PI_\d+)\]\]\]/g, '<ph data-id="$1"/>');
  }

  function xmlTokenTagsToPlaceholders(text) {
    return String(text == null ? "" : text)
      .replace(/<ph\b[^>]*(?:data-id|id)=["'](AIT_(?:PH_\d{4}|PI_\d+))["'][^>]*>[\s\S]*?<\/ph>/gi, "[[[$1]]]")
      .replace(/<ph\b[^>]*(?:data-id|id)=["'](AIT_(?:PH_\d{4}|PI_\d+))["'][^>]*\/>/gi, "[[[$1]]]");
  }

  function stripDeepLWrapper(text) {
    const source = String(text == null ? "" : text).trim();
    const match = /^<ait\b[^>]*>([\s\S]*)<\/ait>$/i.exec(source);
    if (match) return match[1];
    return source.replace(/^<ait\b[^>]*>/i, "").replace(/<\/ait>$/i, "");
  }

  function toDeepLText(unit) {
    const P = window.AIT_Protectors;
    const raw = unit && unit.mode === "tagged-runs"
      ? String(unit.preparedText || "")
      : P.escapeXmlText(unit && unit.preparedText || "");
    return `<ait>${tokenTagsToXml(raw)}</ait>`;
  }

  function fromDeepLText(unit, raw) {
    const P = window.AIT_Protectors;
    let text = xmlTokenTagsToPlaceholders(stripDeepLWrapper(raw));
    if (!unit || unit.mode !== "tagged-runs") text = P.unescapeXmlText(text);
    return text;
  }

  function buildDeepLPayload(input, texts, targetLang, sourceLang, context, modelType) {
    const payload = {
      text: texts,
      target_lang: targetLang,
      model_type: modelType,
      context,
      tag_handling: "xml",
      tag_handling_version: "v2",
      split_sentences: "nonewlines",
      preserve_formatting: true,
      ignore_tags: ["ph"],
      show_billed_characters: true
    };
    if (sourceLang) payload.source_lang = sourceLang;
    return payload;
  }

  function makeDeepLBatches(input, items, targetLang, sourceLang, context, modelType) {
    const batches = [];
    let current = [];
    for (const item of items) {
      const candidate = current.concat(item);
      const body = JSON.stringify(buildDeepLPayload(input, candidate.map(i => i.text), targetLang, sourceLang, context, modelType));
      if (current.length && (candidate.length > DEEPL_MAX_TEXTS_PER_REQUEST || byteLength(body) > DEEPL_MAX_BODY_BYTES)) {
        batches.push(current);
        current = [item];
      } else {
        current = candidate;
      }
      const singleBody = JSON.stringify(buildDeepLPayload(input, current.map(i => i.text), targetLang, sourceLang, context, modelType));
      if (current.length === 1 && byteLength(singleBody) > DEEPL_MAX_BODY_BYTES) {
        throw new Error(`DeepL request unit ${item.unit.id} is too large for the 128 KiB API request limit.`);
      }
    }
    if (current.length) batches.push(current);
    return batches;
  }

  class DeepLProvider {
    async translateBatch(input) {
      if (!input.apiKey) throw new Error("Missing DeepL API key.");
      const targetLang = toDeepLTargetCode(input.targetLanguage);
      const sourceLang = toDeepLSourceCode(input);
      const modelType = getDeepLModelType(input.model);
      const context = buildDeepLContext(input);
      const items = input.units.map(unit => ({ unit, text: toDeepLText(unit) }));
      const batches = makeDeepLBatches(input, items, targetLang, sourceLang, context, modelType);
      const map = {};
      const url = `${deeplBaseUrl(input.apiKey)}/v2/translate`;

      for (const batch of batches) {
        const payload = buildDeepLPayload(input, batch.map(item => item.text), targetLang, sourceLang, context, modelType);
        const body = JSON.stringify(payload);
        const requestBytes = byteLength(body);
        const startedAt = Date.now();
        if (typeof input.providerLog === "function") {
          input.providerLog(`DeepL POST /v2/translate: ${batch.length} document text unit(s), ${requestBytes.toLocaleString()} request bytes.`);
        }
        const res = await fetchWithRetry(url, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `DeepL-Auth-Key ${input.apiKey}`
          },
          body
        }, 5, "DeepL", input.cancelled);
        const data = await res.json();
        const elapsedMs = Date.now() - startedAt;
        const translations = data.translations || [];
        if (translations.length !== batch.length) {
          throw new Error(`DeepL returned ${translations.length} translation(s) for ${batch.length} text unit(s).`);
        }
        // DeepL reports billed_characters on each translation object (when
        // show_billed_characters=true), NOT at the top level of the response.
        // Sum across the batch; fall back to a top-level field only if a future
        // API version ever puts one there.
        const sawBilledCharacters = translations.some(t => t && typeof t.billed_characters === "number")
          || typeof data.billed_characters === "number";
        const billedCharacters = translations.reduce(
          (sum, t) => sum + (t && typeof t.billed_characters === "number" ? t.billed_characters : 0),
          typeof data.billed_characters === "number" ? data.billed_characters : 0
        );
        if (typeof input.providerLog === "function") {
          const billed = sawBilledCharacters
            ? `, ${billedCharacters.toLocaleString()} billed source characters`
            : ", billed source characters not included in this response";
          input.providerLog(`DeepL request accepted: ${batch.length} document text unit(s)${billed}, ${elapsedMs.toLocaleString()} ms.`);
        }
        if (typeof input.deepLRequestAccepted === "function") {
          input.deepLRequestAccepted({
            textUnits: batch.length,
            billedCharacters: sawBilledCharacters ? billedCharacters : null,
            targetLang,
            elapsedMs,
            requestBytes,
            modelType
          });
        }
        translations.forEach((item, index) => {
          map[batch[index].unit.id] = fromDeepLText(batch[index].unit, item.text || "");
        });
      }
      return map;
    }
  }

  class OpenAIProvider {
    async translateBatch(input) {
      if (!input.apiKey) throw new Error("Missing OpenAI API key.");
      const system = buildSystemPrompt(input);
      const user = buildUserPrompt(input);
      const model = normalizeModel("openai", input.model || getDefaultModel("openai"));
      const payload = {
        model,
        store: false,
        text: { format: { type: "json_schema", name: "translation_units", strict: true, schema: translationSchema(input) } },
        input: [
          { role: "system", content: [{ type: "input_text", text: system }] },
          { role: "user", content: [{ type: "input_text", text: user }] }
        ],
        max_output_tokens: Math.min(16000, Math.max(2048, Math.round(input.units.reduce((s, u) => s + String(u.preparedText || "").length, 0) * 2.2)))
      };
      // Astra and Sol 6.1 require low or higher; Terra/Luna support none.
      // Keep reasoning explicit so translation does not inherit costly defaults.
      if (/^gpt-(?:6-astra|6\.1-sol)(?:-|$)/i.test(model)) payload.reasoning = { effort: "low" };
      else if (/^gpt-(?:6(?:\.1-terra|-sol|-luna)|5\.6)(?:-|$)/i.test(model)) payload.reasoning = { effort: "none" };
      else if (/^gpt-4/i.test(model)) payload.temperature = 0.1;

      // If the API still rejects a parameter for this model, strip it and retry.
      for (let attempt = 0; attempt < 4; attempt++) {
        try {
          const res = await fetchWithRetry("https://api.openai.com/v1/responses", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${input.apiKey}`
            },
            body: JSON.stringify(payload)
          }, 5, "OpenAI", input.cancelled);
          const data = await res.json();
          return parseTranslations(extractOpenAIText(data), input.units.map(u => u.id));
        } catch (err) {
          const message = err && err.message ? err.message : "";
          const unsupported = /Unsupported parameter: ['"]([^'"]+)['"]/i.exec(message);
          const optional = unsupported && unsupported[1].split(".")[0];
          const rejectedEffort = /OpenAI request failed \(400\)/.test(message) &&
            /reasoning[._]effort/i.test(message) && /unsupported|not supported|invalid value/i.test(message);
          if (rejectedEffort && payload.reasoning) {
            delete payload.reasoning;
            continue;
          }
          if (optional && ["temperature", "reasoning"].includes(optional) && Object.prototype.hasOwnProperty.call(payload, optional)) {
            delete payload[optional];
            continue;
          }
          throw err;
        }
      }
      throw new Error("OpenAI request failed: could not find a parameter set this model accepts.");
    }
  }

  class AnthropicProvider {
    async translateBatch(input) {
      if (!input.apiKey) throw new Error("Missing Anthropic API key.");
      // No temperature: sampling parameters are removed on claude-opus-4-7+ (400 if sent).
      const payload = {
        model: input.model || getDefaultModel("anthropic"),
        max_tokens: Math.min(16000, Math.max(2048, Math.round(input.units.reduce((s, u) => s + String(u.preparedText || "").length, 0) * 2.2))),
        system: buildSystemPrompt(input),
        messages: [{ role: "user", content: buildUserPrompt(input) }]
      };
      const res = await fetchWithRetry("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": input.apiKey,
          "anthropic-version": "2023-06-01"
        },
        body: JSON.stringify(payload)
      }, 5, "Anthropic", input.cancelled);
      const data = await res.json();
      if (data.stop_reason && data.stop_reason !== "end_turn") {
        throw new Error(`Anthropic translation stopped (${data.stop_reason}). No partial translation was accepted.`);
      }
      const raw = (data.content || []).filter(p => !p.type || p.type === "text").map(p => p.text || "").join("\n");
      return parseTranslations(raw, input.units.map(u => u.id));
    }
  }

  class GeminiProvider {
    async translateBatch(input) {
      if (!input.apiKey) throw new Error("Missing Gemini API key.");
      const modelId = input.model || getDefaultModel("gemini");
      const model = encodeURIComponent(modelId);
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;
      const payload = {
        systemInstruction: { parts: [{ text: buildSystemPrompt(input) }] },
        contents: [{ role: "user", parts: [{ text: buildUserPrompt(input) }] }],
        generationConfig: { responseMimeType: "application/json", responseJsonSchema: translationSchema(input) }
      };
      // Current Gemini models reject sampling overrides. Keep older manually
      // selected models compatible while using supported low thinking on 3+.
      if (/^gemini-[34](?:\.|-)/i.test(modelId)) payload.generationConfig.thinkingConfig = { thinkingLevel: "LOW" };
      else payload.generationConfig.temperature = 0.1;
      const res = await fetchWithRetry(url, {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-goog-api-key": input.apiKey },
        body: JSON.stringify(payload)
      }, 5, "Gemini", input.cancelled);
      const data = await res.json();
      if (data.promptFeedback && data.promptFeedback.blockReason) {
        throw new Error(`Gemini blocked this translation (${data.promptFeedback.blockReason}).`);
      }
      const candidate = data.candidates && data.candidates[0];
      if (!candidate) throw new Error("Gemini returned no translation candidate.");
      if (candidate.finishReason && candidate.finishReason !== "STOP") {
        throw new Error(`Gemini translation stopped (${candidate.finishReason}). No partial translation was accepted.`);
      }
      const raw = ((candidate.content && candidate.content.parts) || []).filter(p => !p.thought).map(p => p.text || "").join("\n");
      return parseTranslations(raw, input.units.map(u => u.id));
    }
  }

  // Local models via Ollama (https://github.com/ollama/ollama) — free, runs on
  // this machine, OpenAI-compatible API on localhost:11434. No API key needed.
  class OllamaProvider {
    async translateBatch(input) {
      const payload = {
        model: input.model || getDefaultModel("ollama"),
        stream: false,
        response_format: { type: "json_object" },
        temperature: 0.1,
        messages: [
          { role: "system", content: buildSystemPrompt(input) },
          { role: "user", content: buildUserPrompt(input) }
        ]
      };
      let res;
      try {
        res = await fetchWithRetry("http://127.0.0.1:11434/v1/chat/completions", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        }, 2, "Ollama", input.cancelled);
      } catch (err) {
        const msg = err && err.message ? err.message : String(err);
        if (/failed|network|fetch|refused|ECONN/i.test(msg)) {
          throw new Error(`Could not reach Ollama at http://127.0.0.1:11434 — is Ollama installed and running, and the model pulled (e.g. "ollama pull ${payload.model}")? (${msg})`);
        }
        throw err;
      }
      const data = await res.json();
      const raw = data.choices && data.choices[0] && data.choices[0].message ? data.choices[0].message.content : "";
      return parseTranslations(raw, input.units.map(u => u.id));
    }
  }

  class MockProvider {
    async translateBatch(input) {
      await sleep(120);
      const map = {};
      for (const unit of input.units) {
        map[unit.id] = `[${input.targetLanguage.name}] ${unit.preparedText}`;
      }
      return map;
    }
  }

  function estimateCost(units, selectedLanguages) {
    const chars = units.reduce((sum, unit) => sum + String(unit.originalText || "").length, 0);
    const approxTokensPerLanguage = Math.ceil(chars / 3.6);
    const totalApproxTokens = approxTokensPerLanguage * Math.max(1, selectedLanguages.length);
    return { chars, approxTokensPerLanguage, totalApproxTokens };
  }

  window.AIT_Providers = {
    DEFAULT_MODELS,
    getDefaultModel,
    normalizeModel,
    getModelLabel,
    getOpenAIModels,
    getDeepLUsage,
    translateBatch,
    estimateCost,
    buildSystemPrompt
  };
})();
