# FormatFlow Translate 3.3.4 development preview

Prepared 4 November 2026. Includes the earlier saved-key fix and translation
close/reopen mitigation.

## Interactive PDF in Batch Export

The Export format menu now offers **Adobe PDF (Print)** and **Adobe PDF
(Interactive)** alongside PNG and JPEG.

Choose **Adobe PDF (Interactive)** for InDesign's native interactive PDF export.
The **Include forms, buttons and media** checkbox defaults to on. Turning it off
exports their appearance only. Other interactive export settings follow the
current InDesign configuration. Each document produces one PDF; viewers are
not opened automatically for every batch item.

Print PDF presets remain in the print options panel. They are not sent to the
interactive exporter. Interactive export failure is reported directly without
falling back to print PDF. Any interactive preferences changed for the export
are restored afterward, including when export fails.

For the InDesign close-reference safety mitigation, documents opened from the
file chooser are left open after batch export for review, as translated copies
already are. The original documents are not saved or edited by Batch Export.

## Use

Reload FormatFlow in Adobe UXP Developer Tool and confirm **3.3.4** in About.
Open **Batch Export**, choose **Adobe PDF (Interactive)** under **Export format**,
then select the source documents and output folder and export.

The automatic PDF alongside translation remains a print PDF. Use Batch Export
on the open translated documents to create interactive PDFs.

## Verification

Automated checks cover the format switch, PDF filenames and routing for open
and chosen files, interactive-element inclusion and appearance-only mode,
native enum and numeric enum compatibility, preference restoration on success
and failure, no print fallback, and existing print/PNG routes.

Adobe objects are simulated in these checks. Live InDesign export and inspection
of the resulting interactive PDF remain to be performed.

## Adobe API references

- https://developer.adobe.com/indesign/uxp/dom/api/e/export-format/
- https://developer.adobe.com/indesign/uxp/dom/api/i/interactive-pdf-export-preference/
- https://developer.adobe.com/indesign/uxp/dom/api/i/interactive-pdf-interactive-elements-options/
