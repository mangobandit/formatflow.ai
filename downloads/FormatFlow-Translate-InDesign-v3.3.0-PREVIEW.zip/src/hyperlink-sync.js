(function () {
  "use strict";

  const SNAPSHOT_VERSION = 1;
  const GBS_PROFILE_ID = "gbs-opex-a4-english-v1";
  const GBS_SOURCE_DOCUMENT = "GBS OpEx Playbook A4 - English.indd";
  const GBS_URL_LINK_COUNT = 59;
  const NOTHING = 1851876449;

  // These rules are deliberately narrow. They are not general translation
  // guesses: each one is a measured repair for the fingerprinted English GBS
  // OpEx source document, and is enabled only for target language code `de`.
  const GBS_GERMAN_RULES = {
    "here 60": {
      pageName: "16",
      pageOffset: 15,
      sourceText: "here",
      targetText: "QR-Code",
      grepPattern: "QR-Code(?!s)",
      url: "https://onegreif.ideascale.com/c/bdp/idea/92513"
    },
    Website: {
      pageName: "16",
      pageOffset: 15,
      sourceText: "this link",
      targetText: "diesem Link",
      grepPattern: "diesem\\s+Link",
      url: "https://onegreif.ideascale.com/a/workspace/login"
    },
    "Global OpEx Team": {
      pageName: "16",
      pageOffset: 15,
      sourceText: "Global OpEx Team",
      targetText: "Globalen OpEx-Teams",
      grepPattern: "Globalen\\s+OpEx-Teams",
      url: "https://itadministrationinfrastruct.sharepoint.com/sites/gbs_oe/SitePages/Home.aspx"
    },
    "Best Demonstrated Practices": {
      pageName: "18",
      pageOffset: 17,
      sourceText: "Best Demonstrated Practices",
      targetText: "Best Demonstrated Practices",
      grepPattern: "Best\\s+Demonstrated\\s+Practices",
      url: "https://onegreif.ideascale.com/c/"
    },
    "OPEx Webpage": {
      pageName: "18",
      pageOffset: 17,
      sourceText: "OpEx Webpage",
      targetText: "OpEx-Webseite",
      grepPattern: "OpEx-Webseite",
      url: "https://itadministrationinfrastruct.sharepoint.com/sites/gbs_oe"
    }
  };

  function clean(value) {
    if (value === null || value === undefined) return "";
    let text = "";
    try { text = String(value); } catch (_) { return ""; }
    return text.replace(/[\t\r\n]+/g, " ").replace(/\s+/g, " ").trim();
  }

  function isValid(value) {
    if (!value) return false;
    try { return value.isValid !== false; } catch (_) { return false; }
  }

  function collectionLength(collection) {
    if (!collection) return 0;
    try {
      if (typeof collection.length === "number") return collection.length;
      if (typeof collection.count === "function") return collection.count();
    } catch (_) {}
    return 0;
  }

  // UXP collection proxies do not support collection[i]. Prefer the shared DOM
  // helper, getElements/everyItem, and finally item(i).
  function collectionToArray(collection) {
    if (!collection) return [];
    if (Array.isArray(collection)) return collection.slice();
    try {
      if (window.AIT_InDesignDom && typeof window.AIT_InDesignDom.collectionToArray === "function") {
        return window.AIT_InDesignDom.collectionToArray(collection).filter(Boolean);
      }
    } catch (_) {}
    try {
      if (typeof collection.getElements === "function") return collection.getElements().filter(Boolean);
    } catch (_) {}
    try {
      if (typeof collection.everyItem === "function") return collection.everyItem().getElements().filter(Boolean);
    } catch (_) {}
    const result = [];
    const length = collectionLength(collection);
    for (let index = 0; index < length; index++) {
      try {
        const item = collection.item(index);
        if (item) result.push(item);
      } catch (_) {}
    }
    return result;
  }

  function firstCollectionItem(collection) {
    if (!collection) return null;
    if (Array.isArray(collection)) return collection[0] || null;
    try {
      if (typeof collection.item === "function" && collectionLength(collection) > 0) {
        return collection.item(0);
      }
    } catch (_) {}
    const items = collectionToArray(collection);
    return items[0] || null;
  }

  function destinationUrl(link) {
    try {
      if (!isValid(link) || !isValid(link.destination)) return "";
      const url = link.destination.destinationURL;
      return url === null || url === undefined ? "" : clean(url);
    } catch (_) {
      return "";
    }
  }

  function destinationIsValid(link) {
    try { return isValid(link) && isValid(link.destination); }
    catch (_) { return false; }
  }

  function destinationKind(link) {
    try {
      const destination = link.destination;
      if (!destination) return "unknown";
      if (destination.constructorName) return String(destination.constructorName);
      if (destination.constructor && destination.constructor.name) return String(destination.constructor.name);
    } catch (_) {}
    return "internal";
  }

  function copyBounds(value) {
    try {
      if (!value || typeof value.length !== "number" || value.length < 4) return null;
      const result = [Number(value[0]), Number(value[1]), Number(value[2]), Number(value[3])];
      return result.every(Number.isFinite) ? result : null;
    } catch (_) {
      return null;
    }
  }

  function pageData(page) {
    const result = { page: page || null, pageName: "", pageOffset: -1 };
    if (!isValid(page)) return result;
    try { result.pageName = String(page.name); } catch (_) {}
    try {
      const offset = Number(page.documentOffset);
      if (Number.isFinite(offset)) result.pageOffset = offset;
    } catch (_) {}
    return result;
  }

  function sourceInfo(link) {
    const result = {
      healthy: false,
      reason: "invalid hyperlink",
      sourceKind: "unknown",
      source: null,
      text: null,
      contents: "",
      page: null,
      pageName: "",
      pageOffset: -1,
      frameBounds: null
    };
    if (!isValid(link)) return result;

    let source = null;
    try { source = link.source; } catch (_) {}
    result.source = source;
    if (!isValid(source)) {
      result.reason = "invalid hyperlink source";
      return result;
    }

    let text = null;
    try { text = source.sourceText; } catch (_) {}
    if (isValid(text)) {
      result.sourceKind = "text";
      result.text = text;
      try { result.contents = clean(text.contents); } catch (_) {}
      if (!result.contents) {
        result.reason = "empty hyperlink text source";
        return result;
      }
      let frame = null;
      try { frame = firstCollectionItem(text.parentTextFrames); } catch (_) {}
      if (!isValid(frame)) {
        result.reason = "hyperlink text source has no parent text frame";
        return result;
      }
      let page = null;
      try { page = frame.parentPage; } catch (_) {}
      if (!isValid(page)) {
        result.reason = "hyperlink text source is not on a page";
        return result;
      }
      const location = pageData(page);
      result.page = location.page;
      result.pageName = location.pageName;
      result.pageOffset = location.pageOffset;
      try { result.frameBounds = copyBounds(frame.geometricBounds); } catch (_) {}
      result.healthy = true;
      result.reason = "";
      return result;
    }

    let pageItem = null;
    try { pageItem = source.sourcePageItem; } catch (_) {}
    if (isValid(pageItem)) {
      result.sourceKind = "pageItem";
      let page = null;
      try { page = pageItem.parentPage; } catch (_) {}
      if (!isValid(page)) {
        result.reason = "hyperlink page-item source is not on a page";
        return result;
      }
      const location = pageData(page);
      result.page = location.page;
      result.pageName = location.pageName;
      result.pageOffset = location.pageOffset;
      try { result.frameBounds = copyBounds(pageItem.geometricBounds); } catch (_) {}
      result.healthy = true;
      result.reason = "";
      return result;
    }

    result.reason = "unsupported or invalid hyperlink source";
    return result;
  }

  function pageMatches(page, expectedName, expectedOffset) {
    if (!isValid(page)) return false;
    try {
      if (expectedName !== null && expectedName !== undefined && String(page.name) === String(expectedName)) {
        return true;
      }
    } catch (_) {}
    try {
      if (Number.isFinite(Number(expectedOffset)) && Number(page.documentOffset) === Number(expectedOffset)) {
        return true;
      }
    } catch (_) {}
    return false;
  }

  function sourceIsHealthyForMeta(link, meta) {
    const info = sourceInfo(link);
    return info.healthy &&
      info.sourceKind === meta.sourceKind &&
      pageMatches(info.page, meta.pageName, meta.pageOffset);
  }

  function copyPrimitive(value) {
    if (value === null || typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
      return value;
    }
    if (Array.isArray(value)) {
      const copied = value.slice(0, 8);
      return copied.every(item => item === null || ["string", "number", "boolean"].includes(typeof item))
        ? copied
        : undefined;
    }
    return undefined;
  }

  function captureAppearance(link) {
    const result = {};
    ["label", "visible", "highlight", "width", "borderStyle", "borderColor"].forEach(property => {
      try {
        const value = copyPrimitive(link[property]);
        if (value !== undefined) result[property] = value;
      } catch (_) {}
    });
    return result;
  }

  function applyAppearance(link, appearance) {
    if (!link || !appearance) return;
    ["label", "visible", "highlight", "width", "borderStyle", "borderColor"].forEach(property => {
      if (!Object.prototype.hasOwnProperty.call(appearance, property)) return;
      try { link[property] = appearance[property]; } catch (_) {}
    });
  }

  function exactKey(value) {
    return "$" + String(value);
  }

  function foldedKey(value) {
    return "$" + String(value).toLocaleLowerCase();
  }

  function buildExactLinkMap(doc) {
    const byName = Object.create(null);
    const folded = Object.create(null);
    const duplicates = [];
    const links = collectionToArray(doc && doc.hyperlinks);
    links.forEach(link => {
      let name = "";
      try { name = String(link.name); } catch (_) { name = ""; }
      const key = exactKey(name);
      if (Object.prototype.hasOwnProperty.call(byName, key)) duplicates.push(name);
      else byName[key] = link;
      const lower = foldedKey(name);
      if (!folded[lower]) folded[lower] = [];
      folded[lower].push(name);
    });
    if (duplicates.length) {
      throw new Error("Duplicate exact-case hyperlink names: " + duplicates.join(", "));
    }
    return { byName, folded, links };
  }

  function inspect(doc) {
    const report = {
      ok: true,
      total: 0,
      urlLinks: 0,
      healthyUrlLinks: 0,
      invalidUrlLinks: 0,
      nonUrlLinks: 0,
      duplicateNames: [],
      issues: []
    };
    const links = collectionToArray(doc && doc.hyperlinks);
    report.total = links.length;
    const seen = Object.create(null);
    links.forEach(link => {
      let name = "";
      try { name = String(link.name); } catch (_) { name = ""; }
      const key = exactKey(name);
      if (seen[key]) report.duplicateNames.push(name);
      seen[key] = true;
      const url = destinationUrl(link);
      if (!url) {
        report.nonUrlLinks++;
        return;
      }
      report.urlLinks++;
      const info = sourceInfo(link);
      if (info.healthy) report.healthyUrlLinks++;
      else {
        report.invalidUrlLinks++;
        report.issues.push({ name, reason: info.reason || "invalid hyperlink source" });
      }
    });
    report.duplicateNames.forEach(name => {
      report.issues.push({ name, reason: "duplicate exact-case hyperlink name" });
    });
    report.ok = report.invalidUrlLinks === 0 && report.duplicateNames.length === 0;
    return report;
  }

  function snapshotLink(link) {
    let name = "";
    try { name = String(link.name); } catch (_) {}
    const url = destinationUrl(link);
    const info = sourceInfo(link);
    return {
      name,
      url,
      sourceKind: info.sourceKind,
      pageName: info.pageName,
      pageOffset: info.pageOffset,
      frameBounds: info.frameBounds,
      sourceContents: info.contents,
      appearance: captureAppearance(link)
    };
  }

  function snapshotInternalLink(link) {
    const meta = snapshotLink(link);
    delete meta.url;
    delete meta.appearance;
    meta.destinationKind = destinationKind(link);
    return meta;
  }

  function assertSnapshot(snapshot) {
    if (!snapshot || snapshot.version !== SNAPSHOT_VERSION || !Array.isArray(snapshot.links)) {
      throw new Error("Invalid hyperlink snapshot.");
    }
    const internalLinks = snapshot.internalLinks === undefined ? [] : snapshot.internalLinks;
    if (!Array.isArray(internalLinks)) throw new Error("Invalid internal hyperlink snapshot.");
    if (snapshot.externalCount !== undefined && snapshot.externalCount !== snapshot.links.length) {
      throw new Error("External hyperlink snapshot count does not match its metadata.");
    }
    if (snapshot.internalCount !== undefined && snapshot.internalCount !== internalLinks.length) {
      throw new Error("Internal hyperlink snapshot count does not match its metadata.");
    }
    const seen = Object.create(null);
    snapshot.links.forEach((meta, index) => {
      if (!meta || !clean(meta.name) || !clean(meta.url)) {
        throw new Error("Invalid hyperlink metadata at position " + (index + 1) + ".");
      }
      if (meta.sourceKind !== "text" && meta.sourceKind !== "pageItem") {
        throw new Error("Unsupported source kind for hyperlink: " + clean(meta.name));
      }
      const key = exactKey(meta.name);
      if (seen[key]) throw new Error("Duplicate hyperlink name in snapshot: " + meta.name);
      seen[key] = true;
    });
    internalLinks.forEach((meta, index) => {
      if (!meta || !clean(meta.name)) {
        throw new Error("Invalid internal hyperlink metadata at position " + (index + 1) + ".");
      }
      if (meta.sourceKind !== "text" && meta.sourceKind !== "pageItem") {
        throw new Error("Unsupported source kind for internal hyperlink: " + clean(meta.name));
      }
      const key = exactKey(meta.name);
      if (seen[key]) throw new Error("Duplicate hyperlink name in snapshot: " + meta.name);
      seen[key] = true;
    });
  }

  function matchesGbsSignature(meta, name, rule) {
    return !!meta && meta.name === name && meta.url === rule.url &&
      meta.sourceKind === "text" &&
      meta.pageName === rule.pageName &&
      Number(meta.pageOffset) === rule.pageOffset &&
      meta.sourceContents === rule.sourceText;
  }

  function detectProfile(snapshot) {
    try { assertSnapshot(snapshot); } catch (_) { return null; }
    if (snapshot.documentName !== GBS_SOURCE_DOCUMENT || snapshot.links.length !== GBS_URL_LINK_COUNT) return null;
    const byName = Object.create(null);
    snapshot.links.forEach(meta => { byName[exactKey(meta.name)] = meta; });
    const names = Object.keys(GBS_GERMAN_RULES);
    for (let index = 0; index < names.length; index++) {
      const name = names[index];
      if (!matchesGbsSignature(byName[exactKey(name)], name, GBS_GERMAN_RULES[name])) return null;
    }
    return GBS_PROFILE_ID;
  }

  function captureSource(doc) {
    if (!doc) throw new Error("No English source document was provided for hyperlink capture.");
    const map = buildExactLinkMap(doc);
    const links = [];
    const internalLinks = [];
    map.links.forEach(link => {
      const url = destinationUrl(link);
      const info = sourceInfo(link);
      let name = "";
      try { name = String(link.name); } catch (_) {}
      if (!info.healthy) {
        throw new Error("English source hyperlink is unsafe: " + name + " (" + info.reason + ").");
      }
      if (url) links.push(snapshotLink(link));
      else {
        if (!destinationIsValid(link)) {
          throw new Error("English source hyperlink has an invalid destination: " + name + ".");
        }
        if (/URLDestination/i.test(destinationKind(link))) {
          throw new Error("English source hyperlink has an empty URL destination: " + name + ".");
        }
        internalLinks.push(snapshotInternalLink(link));
      }
    });
    let documentName = "";
    try { documentName = String(doc.name); } catch (_) {}
    const snapshot = {
      version: SNAPSHOT_VERSION,
      documentName,
      links,
      internalLinks,
      externalCount: links.length,
      internalCount: internalLinks.length,
      profileId: null
    };
    snapshot.profileId = detectProfile(snapshot);
    return snapshot;
  }

  function findCaseMismatch(linkMap, expectedName) {
    const alternatives = linkMap.folded[foldedKey(expectedName)] || [];
    return alternatives.find(name => name !== expectedName) || "";
  }

  function validate(doc, snapshot) {
    const result = {
      ok: false,
      total: 0,
      verified: 0,
      expected: 0,
      checked: 0,
      externalTotal: 0,
      externalVerified: 0,
      internalTotal: 0,
      internalVerified: 0,
      errors: []
    };
    try {
      assertSnapshot(snapshot);
      const internalLinks = snapshot.internalLinks || [];
      result.externalTotal = snapshot.links.length;
      result.internalTotal = internalLinks.length;
      result.total = result.externalTotal + result.internalTotal;
      result.expected = result.total;
      const map = buildExactLinkMap(doc);
      snapshot.links.forEach(meta => {
        const link = map.byName[exactKey(meta.name)];
        let valid = true;
        if (!link || !isValid(link)) {
          const mismatch = findCaseMismatch(map, meta.name);
          result.errors.push(mismatch
            ? "Case mismatch: expected '" + meta.name + "', found '" + mismatch + "'."
            : "Missing hyperlink: " + meta.name);
          return;
        }
        if (destinationUrl(link) !== meta.url) {
          result.errors.push("Wrong destination: " + meta.name);
          valid = false;
        }
        if (!sourceIsHealthyForMeta(link, meta)) {
          result.errors.push("Invalid or misplaced source: " + meta.name);
          valid = false;
        }
        if (valid) result.externalVerified++;
      });
      internalLinks.forEach(meta => {
        const link = map.byName[exactKey(meta.name)];
        let valid = true;
        if (!link || !isValid(link)) {
          const mismatch = findCaseMismatch(map, meta.name);
          result.errors.push(mismatch
            ? "Case mismatch: expected internal link '" + meta.name + "', found '" + mismatch + "'."
            : "Missing internal hyperlink: " + meta.name);
          return;
        }
        if (!destinationIsValid(link) || destinationUrl(link) ||
            (meta.destinationKind && destinationKind(link) !== meta.destinationKind)) {
          result.errors.push("Invalid or changed internal destination: " + meta.name);
          valid = false;
        }
        if (!sourceIsHealthyForMeta(link, meta)) {
          result.errors.push("Invalid or misplaced internal source: " + meta.name);
          valid = false;
        }
        if (valid) result.internalVerified++;
      });
    } catch (error) {
      result.errors.push(clean(error && error.message ? error.message : error));
    }
    result.verified = result.externalVerified + result.internalVerified;
    result.checked = result.verified;
    result.ok = result.errors.length === 0 && result.verified === result.total;
    return result;
  }

  function hostApis() {
    try {
      const module = require("indesign");
      return { module, app: module.app || module };
    } catch (_) {
      return { module: null, app: null };
    }
  }

  function resetGrep(app, module) {
    const nothing = module && module.NothingEnum && module.NothingEnum.NOTHING !== undefined
      ? module.NothingEnum.NOTHING
      : NOTHING;
    try { app.findGrepPreferences = nothing; } catch (_) {}
    try { app.changeGrepPreferences = nothing; } catch (_) {}
  }

  function findAnchorCandidate(doc, rule, meta) {
    const host = hostApis();
    if (!host.app || !doc || typeof doc.findGrep !== "function") {
      throw new Error("InDesign GREP is unavailable; no hyperlink anchor was changed.");
    }
    let oldFind = null;
    let oldChange = null;
    try { oldFind = host.app.findGrepPreferences.properties; } catch (_) {}
    try { oldChange = host.app.changeGrepPreferences.properties; } catch (_) {}
    let hits = [];
    try {
      resetGrep(host.app, host.module);
      host.app.findGrepPreferences.findWhat = "(?i)" + rule.grepPattern;
      hits = collectionToArray(doc.findGrep(false));
    } finally {
      resetGrep(host.app, host.module);
      if (oldFind) {
        try { host.app.findGrepPreferences.properties = oldFind; } catch (_) {}
      }
      if (oldChange) {
        try { host.app.changeGrepPreferences.properties = oldChange; } catch (_) {}
      }
    }

    const candidates = [];
    hits.forEach(hit => {
      if (!isValid(hit)) return;
      let contents = "";
      try { contents = clean(hit.contents); } catch (_) {}
      if (!contents || contents.toLocaleLowerCase() !== rule.targetText.toLocaleLowerCase()) return;
      let frame = null;
      try { frame = firstCollectionItem(hit.parentTextFrames); } catch (_) {}
      if (!isValid(frame)) return;
      let page = null;
      try { page = frame.parentPage; } catch (_) {}
      if (!pageMatches(page, rule.pageName, rule.pageOffset)) return;
      candidates.push({ text: hit, page, contents, frameBounds: copyBounds(frame.geometricBounds) });
    });
    if (!candidates.length) {
      throw new Error(
        "No safe text match for '" + meta.name + "' on page " + rule.pageName +
        " (expected text: " + rule.targetText + "). No anchor was changed."
      );
    }
    if (candidates.length > 1) {
      throw new Error(
        "Ambiguous text matches for '" + meta.name + "' on page " + rule.pageName +
        ". No anchor was changed."
      );
    }
    return candidates[0];
  }

  function textSignature(text) {
    try {
      if (!isValid(text) || !isValid(text.parentStory)) return "";
      const points = text.insertionPoints;
      const length = collectionLength(points);
      if (length < 2) return "";
      let first = null;
      let last = null;
      if (Array.isArray(points)) {
        first = points[0];
        last = points[length - 1];
      } else if (typeof points.item === "function") {
        first = points.item(0);
        last = points.item(length - 1);
      } else {
        const items = collectionToArray(points);
        first = items[0];
        last = items[items.length - 1];
      }
      return String(text.parentStory.id) + ":" + String(first.index) + ":" + String(last.index);
    } catch (_) {
      return "";
    }
  }

  function sourceIdentity(source) {
    try {
      if (source && source.id !== undefined && source.id !== null) return "id:" + String(source.id);
    } catch (_) {}
    return source;
  }

  function sameSource(left, right) {
    if (left === right) return true;
    const a = sourceIdentity(left);
    const b = sourceIdentity(right);
    return typeof a === "string" && typeof b === "string" && a === b;
  }

  function sourceReferenceCount(doc, source) {
    let count = 0;
    collectionToArray(doc && doc.hyperlinks).forEach(link => {
      try { if (sameSource(link.source, source)) count++; } catch (_) {}
    });
    return count;
  }

  function matchingTextSource(doc, text) {
    const wanted = textSignature(text);
    if (!wanted) return null;
    const sources = collectionToArray(doc && doc.hyperlinkTextSources);
    for (let index = 0; index < sources.length; index++) {
      const source = sources[index];
      try {
        if (isValid(source) && isValid(source.sourceText) && textSignature(source.sourceText) === wanted) {
          return source;
        }
      } catch (_) {}
    }
    return null;
  }

  function captureSourceMetadata(source) {
    const result = {};
    if (!source) return result;
    try { result.name = source.name; } catch (_) {}
    try { result.label = source.label; } catch (_) {}
    try {
      if (isValid(source.appliedCharacterStyle)) result.appliedCharacterStyle = source.appliedCharacterStyle;
    } catch (_) {}
    return result;
  }

  function applySourceMetadata(source, metadata) {
    if (!source || !metadata) return;
    try { if (metadata.name !== undefined) source.name = metadata.name; } catch (_) {}
    try { if (metadata.label !== undefined) source.label = metadata.label; } catch (_) {}
    try {
      if (isValid(metadata.appliedCharacterStyle)) source.appliedCharacterStyle = metadata.appliedCharacterStyle;
    } catch (_) {}
  }

  function freshUrlDestination(doc, url) {
    if (!doc || !doc.hyperlinkURLDestinations || typeof doc.hyperlinkURLDestinations.add !== "function") {
      throw new Error("InDesign cannot create a URL destination for: " + url);
    }
    const destination = doc.hyperlinkURLDestinations.add(url);
    if (!isValid(destination)) throw new Error("Could not create a fresh URL destination for: " + url);
    return destination;
  }

  function replaceLinkDestination(doc, link, expectedUrl) {
    const destination = freshUrlDestination(doc, expectedUrl);
    const originalName = String(link.name);
    const originalSource = link.source;
    const appearance = captureAppearance(link);
    try {
      link.destination = destination;
      if (destinationUrl(link) === expectedUrl) return link;
    } catch (_) {}
    if (!isValid(originalSource)) {
      throw new Error("Cannot reconnect destination because the source is invalid: " + originalName);
    }
    try { if (isValid(link)) link.remove(); }
    catch (error) { throw new Error("Could not rebuild hyperlink '" + originalName + "': " + clean(error)); }
    const replacement = doc.hyperlinks.add(originalSource, destination, { name: originalName });
    applyAppearance(replacement, appearance);
    if (destinationUrl(replacement) !== expectedUrl) {
      throw new Error("Destination verification failed after rebuilding: " + originalName);
    }
    return replacement;
  }

  function rebuildAnchor(doc, link, meta, rule) {
    // Reacquire the text immediately before editing. InDesign text wrappers can
    // become stale whenever another live DOM object is mutated.
    const candidate = findAnchorCandidate(doc, rule, meta);
    let source = matchingTextSource(doc, candidate.text);
    if (source && sourceReferenceCount(doc, source) > 0) {
      throw new Error("The intended text for '" + meta.name + "' is already used by another hyperlink.");
    }
    const appearance = isValid(link) ? captureAppearance(link) : meta.appearance;
    let oldSource = null;
    try { if (link) oldSource = link.source; } catch (_) {}
    const oldSourceMetadata = captureSourceMetadata(oldSource);

    if (!source) {
      try {
        // `add(candidate.text)` is intentional. Assigning source.sourceText is
        // unsupported in UXP and can leave a detached HyperlinkTextSource.
        source = doc.hyperlinkTextSources.add(candidate.text);
      } catch (error) {
        throw new Error("Could not create text source for '" + meta.name + "': " + clean(error));
      }
    }
    const destination = freshUrlDestination(doc, meta.url);
    if (isValid(link)) {
      try { link.remove(); }
      catch (error) { throw new Error("Could not remove broken hyperlink '" + meta.name + "': " + clean(error)); }
    }
    if (isValid(oldSource) && !sameSource(oldSource, source) && sourceReferenceCount(doc, oldSource) === 0) {
      try { if (typeof oldSource.remove === "function") oldSource.remove(); } catch (_) {}
    }
    applySourceMetadata(source, oldSourceMetadata);
    const replacement = doc.hyperlinks.add(source, destination, { name: meta.name });
    applyAppearance(replacement, appearance);
    if (!sourceIsHealthyForMeta(replacement, meta) || destinationUrl(replacement) !== meta.url) {
      throw new Error("Rebuilt hyperlink did not pass verification: " + meta.name);
    }
    return replacement;
  }

  function languageCode(language) {
    if (typeof language === "string") return language;
    try { return language && typeof language.code === "string" ? language.code : ""; }
    catch (_) { return ""; }
  }

  function approvedGermanRule(snapshot, language, meta) {
    if (languageCode(language) !== "de") return null;
    if (detectProfile(snapshot) !== GBS_PROFILE_ID) return null;
    const rule = GBS_GERMAN_RULES[meta.name];
    return rule && matchesGbsSignature(meta, meta.name, rule) ? rule : null;
  }

  function preflightInternalLinks(doc, snapshot, map) {
    const internalLinks = snapshot.internalLinks || [];
    internalLinks.forEach(meta => {
      const link = map.byName[exactKey(meta.name)] || null;
      if (!link || !isValid(link)) {
        const mismatch = findCaseMismatch(map, meta.name);
        throw new Error(mismatch
          ? "Case mismatch: expected internal link '" + meta.name + "', found '" + mismatch + "'. No link was changed."
          : "Missing internal hyperlink: " + meta.name + ". No link was changed.");
      }
      if (!destinationIsValid(link) || destinationUrl(link) ||
          (meta.destinationKind && destinationKind(link) !== meta.destinationKind)) {
        throw new Error("Invalid or changed internal destination for '" + meta.name + "'. No link was changed.");
      }
      if (!sourceIsHealthyForMeta(link, meta)) {
        throw new Error("Invalid or misplaced internal source for '" + meta.name + "'. No link was changed.");
      }
    });
  }

  function preflight(doc, snapshot, language) {
    const map = buildExactLinkMap(doc);
    // Internal destinations are document-local and cannot be synchronized from
    // English. Verify all of them before planning any external-link mutation.
    preflightInternalLinks(doc, snapshot, map);
    const plan = [];
    const reservedSignatures = Object.create(null);
    snapshot.links.forEach(meta => {
      const link = map.byName[exactKey(meta.name)] || null;
      if (!link) {
        const mismatch = findCaseMismatch(map, meta.name);
        if (mismatch) {
          throw new Error("Case mismatch: expected '" + meta.name + "', found '" + mismatch + "'. No link was changed.");
        }
      }
      if (link && sourceIsHealthyForMeta(link, meta)) {
        plan.push({ type: destinationUrl(link) === meta.url ? "unchanged" : "destination", meta });
        return;
      }
      const rule = approvedGermanRule(snapshot, language, meta);
      if (!rule) {
        throw new Error(
          "Invalid or missing source for '" + meta.name +
          "'. No approved anchor repair applies, so no link was changed."
        );
      }
      const candidate = findAnchorCandidate(doc, rule, meta);
      const signature = textSignature(candidate.text);
      if (!signature) throw new Error("Could not identify a stable text range for '" + meta.name + "'.");
      if (reservedSignatures[exactKey(signature)]) {
        throw new Error("Two hyperlinks resolve to the same target text. No link was changed: " + meta.name);
      }
      reservedSignatures[exactKey(signature)] = true;
      const source = matchingTextSource(doc, candidate.text);
      if (source && sourceReferenceCount(doc, source) > 0) {
        throw new Error("The intended text for '" + meta.name + "' is already used by another hyperlink.");
      }
      plan.push({ type: "source", meta, rule });
    });
    return plan;
  }

  function synchronizeAndValidate(doc, snapshot, language) {
    if (!doc) throw new Error("No translated document was provided for hyperlink synchronization.");
    assertSnapshot(snapshot);
    const plan = preflight(doc, snapshot, language);
    const internalTotal = (snapshot.internalLinks || []).length;
    const result = {
      ok: false,
      total: snapshot.links.length + internalTotal,
      verified: 0,
      destinationsRepaired: 0,
      anchorsRebuilt: 0,
      freshDestinations: 0,
      unchanged: 0,
      internalTotal,
      internalVerified: 0,
      // Compatibility aliases for callers built against the initial API draft.
      expected: snapshot.links.length + internalTotal,
      destinationRepairs: 0,
      sourceRepairs: 0,
      profileId: detectProfile(snapshot)
    };

    plan.forEach(action => {
      if (action.type === "unchanged") {
        result.unchanged++;
        return;
      }
      // Reacquire link proxies after every mutation; collection members and
      // text wrappers are live in InDesign UXP.
      const map = buildExactLinkMap(doc);
      const link = map.byName[exactKey(action.meta.name)] || null;
      if (action.type === "destination") {
        if (!link || !sourceIsHealthyForMeta(link, action.meta)) {
          throw new Error("Hyperlink source changed during synchronization: " + action.meta.name);
        }
        replaceLinkDestination(doc, link, action.meta.url);
        result.destinationsRepaired++;
        result.destinationRepairs++;
        result.freshDestinations++;
        return;
      }
      const oldUrl = link ? destinationUrl(link) : "";
      rebuildAnchor(doc, link, action.meta, action.rule);
      result.anchorsRebuilt++;
      result.sourceRepairs++;
      result.freshDestinations++;
      if (oldUrl !== action.meta.url) {
        result.destinationsRepaired++;
        result.destinationRepairs++;
      }
    });

    const validation = validate(doc, snapshot);
    if (!validation.ok) {
      throw new Error("Hyperlink validation failed: " + validation.errors.join(" | "));
    }
    result.ok = true;
    result.verified = validation.verified;
    result.internalVerified = validation.internalVerified;
    return result;
  }

  window.AIT_HyperlinkSync = {
    inspect,
    captureSource,
    synchronizeAndValidate,
    validate,
    _private: {
      GBS_PROFILE_ID,
      GBS_SOURCE_DOCUMENT,
      GBS_URL_LINK_COUNT,
      GBS_GERMAN_RULES,
      collectionToArray,
      destinationUrl,
      sourceInfo,
      sourceIsHealthyForMeta,
      detectProfile,
      textSignature,
      matchingTextSource
    }
  };
})();
