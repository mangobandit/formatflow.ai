# FormatFlow Translate 3.3.0 development preview

Prepared 3 November 2026. This package is for developer installation through Adobe
UXP Developer Tools, not an Adobe Marketplace release. Paid licensing remains off.

## Changes

- Updated OpenAI, Claude and Gemini presets and request settings. Custom model IDs
  persist, and an existing saved model is not silently moved to a different tier.
- Structured provider output is checked for missing, duplicate, unexpected or
  empty translation units and missing or repeated protected tokens.
- Permanent provider errors fail promptly. Transient retries respect provider
  backoff, request timeouts and cancellation.
- In-memory API keys are scoped to each provider. A DeepL key test cannot turn
  Private mode off, and the DeepL document route enforces the same privacy rule.
- Cancellation blocks subsequent DeepL steps and final file writes. Existing
  requests may complete; batch workers drain before the UI reports completion.
- IDML batches always preserve character runs and include locked text. Controls
  that previously implied otherwise are disabled with explanatory text.
- The existing 3.2.0 hyperlink checks and repair work are retained.

## Verification

`npm run verify` passed: structure validation, 101 UI bindings and 42 automated
tests, with no skipped tests. Provider calls in tests are simulated. No paid live
provider call or Adobe InDesign host test was performed during this update.

Before client use, load the package in InDesign, translate a COPY of a short
representative document into one language, then reopen the output. Check paragraph
starts, styled spans, tables, URLs and anchors, overset, RTL/CJK text, and exported
PDF links. Test Cancel during a batch and Private mode with a cloud provider. Keep
the source and preview outputs separate.

## Provider contracts checked

- https://developers.openai.com/api/docs/guides/latest-model
- https://developers.openai.com/api/docs/guides/structured-outputs
- https://platform.claude.com/docs/en/models/overview
- https://ai.google.dev/api/generate-content

Models are available according to the user's own provider account and may change.
Enter the exact account-supported model ID if a preset is unavailable.
