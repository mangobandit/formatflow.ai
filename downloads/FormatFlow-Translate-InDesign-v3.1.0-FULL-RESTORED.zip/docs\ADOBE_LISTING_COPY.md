# Adobe Marketplace Listing — FormatFlow Translate (paste-ready)

Drop these into the Adobe Developer Distribution **Listing Details** fields. Every claim
here is honesty-gate compliant (verified against the shipping code, 2026-06-27): 48
languages, IDML-safe, BYOK, on-device Ollama / Private mode with its caveat, no
"first-to-market" language.

> **DeepL is advertised** (decided 2026-07-27). It is folded into the copy below as a
> fifth provider. It must therefore pass the QA pass (`QA_PASS_FAIL.md` row C2b) before
> submission — advertise only what you have personally verified in InDesign.

---

## Plugin name
```
FormatFlow Translate
```

## Tagline / short description (≤ ~100 chars)
```
Translate entire InDesign documents into 48 languages in one batch — layout intact, your own AI key.
```

## Summary (1–2 sentences)
```
FormatFlow Translate is the IDML-safe AI translation plugin for Adobe InDesign. Translate a
whole document into any of 48 languages in a single batch using your own OpenAI, Anthropic,
Gemini, or local Ollama key — every text frame verified, layout preserved, overset text
auto-fixed.
```

## Full description
```
Stop copy-pasting paragraphs into a browser and rebuilding your layout by hand.

FormatFlow Translate runs inside InDesign and translates an entire document — every text
frame, table cell, and story — into any of 48 languages in one batch. It works at the IDML
level, so your styles, threading, and layout stay exactly where you put them.

WHY DESIGNERS USE IT
• 48 languages, one batch — including all major European languages, Chinese (Simplified &
  Traditional), Japanese, Korean, Hindi, Arabic, Hebrew, and more, with automatic
  right-to-left handling. Presets for Core 20, Europe, Africa, Asia, Middle East, Americas.
• Layout-safe — IDML round-trip means nothing in your document structure gets rewritten,
  only the text content.
• Auto-fit overset text — translations run longer than English; the fixer tightens tracking,
  then leading, then size (least-invasive first) so nothing clips in print.
• Bring your own key (BYOK) — use OpenAI, Anthropic, Gemini, DeepL, or a local Ollama model. AI
  compute is billed by your provider (often pennies per document, or free on Google's AI
  Studio tier and local Ollama). No markup, no middleman.
• Private mode — flip one toggle and the plugin hard-blocks every cloud provider, so with a
  local Ollama model installed, guaranteed nothing leaves your machine.
• We have no server in the path — text goes straight from your machine to the provider you
  chose. The only call back to us is license validation, which carries your license key and
  nothing else. We never see your content.

HOW IT WORKS
1. Open your .indd, open the FormatFlow Translate panel.
2. Pick your provider, paste your API key (or point it at local Ollama), choose target
   languages.
3. Translate the whole document in one batch and review. Export when you're happy.

REQUIREMENTS
Adobe InDesign 18.5 or newer (2023+), macOS or Windows, and an API key from any supported
provider — or Ollama installed locally for fully offline translation.

PRICING
14-day free trial, then €12/month or €120/year for the plugin. Your AI usage is billed
separately by your own provider and is completely independent of the subscription.
```

## Key features (bullet list field, if separate)
```
- 48 languages translated in a single batch, with RTL handling
- IDML-safe: layout, styles, and threading preserved
- Auto-fit for overset text (tracking → leading → size)
- BYOK: OpenAI, Anthropic, Gemini, DeepL, or local Ollama
- Private mode: hard-blocks cloud providers for fully on-device translation
- No server in the path — your content never touches our infrastructure
- 14-day free trial
```

## Categories / tags
```
Translation, Localization, Productivity, Automation, Text & Typography, AI
```
Tags: `translation, localization, AI, batch, IDML, multilingual, RTL, OpenAI, Anthropic, Gemini, DeepL, Ollama, BYOK, privacy`

## System requirements
```
Adobe InDesign 18.5+ (2023 or newer), macOS or Windows. Requires an API key from a
supported AI provider, or a local Ollama installation.
```

## Support / links (fill from Go-Live values)
```
Website:  https://formatflow.ai/<plugin-page>     ← VALUE 5
Support:  <support email>                          ← VALUE 4
FAQ:      <faq url>                                ← VALUE 6
Docs:     <docs url>                               ← VALUE 6
```

## Media checklist (Media section)
- Square publisher logo (FormatFlow teal `#14c9b4`).
- 3–5 panel screenshots: language picker, a batch running, the overset auto-fit, Settings
  showing Private mode, a before/after document. **Use your own screenshots — do NOT reuse
  any competitor's listing art.**
- Optional: short screen-capture GIF of a one-batch translation.

---

## DeepL — applied 2026-07-27
DeepL is now folded into every line above (short description, full description, key
features, tags). Nothing further to swap in.

⚠️ Standing condition: DeepL must pass `QA_PASS_FAIL.md` row C2b in live InDesign before
submission. It is wired and the `billed_characters` bug is fixed, but the honesty gate says
advertise only what you have personally verified.
```
```
