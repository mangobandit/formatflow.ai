# 🚀 Launch Playbook — FormatFlow Translate

Everything between this folder and a live Adobe Marketplace listing, in order.
Items marked **[YOU]** need an account/decision only you can provide; everything
else is already done in the codebase.

---

## 0. What's already done (v1.2.0)

- ✅ IDML-safe translation engine with verification gates, repair retries, glossary, RTL
- ✅ 48 languages, multi-select batch, one .indd (+ optional PDF) per language
- ✅ Batch PDF tab + Overset Fixer tab as standalone tools
- ✅ BYOK providers: OpenAI, Anthropic, Google Gemini, DeepL, Ollama (local) + Mock
- ✅ Subscription licensing layer (`src/license.js`): 14-day trial, key activation,
  72-hour cached revalidation, graceful offline behavior — **currently in dev mode**
- ✅ Spectrum-native UI, light/dark, Match-InDesign theme
- ✅ Marketing site: `docs/site/index.html` (+ `privacy.html`, `eula.html`)
- ✅ Regression test (`tests/idml-roundtrip.test.js`), validators (`scripts/validate.js`, `scripts/check-ids.js`)

---

## 1. Payments & licensing — Lemon Squeezy **[YOU — ~1 hour]**

The plugin is pre-wired for Lemon Squeezy's public license API (no server of your own).

1. Create a store at <https://lemonsqueezy.com> (they are merchant of record — they
   handle VAT/sales tax globally).
2. Create a **Subscription** product: "FormatFlow Translate — Pro".
   Suggested variants: Monthly €12, Yearly €120 (matches the website).
3. In the product settings, enable **License keys** (1 activation per key is fine;
   raise to 2–3 if you want to allow laptop + desktop).
4. Copy your checkout URL.
5. Edit `src/license.js` → `CONFIG`:
   - `urls.buy` → your checkout URL
   - `urls.website` / `urls.faq` / `urls.support` → your real URLs (step 2)
   - `enabled: true`  ← the switch that turns enforcement on
6. Update the two checkout links in `docs/site/index.html` (search `lemonsqueezy.com/checkout`).
7. **Test**: buy with Lemon Squeezy's test mode, paste the key into the plugin's
   Settings → Plugin License → Activate. Confirm status reads "License active."
   Then `deactivate` the key in the LS dashboard and confirm the plugin reverts
   to trial/expired within 72 hours (or immediately after Reload).

> Behavior summary: 14-day full trial starts on first run → after that, Translate
> is gated (the two tool tabs and Settings stay usable) → activation is one API
> call → once active, the plugin re-checks the key at most every 72 h and never
> blocks the user while offline.

---

## 2. Website **[YOU — ~30 min]**

`docs/site/` is a complete static site (index, privacy, EULA) — no build step.

1. Host it anywhere static: Cloudflare Pages, Netlify, GitHub Pages — pointed at
   the **formatflow.ai** domain. Drag-and-drop the `docs/site` folder.
2. The site ships as: `index.html` (product page), `docs.html` (user guide),
   `privacy.html`, `eula.html`.
3. Replace placeholder URLs in:
   - `docs/site/index.html` (checkout links, support email if different)
   - `src/license.js` → `CONFIG.urls`
4. Adobe review requires the **privacy policy URL** — that's `…/privacy.html`.

---

## 3. Adobe listing **[YOU — accounts & upload]**

### 3a. Get the marketplace plugin ID
1. Sign in at the **Adobe Developer Distribution portal**: <https://developer.adobe.com/distribute>
   (free; needs an Adobe ID, and company info for payout/identity).
2. Create a new **plugin** listing → platform **UXP / InDesign**.
3. The portal assigns your plugin an **ID**. Replace the `id` field in
   `manifest.json` (currently `ai.formatflow.translate.indesign`)
   with the assigned ID — they must match or upload fails.

### 3b. Package
1. Run `node scripts/validate.js` (must pass).
2. In **UXP Developer Tools**: your plugin → ••• → **Package**. This produces a
   `.ccx` file (it's the plugin folder zipped with the manifest at root —
   `npm run zip` + renaming the inner folder zip to `.ccx` also works).
3. Upload the `.ccx` in the portal.

### 3c. Listing assets checklist
The portal will ask for (prepare before you start):
- [ ] Icon (the portal states exact sizes; export from `icons/` artwork at high res)
- [ ] 3–5 screenshots — suggested shots:
      1. Translate tab with 10+ languages ticked,
      2. the progress log mid-batch showing per-language ✓ lines,
      3. a before/after spread (English vs French .indd side by side),
      4. Batch PDF tab, 5. Overset Fixer tab
- [ ] Publisher name, support **email**, support **website** (your new site)
- [ ] **Privacy policy URL** → `…/privacy.html`
- [ ] EULA: choose "custom" and link `…/eula.html` (or accept Adobe's default)

### 3d. Listing copy — ready to paste

**Name:** FormatFlow Translate

**Subtitle (one-liner):**
Translate entire InDesign documents into 48 languages in one batch — layout-safe, with your own AI key.

**Description:**
> Translate a whole InDesign document into French, German, Japanese, Arabic — and 44 more — in a single batch. FormatFlow Translate exports your document to IDML, translates the text inside the XML, verifies every block, and builds a fresh, press-ready .indd per language. Your original file is never edited.
>
> • 48 languages with regional presets (Core 20, Europe, Asia, Middle East, Africa, Americas)
> • Bring your own AI key: OpenAI, Anthropic Claude, Google Gemini (free tier), DeepL, or 100% local Ollama — your content goes directly to your provider, never through our servers
> • Layout preserved by construction: frames, styles, tables, and masters untouched
> • Every paragraph and table cell verified; incomplete translations are automatically re-requested
> • Auto-fit for overset text: tracking → leading → size, least invasive first
> • Batch PDF export — a print PDF per language, plus a standalone batch-PDF tool
> • Standalone Overset Fixer for any document
> • Glossary enforcement from CSV, brand/product/URL protection
> • Right-to-left support for Arabic, Hebrew, Persian; full CJK and complex-script support
>
> 14-day free trial, full-featured, no card required. Subscription covers the plugin; AI usage is billed by your own provider (free options available).

**Keywords:** translation, translate, localization, AI, multilingual, IDML, batch, GPT, Claude, Gemini, language, RTL, Arabic, Japanese

**What's new in 1.2.0:** New IDML-safe engine, batch PDF export, overset auto-fit + fixer tool, multi-select language dropdown, Spectrum UI, subscription licensing with 14-day trial.

### 3e. Review notes — paste into the "notes for reviewers" box
> The plugin is BYOK (bring-your-own-key): users supply their own API key for
> OpenAI / Anthropic / Google Gemini, or use a local Ollama instance. To test
> without any key or cost, select Provider → "Mock/offline test" and run
> Translate on any document — the full workflow executes with simulated
> translations. A 14-day trial starts automatically; no license key is needed
> for review.
>
> Permission justifications:
> • network "all" — user-configurable AI endpoints (api.openai.com,
>   api.anthropic.com, generativelanguage.googleapis.com), localhost:11434 for
>   local Ollama, and license validation (api.lemonsqueezy.com).
> • localFileSystem fullAccess — the document is exported to IDML, rebuilt per
>   language, and saved as .indd/.pdf into a user-chosen output folder.
> • launchProcess — opens the product website / support mail from the About tab.
> • clipboard — convenience copy of log output.
> • AI-generated content disclosure: all translations are produced by the AI
>   provider selected and credentialed by the user.

---

## 4. Pre-flight QA — run before every submission

Automated (all must pass):
```
node scripts/validate.js
node scripts/check-ids.js
node tests/idml-roundtrip.test.js
```

Manual, in InDesign (15 minutes):
- [ ] Fresh install (unload + load): trial banner shows in Settings → Plugin License
- [ ] Mock provider: full batch on a small doc → .indd + .pdf appear, copy opens
- [ ] Gemini (or any real provider): one language end-to-end, log shows
      "XML rebuilt and verified" and no leftover warnings
- [ ] Multi-language: 3+ languages ticked → one file set per language
- [ ] Batch PDF tab: "All open documents" works; "Choose files" works
- [ ] Overset Fixer: Scan on an overset doc reports; Fix resolves or reports remainder
- [ ] License: activate a test key → "License active"; bogus key → clear error
- [ ] Theme: Match InDesign follows Interface brightness; Light/Dark force correctly
- [ ] Panel at 320px width: nothing clips; all six tabs reachable

---

## 5. Launch-day order of operations

1. Lemon Squeezy live (test purchase verified) → flip `CONFIG.enabled = true`
2. Deploy website with final URLs
3. Update `CONFIG.urls` + site checkout links → `npm run zip` → package `.ccx`
4. Run §4 QA on the **packaged** build (install the .ccx locally to test)
5. Submit on Developer Distribution with §3d/§3e copy
6. While in review: prepare 3 demo videos/GIFs for the listing page & socials
7. On approval: announce — InDesign user groups, r/indesign, LinkedIn,
   print/localization communities. Lead with the 2-minute demo: one click → ten
   translated, print-ready files.

---

## 6. Post-launch backlog (already scoped, not yet built)

- Selection-scope translation (translate only selected frames) in IDML mode
- Per-language model override (Flash for drafts, Pro/Claude for finals) per run
- Translation memory: reuse previous translations across document versions
- .idml input files directly (skip the open-document requirement)
- Team licensing portal / seat management
