/* FormatFlow Translate — batch export UI wiring.
   Adds the PDF / PNG / JPEG format switch, per-format option panels, and the
   Adobe PDF preset list. The export run itself lives in ui.js (handler Le),
   which reads options through window.__ffExportOpts(format). */
(function () {
  function $(id) { return document.getElementById(id); }

  // Read the option values for the chosen format. Called by the export handler.
  window.__ffExportOpts = function (fmt) {
    function val(id, d) { var el = $(id); return el && el.value !== undefined && el.value !== null ? el.value : d; }
    function chk(id) { var el = $(id); return !!(el && el.checked); }
    function num(id, d) { var n = parseInt(val(id, d), 10); return isFinite(n) ? n : d; }
    if (fmt === "png") {
      return {
        scope: val("pngScope", "all"),
        pageRange: val("pngRange", ""),
        spreads: val("pngLayout", "pages") === "spreads",
        suffix: val("pngSuffix", ""),
        quality: val("pngQuality", "maximum"),
        resolution: num("pngRes", 150),
        colorSpace: val("pngColor", "rgb"),
        transparent: chk("pngTransparent"),
        antiAlias: chk("pngAntiAlias"),
        bleed: chk("pngBleed"),
        overprint: chk("pngOverprint")
      };
    }
    if (fmt === "jpeg") {
      return {
        scope: val("jpegScope", "all"),
        pageRange: val("jpegRange", ""),
        spreads: val("jpegLayout", "pages") === "spreads",
        suffix: val("jpegSuffix", ""),
        quality: val("jpegQuality", "maximum"),
        resolution: num("jpegRes", 150),
        colorSpace: val("jpegColor", "rgb"),
        antiAlias: chk("jpegAntiAlias"),
        bleed: chk("jpegBleed"),
        overprint: chk("jpegOverprint"),
        embedProfile: chk("jpegEmbed")
      };
    }
    return { preset: val("pdfPreset", "") };
  };

  // Show the page-range field only when its scope select is set to "range".
  function wireScope(scopeId, rangeId) {
    var s = $(scopeId), r = $(rangeId);
    if (!s || !r) return;
    var upd = function () { r.style.display = (s.value === "range") ? "" : "none"; };
    s.addEventListener("change", upd);
    upd();
  }

  function showOptionsFor(fmt) {
    var map = { pdf: "pdfOptions", png: "pngOptions", jpeg: "jpegOptions" };
    ["pdfOptions", "pngOptions", "jpegOptions"].forEach(function (id) {
      var el = $(id);
      if (el) el.style.display = (map[fmt] === id) ? "" : "none";
    });
    var btn = $("pdfRun");
    if (btn) btn.textContent = fmt === "png" ? "Export PNGs" : fmt === "jpeg" ? "Export JPEGs" : "Export PDFs";
  }

  function populatePresets() {
    var sel = $("pdfPreset");
    var NS = window.AIT_InDesignDom;
    if (!sel || !NS || typeof NS.listPdfPresets !== "function") return;
    var names = [];
    try { names = NS.listPdfPresets() || []; } catch (e) { names = []; }
    if (!names.length) return; // keep the default "Current PDF export settings" option
    var current = sel.value;
    while (sel.options.length > 1) sel.remove(1);
    names.forEach(function (nm) {
      var o = document.createElement("option");
      o.value = nm;
      o.textContent = nm;
      sel.appendChild(o);
    });
    if (current) { try { sel.value = current; } catch (e) {} }
  }

  function init() {
    var fmtSel = $("exportFormat");
    if (fmtSel) {
      fmtSel.addEventListener("change", function () { showOptionsFor(fmtSel.value || "pdf"); });
      showOptionsFor(fmtSel.value || "pdf");
    }
    wireScope("pngScope", "pngRange");
    wireScope("jpegScope", "jpegRange");
    populatePresets();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
