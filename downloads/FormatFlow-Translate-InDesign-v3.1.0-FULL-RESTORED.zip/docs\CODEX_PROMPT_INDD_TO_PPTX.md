# Codex prompt — personal INDD → PPTX tool for Matt

Copy everything below the line into Codex as the task prompt. It is self-contained.

---

## Mission

Build a **personal-use** tool that converts Matt's own InDesign documents into PowerPoint. This is NOT a product: no licensing, no marketplace packaging, no marketing copy, no UI polish. Optimize for "Matt can convert a real document today" — a working hybrid deck beats an elegant incomplete one.

Two pieces, deliberately decoupled:

1. **`extract.jsx`** — an ExtendScript run from InDesign's Scripts panel. It walks the OPEN document and writes an export folder next to the `.indd`: `deck.json` (scene graph), `assets/` (linked images copied in), `pages/` (a PNG render of every page).
2. **`build.js`** — a Node CLI: `node build.js <exportFolder> [--mode snapshot|editable]` → writes `<docname>.pptx`.

Create this as a new standalone project folder: `indd2pptx/` (in the Vault root, sibling of `ai-translator-pro-multilang-v1.1-filefirst/`). `git init` it and commit as you go. Do NOT modify the FormatFlow Translate plugin — reference its readable source at `ai-translator-pro-multilang-v1.1-filefirst/ai-translator-pro-multilang-v1.1-filefirst/src/` (especially `indesign-dom.js` and `idml-engine.js`) for working InDesign DOM patterns, but this tool stands alone.

## Architecture facts (verified — do not relitigate)

- **Extract from the live InDesign DOM, never from IDML.** IDML stores a threaded story as one continuous flow with no per-frame text partition and no composed line breaks; only InDesign's composer knows which text lands in which frame. The scripting DOM exposes the composed result directly: each text frame's own text range, `geometricBounds`, per-character positions. Extraction therefore MUST run inside InDesign — hence `extract.jsx`.
- **ExtendScript over UXP** for the extractor: full `File`/`Folder` write access with no sandbox friction, same DOM. Gotchas: ExtendScript is ES3 (no `const`, no arrow functions, **no built-in `JSON`** — write a small serializer or bundle a json2 polyfill) and files should be written with explicit UTF-8 encoding.
- **The Node side is unconstrained** — npm deps are fine. Recommended: **PptxGenJS** for authoring (covers text boxes, images with crop, basic shapes, rotation — everything this tool needs since groups are flattened and the default master suffices), dropping to raw OOXML XML only if PptxGenJS blocks something specific. Alternative if it fights you: raw OOXML + `fflate` (1 pt = 12,700 EMU exactly; minimal package needs one master/layout/theme).
- **Hard format ceilings (flatten or skip + warn, don't fight them):** DrawingML is RGB-only (no CMYK/spot), `a:xfrm` has no shear, PowerPoint doesn't render blend modes (Multiply etc.), no text-on-a-path, feathering ≈ soft edge at best.

## Modes

- **`snapshot`** — one slide per page, each a full-bleed PNG of the page. Trivial, always correct, ships first. Slide size = page size.
- **`editable`** (default) — per page, z-ordered:
  - **Text frames** → editable text boxes. Use each frame's own composed text (`textFrame.texts[0].paragraphs` — threading resolves per frame automatically). Capture per run: font family, bold/italic, size (pt), fill color, and per paragraph: alignment, leading (set exact line spacing), plus frame rotation (`rotationAngle` — InDesign is counterclockwise-positive, PowerPoint clockwise: negate, and verify sign on the first real doc). Turn autofit off; box dims = frame dims; note that PowerPoint re-wraps slightly — that's inherent to editable output.
  - **Placed images** → pictures with crop computed from graphic bounds vs frame bounds. Copy the link file into `assets/` when it's PNG/JPEG/GIF/TIFF; for EPS/PDF/AI/PSD placed art, try exporting the item to PNG in a try/catch, else warn.
  - **Rectangles / lines** with solid fill/stroke → shapes.
  - **Groups** → flatten: recurse children with absolute page coordinates, never emit a group.
  - **Everything else** (tables, curved polygons, text on path, blend modes, sheared items) → skip + line in `warnings.txt`. Matt checks the matching `pages/*.png` for anything skipped.
- Colors: `geometricBounds` come back as `[y1, x1, y2, x2]` in **points** (PptxGenJS wants inches: divide by 72). CMYK → RGB via naive `R=255(1−C)(1−K)` (etc.) with a warning that it's not color-managed; spot colors via their alternate values + warning.
- Fonts: list fonts used; flag any not installed on this Windows machine in `warnings.txt` (PowerPoint will substitute them).

## extract.jsx specifics

- Iterate `page.pageItems` per page (MVP: ignore pasteboard/spread-level oddities). Record z-order (iteration order) and item type via `constructor.name`.
- Page PNG export: set `app.pngExportPreferences` (resolution ~150–200 ppi, `pageString` per page or EXPORT_ALL) then `doc.exportFile(ExportFormat.PNG_FORMAT, ...)`. A per-page loop is acceptable here (personal tool; correctness over speed).
- Overset text: flag frames whose story is overset in `warnings.txt`.
- Output layout: `<docname>_export/deck.json`, `assets/`, `pages/page-<n>.png`, `warnings.txt` (extractor half; `build.js` appends its own warnings).

## Deliverables & acceptance

- `indd2pptx/extract.jsx`, `indd2pptx/build.js`, `package.json`, `README.md` (install + the 2-step usage), plus lean tests for the pure logic in `build.js` (pt→inch/EMU math, crop math, color conversion, XML/text escaping if raw OOXML) runnable with plain `node --test` or similar — no InDesign needed.
- Acceptance: given a fixture `deck.json` + assets (commit one, hand-built, containing: title, 2-paragraph body, image with crop, colored CMYK rectangle, rotated rectangle, a skipped item), `build.js` produces a `.pptx` that PowerPoint opens without repair, with text editable at the right position/size/color, image cropped correctly, z-order preserved, and the skipped item listed in warnings.
- `--mode snapshot` from fixture PNGs also opens clean with slide size = page size.
- End your final summary with the exact steps Matt must do by hand: run `extract.jsx` from InDesign's Scripts panel on a real doc (Codex cannot run InDesign), run `build.js`, open the result in PowerPoint, and report back the first three things that look wrong — those drive iteration two.

## Non-goals (do not build)

Tables (warn only), AI visual-diff/repair, 16:9 re-layout, slide-master inference, speaker notes, UXP panel UI, any integration into the FormatFlow Translate plugin, any server or cloud API (Adobe's InDesign cloud API is enterprise-gated — verified 2026-07).

---

*Note (not part of the Codex prompt): if this later becomes a FormatFlow product feature, the extraction logic ports into the plugin's `indesign-dom.js` and the writer moves in-plugin on fflate + raw OOXML — the git history of this session's earlier product-scoped prompt has that variant.*
