const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const source = fs.readFileSync(path.join(__dirname, '..', 'src', 'indesign-dom.js'), 'utf8');

function makeDriftingStory(initialContents) {
  const contents = initialContents.slice();
  let generation = 0;

  const story = {
    get paragraphs() {
      return {
        getElements() {
          const snapshotGeneration = generation;
          return contents.map((_, index) => ({
            get contents() {
              return contents[index];
            },
            set contents(value) {
              contents[index] = snapshotGeneration === generation ? value : String(value).slice(5);
              generation += 1;
            }
          }));
        }
      };
    },
    tables: { getElements: () => [] },
    textContainers: { getElements: () => [] }
  };

  return { story, contents };
}

const drifting = makeDriftingStory(['First paragraph\r', 'Second paragraph\r']);
const document = {
  stories: { getElements: () => [drifting.story] },
  recompose() {}
};
const initialRefs = drifting.story.paragraphs.getElements();
const units = [
  {
    id: 's000-p0000',
    ref: initialRefs[0],
    originalText: 'First paragraph\r',
    textForTranslation: 'First paragraph',
    preparedText: 'First paragraph',
    placeholders: [],
    runs: [],
    mode: 'plain',
    hasFinalReturn: true,
    containerIndex: 0,
    paragraphIndex: 0
  },
  {
    id: 's000-p0001',
    ref: initialRefs[1],
    originalText: 'Second paragraph\r',
    textForTranslation: 'Second paragraph',
    preparedText: 'Second paragraph',
    placeholders: [],
    runs: [],
    mode: 'plain',
    hasFinalReturn: true,
    containerIndex: 0,
    paragraphIndex: 1
  }
];
const translations = {
  's000-p0000': 'Primer párrafo completo',
  's000-p0001': 'Segundo párrafo completo'
};

const context = vm.createContext({
  window: {
    AIT_Protectors: {
      restoreText: value => value,
      normalizeWhitespace: (_source, value) => value,
      parseTaggedRuns: () => []
    }
  },
  require() {
    throw new Error('Host module unavailable in regression test');
  },
  console,
  String,
  Array,
  Object,
  Error
});

vm.runInContext(source, context);
const dom = context.window.AIT_InDesignDom;
dom.applyTranslations(units, translations, { preserveCharStyles: false, rtlSupport: false }, null, document);
const verification = dom.verifyApplied(units, translations, document, { preserveCharStyles: false });

assert.deepStrictEqual(
  drifting.contents,
  ['Primer párrafo completo\r', 'Segundo párrafo completo\r'],
  'each paragraph must be written through a freshly resolved InDesign text range'
);
assert.strictEqual(verification.failed.length, 0, 'post-apply verification should pass after fresh writes');

console.log('InDesign DOM regression test passed.');
