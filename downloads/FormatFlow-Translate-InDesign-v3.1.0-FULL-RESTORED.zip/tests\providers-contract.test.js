const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const root = path.resolve(__dirname, '..');
const source = fs.readFileSync(path.join(root, 'src', 'providers.js'), 'utf8');
let capturedUrl = '';
let capturedPayload = null;

const context = vm.createContext({
  window: {
    AIT_Glossary: { toPromptLines: () => '' },
    AIT_Protectors: { stripFences: value => value }
  },
  fetch: async (url, options) => {
    capturedUrl = url;
    capturedPayload = JSON.parse(options.body);
    return {
      ok: true,
      status: 200,
      json: async () => ({
        output_text: JSON.stringify({ translations: [{ id: 'unit-1', text: 'Hola' }] })
      }),
      text: async () => ''
    };
  },
  setTimeout,
  clearTimeout,
  Promise,
  Math,
  JSON,
  String,
  Array,
  Object,
  Error,
  console
});

vm.runInContext(source, context);
const providers = context.window.AIT_Providers;

assert.strictEqual(providers.getDefaultModel('openai'), 'gpt-5.6-sol');
assert.deepStrictEqual(
  Array.from(providers.DEFAULT_MODELS.openai),
  ['gpt-5.6-sol', 'gpt-5.6-terra', 'gpt-5.6-luna']
);
assert.strictEqual(providers.normalizeModel('openai', 'gpt-5.5'), 'gpt-5.6-sol');
assert.strictEqual(providers.normalizeModel('openai', 'gpt-4.1'), 'gpt-5.6-terra');
assert.strictEqual(providers.normalizeModel('openai', 'gpt-4o-mini'), 'gpt-5.6-terra');
assert.strictEqual(providers.normalizeModel('anthropic', 'claude-sonnet-4-6'), 'claude-sonnet-4-6');

async function verifyOpenAiRequest(model) {
  capturedUrl = '';
  capturedPayload = null;
  const result = await providers.translateBatch('openai', {
    apiKey: 'test-key-not-sent-to-a-real-service',
    model,
    sourceLanguageName: 'English',
    targetLanguage: { name: 'Spanish', code: 'es' },
    units: [{ id: 'unit-1', preparedText: 'Hello', originalText: 'Hello' }],
    glossary: [],
    industry: 'General business',
    qualityMode: 'layout-tight',
    context: ''
  });

  assert.strictEqual(capturedUrl, 'https://api.openai.com/v1/responses');
  assert.strictEqual(capturedPayload.model, model);
  assert.deepStrictEqual(capturedPayload.reasoning, { effort: 'none' });
  assert.strictEqual(Object.prototype.hasOwnProperty.call(capturedPayload, 'temperature'), false);
  assert.strictEqual(result['unit-1'], 'Hola');
}

(async () => {
  await verifyOpenAiRequest('gpt-5.6-sol');
  await verifyOpenAiRequest('gpt-5.6-terra');
  await verifyOpenAiRequest('gpt-5.6-luna');
  console.log('Provider contract tests passed for GPT-5.6 Sol, Terra, and Luna.');
})().catch(error => {
  console.error(error);
  process.exit(1);
});
