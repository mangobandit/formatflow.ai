(function () {
  let app = null;
  let uxp = null;
  let fs = null;
  let indesignModule = null;

  // Lazily (re)acquire host APIs on every use: capturing them once at script load
  // breaks after plugin reloads, when the host module can load before InDesign is ready.
  function loadHostApis() {
    if (!app) {
      try {
        indesignModule = require("indesign");
        app = indesignModule.app || indesignModule;
      } catch (_) {
        // UI can load in a browser for visual inspection; document actions require InDesign UXP.
      }
    }
    if (!fs) {
      try {
        uxp = require("uxp");
        fs = uxp.storage && uxp.storage.localFileSystem;
      } catch (_) {}
    }
  }
  loadHostApis();

  function requireInDesign() {
    loadHostApis();
    if (!app) throw new Error("InDesign API is not available. Open this panel inside Adobe InDesign.");
    return app;
  }

  function requireFileSystem() {
    loadHostApis();
    if (!fs) throw new Error("UXP file system is not available. Load this as an InDesign UXP plugin.");
    return fs;
  }

  async function chooseOutputFolder() {
    return await requireFileSystem().getFolder();
  }

  function getActiveDocument() {
    const indesignApp = requireInDesign();
    // Prefer activeDocument directly — documents.length can misreport 0 in UXP
    // even while a document is open (e.g. right after a plugin reload).
    let doc = null;
    try { doc = indesignApp.activeDocument; } catch (_) {}
    if (doc) return doc;
    let docsArr = [];
    try { docsArr = collectionToArray(indesignApp.documents); } catch (_) {}
    if (docsArr.length) return docsArr[0];
    throw new Error("No InDesign document is open.");
  }

  function listLockedLayers(doc) {
    if (!doc) doc = getActiveDocument();
    let layers = [];
    try { layers = collectionToArray(doc.layers); } catch (_) {}
    return layers
      .filter(l => { try { return l.locked === true; } catch (_) { return false; } })
      .map(l => { try { return l.name || "(layer)"; } catch (_) { return "(layer)"; } });
  }

  function listFonts(doc) {
    if (!doc) doc = getActiveDocument();
    const out = [];
    let fonts = [];
    try { fonts = collectionToArray(doc.fonts); } catch (_) {}
    const FS = (indesignModule && indesignModule.FontStatus) || null;
    for (const f of fonts) {
      let name = "";
      try { name = f.fontFamily ? `${f.fontFamily} ${f.fontStyleName || ""}`.trim() : (f.name || "(font)"); } catch (_) { name = "(font)"; }
      let status = "unknown";
      if (FS && FS.INSTALLED !== undefined) {
        try {
          const s = f.status;
          if (s === FS.INSTALLED) status = "ok";
          else if (FS.SUBSTITUTED !== undefined && s === FS.SUBSTITUTED) status = "substituted";
          else status = "missing";
        } catch (_) {}
      }
      out.push({ name, status });
    }
    return out;
  }

  function getOpenDocuments() {
    const indesignApp = requireInDesign();
    let docs = [];
    try { docs = collectionToArray(indesignApp.documents); } catch (_) {}
    if (!docs.length) {
      try { const d = indesignApp.activeDocument; if (d) docs = [d]; } catch (_) {}
    }
    return docs;
  }

  function getCollectionLength(collection) {
    if (!collection) return 0;
    if (typeof collection.length === "number") return collection.length;
    if (typeof collection.count === "function") {
      try { return collection.count(); } catch (_) {}
    }
    return 0;
  }

  function getDocumentBaseName(doc) {
    const name = (doc && doc.name) || "Translated Document";
    return name.replace(/\.indd$/i, "").replace(/\.idml$/i, "");
  }

  function safeFilePart(value) {
    return String(value || "").replace(/[\\/:*?"<>|]/g, "-").replace(/\s+/g, " ").trim().slice(0, 120) || "Output";
  }

  function collectionToArray(collection) {
    if (!collection) return [];
    if (Array.isArray(collection)) return collection;
    if (typeof collection.getElements === "function") {
      try { return collection.getElements(); } catch (_) {}
    }
    if (collection.everyItem && typeof collection.everyItem === "function") {
      try { return collection.everyItem().getElements(); } catch (_) {}
    }
    const out = [];
    let count = getCollectionLength(collection);
    for (let i = 0; i < count; i++) {
      try { out.push(collection.item(i)); } catch (_) {
        try { out.push(collection[i]); } catch (__) {}
      }
    }
    return out.filter(Boolean);
  }

  function stringContents(obj) {
    try { return typeof obj.contents === "string" ? obj.contents : ""; }
    catch (_) { return ""; }
  }

  function textIsTranslatable(text) {
    if (!text) return false;
    const clean = String(text).replace(/[\s\r\n\t\uFEFF]+/g, "");
    return clean.length > 0;
  }

  function isLocked(obj) {
    let current = obj;
    for (let i = 0; i < 8 && current; i++) {
      try { if (current.locked === true) return true; } catch (_) {}
      try { if (current.itemLayer && current.itemLayer.locked === true) return true; } catch (_) {}
      try { current = current.parent; } catch (_) { current = null; }
    }
    try {
      const frames = collectionToArray(obj.parentStory && obj.parentStory.textContainers);
      if (frames.some(f => f.locked || (f.itemLayer && f.itemLayer.locked))) return true;
    } catch (_) {}
    return false;
  }

  function storyLabel(story, index) {
    try {
      const frames = collectionToArray(story.textContainers);
      const first = frames[0];
      if (first && first.name) return first.name;
    } catch (_) {}
    return `Story ${index + 1}`;
  }

  function getSelectedContainers() {
    const indesignApp = requireInDesign();
    const selection = collectionToArray(indesignApp.selection);
    const containers = [];
    for (const item of selection) {
      if (!item) continue;
      if (item.paragraphs || item.textStyleRanges || typeof item.contents === "string") containers.push(item);
      else if (item.parentStory) containers.push(item.parentStory);
      else if (item.texts) containers.push(item);
    }
    return containers;
  }

  function getStoryContainers(doc, scope) {
    if (!doc) doc = getActiveDocument();
    if (scope === "selection") {
      const selected = getSelectedContainers();
      if (selected.length) return selected;
      throw new Error("Selection scope needs selected text/frame in the currently active document. For file-first batch translation, use Whole document for now.");
    }
    return collectionToArray(doc.stories);
  }

  function collectParagraphs(container) {
    if (!container) return [];
    try {
      if (container.paragraphs) {
        const p = collectionToArray(container.paragraphs);
        if (p.length) return p;
      }
    } catch (_) {}
    try {
      if (container.parentStory && container.parentStory.paragraphs) return collectionToArray(container.parentStory.paragraphs);
    } catch (_) {}
    if (typeof container.contents === "string") return [container];
    return [];
  }

  function extractStyleRuns(paragraph, protectPlaceholders) {
    const ranges = collectionToArray(paragraph.textStyleRanges);
    if (!ranges.length) return [];
    const runs = [];
    for (const range of ranges) {
      const original = stringContents(range);
      if (!original) continue;
      const protectedResult = protectPlaceholders
        ? window.AIT_Protectors.protectText(original)
        : { text: original, placeholders: [] };
      runs.push({ ref: range, originalText: original, protectedText: protectedResult.text, placeholders: protectedResult.placeholders });
    }
    return runs;
  }

  function makeUnit(paragraph, unitNumber, options, sourceLabel) {
    const originalText = stringContents(paragraph);
    if (!textIsTranslatable(originalText)) return null;
    if (options.skipLocked && isLocked(paragraph)) {
      return { skipped: true, reason: "locked", originalText, sourceLabel };
    }

    const hasFinalReturn = /\r$/.test(originalText);
    const textForTranslation = hasFinalReturn ? originalText.replace(/\r$/, "") : originalText;
    const charStyleMode = !!options.preserveCharStyles;
    let runs = [];
    let preparedText = "";
    let placeholders = [];
    let mode = "plain";

    // Paragraph-safe mode is the default. Translating independent style-runs causes duplicated fragments
    // when InDesign splits a sentence across several ranges, so style-runs are now opt-in/advanced only.
    if (charStyleMode) {
      runs = extractStyleRuns(paragraph, options.protectPlaceholders).filter(r => textIsTranslatable(r.originalText));
      if (runs.length > 1 && runs.length <= 40) {
        mode = "tagged-runs";
        preparedText = window.AIT_Protectors.makeTaggedRuns(runs);
      }
    }

    if (!preparedText) {
      const protectedResult = options.protectPlaceholders
        ? window.AIT_Protectors.protectText(textForTranslation)
        : { text: textForTranslation, placeholders: [] };
      preparedText = protectedResult.text;
      placeholders = protectedResult.placeholders;
    }

    return {
      id: `u${String(unitNumber).padStart(5, "0")}`,
      ref: paragraph,
      originalText,
      textForTranslation,
      preparedText,
      placeholders,
      runs,
      mode,
      hasFinalReturn,
      sourceLabel
    };
  }

  function padIndex(n, width) {
    return String(n).padStart(width || 3, "0");
  }

  function extractUnitsFromDocument(doc, scope, options) {
    const containers = getStoryContainers(doc, scope);
    const units = [];
    const skipped = [];
    let unitNumber = 0;
    containers.forEach((container, cIndex) => {
      const paragraphs = collectParagraphs(container);
      const label = container === (container && container.parentStory) ? storyLabel(container.parentStory, cIndex) : storyLabel(container, cIndex);

      paragraphs.forEach((paragraph, pIndex) => {
        const unit = makeUnit(paragraph, unitNumber, options, label);
        if (!unit) return;
        if (unit.skipped) skipped.push(unit);
        else {
          // Stable structural ID + position info: translations are mapped back by
          // this ID, and the paragraph is re-resolved fresh at apply/verify time.
          unit.id = `s${padIndex(cIndex)}-p${padIndex(pIndex, 4)}`;
          unit.containerIndex = cIndex;
          unit.paragraphIndex = pIndex;
          units.push(unit);
          unitNumber++;
        }
      });

      // Table cells are separate text objects — story.paragraphs does not include
      // them, so without this whole tables would silently stay untranslated.
      let tables = [];
      try { tables = collectionToArray(container.tables); } catch (_) {}
      tables.forEach((table, tIndex) => {
        let cells = [];
        try { cells = collectionToArray(table.cells); } catch (_) {}
        cells.forEach((cell, cellIndex) => {
          let cellParas = [];
          try { cellParas = collectionToArray(cell.paragraphs); } catch (_) {}
          cellParas.forEach((para, cpIndex) => {
            const unit = makeUnit(para, unitNumber, options, `${label} / table ${tIndex + 1}`);
            if (!unit) return;
            if (unit.skipped) skipped.push(unit);
            else {
              unit.id = `s${padIndex(cIndex)}-t${padIndex(tIndex)}-c${padIndex(cellIndex, 4)}-p${padIndex(cpIndex)}`;
              unit.tablePath = { story: cIndex, table: tIndex, cell: cellIndex, para: cpIndex };
              units.push(unit);
              unitNumber++;
            }
          });
        });
      });
    });
    return { units, skipped };
  }

  function extractUnits(scope, options) {
    return extractUnitsFromDocument(getActiveDocument(), scope, options);
  }

  function restoreUnits(units) {
    for (const unit of units || []) {
      try { unit.ref.contents = unit.originalText; } catch (_) {}
    }
    recompose();
  }

  // Builds the exact text that will be written for a unit — shared by apply and
  // post-apply verification so both always agree.
  function buildPlainOutput(unit, translated) {
    let output = window.AIT_Protectors.restoreText(translated, unit.placeholders);
    output = window.AIT_Protectors.normalizeWhitespace(unit.textForTranslation, output);
    if (unit.hasFinalReturn && !/\r$/.test(output)) output += "\r";
    return output;
  }

  function applyPlainTranslation(unit, translated, targetRef) {
    const output = buildPlainOutput(unit, translated);
    const ref = targetRef || unit.ref;
    try { ref.contents = output; return { ok: true, fallback: false }; }
    catch (err) { return { ok: false, error: err.message || String(err) }; }
  }

  function applyTaggedRunTranslation(unit, translated) {
    const parsed = window.AIT_Protectors.parseTaggedRuns(translated);
    if (!parsed.length || parsed.length !== unit.runs.length) {
      return applyPlainTranslation(unit, stripTagsToPlain(unit, translated, true));
    }

    const byIndex = {};
    parsed.forEach(item => { byIndex[item.index] = item.text; });

    try {
      for (let i = unit.runs.length - 1; i >= 0; i--) {
        const run = unit.runs[i];
        let output = byIndex[i];
        if (typeof output !== "string") throw new Error(`Missing style run ${i}`);
        output = window.AIT_Protectors.restoreText(output, run.placeholders);
        output = window.AIT_Protectors.normalizeWhitespace(run.originalText, output);
        run.ref.contents = output;
      }
      return { ok: true, fallback: false };
    } catch (err) {
      return applyPlainTranslation(unit, stripTagsToPlain(unit, translated, true));
    }
  }

  function stripTagsToPlain(unit, translated, restoreRunPlaceholders) {
    const parsed = window.AIT_Protectors.parseTaggedRuns(translated);
    if (!parsed.length) return String(translated || "").replace(/<\/?r\b[^>]*>/gi, "");
    const pieces = [];
    parsed.sort((a, b) => a.index - b.index).forEach(item => {
      let value = item.text;
      if (restoreRunPlaceholders && unit.runs[item.index]) {
        value = window.AIT_Protectors.restoreText(value, unit.runs[item.index].placeholders);
      }
      pieces.push(value);
    });
    return pieces.join("");
  }

  // Fresh paragraph resolver: re-enumerates the document for every lookup and
  // resolves each unit by structural position (story/table/cell indices). InDesign
  // text wrappers are live ranges and can drift after a neighbouring write.
  function makeResolver(doc) {
    function resolve(unit, expectText) {
      let candidate = null;
      let stories = [];
      try { stories = collectionToArray(doc.stories); } catch (_) {}
      try {
        if (unit.tablePath) {
          const tables = collectionToArray(stories[unit.tablePath.story].tables);
          const cells = collectionToArray(tables[unit.tablePath.table].cells);
          const paragraphs = collectionToArray(cells[unit.tablePath.cell].paragraphs);
          candidate = paragraphs[unit.tablePath.para] || null;
        } else if (typeof unit.containerIndex === "number" && typeof unit.paragraphIndex === "number") {
          const paragraphs = collectionToArray(stories[unit.containerIndex].paragraphs);
          candidate = paragraphs[unit.paragraphIndex] || null;
        }
      } catch (_) {}
      if (candidate && typeof expectText === "string" && stringContents(candidate) !== expectText) candidate = null;
      return candidate;
    }

    return { resolve, invalidate() {} };
  }

  // Write + read-back: a write only counts if reading the paragraph back returns
  // exactly what was written. IMPORTANT: the read-back must go through a FRESHLY
  // resolved wrapper — the wrapper used for the write can go stale the moment
  // contents change, reporting false mismatches even when the write landed.
  function applyWithReadback(unit, translated, resolver) {
    const expected = buildPlainOutput(unit, translated);
    let lastError = "read-back mismatch after write";
    for (let attempt = 0; attempt < 2; attempt++) {
      const target = (resolver && resolver.resolve(unit, attempt === 0 ? unit.originalText : undefined)) || unit.ref;
      let writeErr = null;
      try {
        target.contents = expected;
      } catch (err) {
        writeErr = err;
        lastError = err.message || String(err);
      }
      if (resolver) resolver.invalidate(unit); // force fresh wrappers from here on
      if (!writeErr) {
        let actual = "";
        try {
          const fresh = resolver ? resolver.resolve(unit) : null;
          if (fresh) actual = stringContents(fresh);
        } catch (_) {}
        if (!actual) {
          try { actual = stringContents(target); } catch (_) {}
        }
        if (textsEquivalent(actual, expected)) return { ok: true, fallback: attempt > 0 };
        lastError = "read-back mismatch after write";
      }
    }
    return { ok: false, error: lastError };
  }

  function applyTranslations(units, translationMap, options, targetLanguage, doc) {
    if (!doc) { try { doc = getActiveDocument(); } catch (_) { doc = null; } }
    const resolver = doc ? makeResolver(doc) : null;

    const results = [];
    // Apply last-to-first: replacing contents changes text length, which shifts
    // later paragraph references in the same story (same reason style runs are
    // applied in reverse inside applyTaggedRunTranslation).
    for (let i = units.length - 1; i >= 0; i--) {
      const unit = units[i];
      const translated = translationMap[unit.id];
      let result;
      if (unit.mode === "tagged-runs" && options.preserveCharStyles) result = applyTaggedRunTranslation(unit, translated);
      else result = applyWithReadback(unit, translated, resolver);
      results.push(Object.assign({ id: unit.id, sourceLabel: unit.sourceLabel, mode: unit.mode }, result));
    }
    results.reverse();
    if (options.rtlSupport && targetLanguage && targetLanguage.rtl) applyRtl(doc, targetLanguage);
    recompose(doc);
    return results;
  }

  function textsEquivalent(a, b) {
    const norm = s => String(s == null ? "" : s)
      .replace(/\r$/, "")
      .replace(/[‘’]/g, "'")
      .replace(/[“”]/g, '"');
    return norm(a) === norm(b);
  }

  // Post-apply integrity check: re-reads every translated paragraph fresh from
  // the document and compares it against exactly what should have been written.
  // Catches shifted/clipped/partially-overwritten text before anything is saved.
  function verifyApplied(units, translationMap, doc, options) {
    if (!doc) doc = getActiveDocument();
    const resolver = makeResolver(doc);
    const failed = [];
    let checked = 0;
    for (const unit of units) {
      if (unit.mode === "tagged-runs" && options && options.preserveCharStyles) continue; // experimental path, not verified
      const translated = translationMap[unit.id];
      if (typeof translated !== "string") continue; // completeness is validated before apply
      const expected = buildPlainOutput(unit, translated);
      const target = resolver.resolve(unit) || unit.ref;
      let actual = "";
      try { actual = stringContents(target); } catch (_) { actual = ""; }
      checked++;
      if (!textsEquivalent(actual, expected)) {
        failed.push({ id: unit.id, sourceLabel: unit.sourceLabel, expected: expected.slice(0, 80), actual: String(actual).slice(0, 80) });
      }
    }
    return { checked, failed };
  }

  function applyRtl(doc, targetLanguage) {
    if (!doc) doc = getActiveDocument();
    const stories = collectionToArray(doc.stories);
    for (const story of stories) {
      try {
        if (story.storyPreferences) {
          const opts = indesignModule && (indesignModule.StoryDirectionOptions || {});
          story.storyPreferences.storyDirection = (opts && (opts.RIGHT_TO_LEFT_DIRECTION || opts.rightToLeftDirection)) || 1379028068;
        }
      } catch (_) {}
      try {
        const paragraphs = collectionToArray(story.paragraphs);
        for (const p of paragraphs) {
          if (p.paragraphDirection !== undefined) p.paragraphDirection = 1379028068;
        }
      } catch (_) {}
    }
  }

  function recompose(doc) {
    try { (doc || getActiveDocument()).recompose(); } catch (_) {}
  }

  function storyIsOverset(story) {
    try { if (story.overflows === true) return true; } catch (_) {}
    try {
      const frames = collectionToArray(story.textContainers);
      if (frames.some(f => f && f.overflows === true)) return true;
    } catch (_) {}
    return false;
  }

  function forEachStoryRange(story, fn) {
    let ranges = [];
    try { ranges = collectionToArray(story.textStyleRanges); } catch (_) {}
    for (const range of ranges) {
      try { fn(range); } catch (_) {}
    }
  }

  // Multi-stage overset solver, least invasive first:
  //   1-2. tighten tracking (invisible at these values)
  //   3.   reduce leading 5% (numeric leading only — auto leading is left alone)
  //   4-6. shrink point size 5% per pass (leading follows), floor 4pt
  // Each stage only touches stories that are still overset after the previous
  // one. options {tracking, leading, size} toggles the stage groups.
  function autoFitOverset(doc, options) {
    if (!doc) doc = getActiveDocument();
    const opts = Object.assign({
      tracking: true, leading: true, size: true,
      trackingMax: -25,  // thousandths of an em; user-configurable limit
      leadingPct: 5,     // max % leading reduction
      sizeMaxPct: 15,    // max % size reduction
      sizeMinPt: 4       // size floor in points
    }, options || {});
    // Defensive clamps — these also bound whatever the UI passes in.
    const trackingMax = Math.min(0, Math.max(-200, Number(opts.trackingMax) || -25));
    const leadingPct = Math.min(20, Math.max(0, Number(opts.leadingPct) || 5));
    const sizeMaxPct = Math.min(50, Math.max(0, Number(opts.sizeMaxPct) || 15));
    const sizeMinPt = Math.min(24, Math.max(1, Number(opts.sizeMinPt) || 4));
    const leadFactor = 1 - leadingPct / 100;

    function shrinkStage(story) {
      forEachStoryRange(story, r => {
        const s = r.pointSize;
        if (typeof s === "number" && s > sizeMinPt) r.pointSize = Math.max(sizeMinPt, s * 0.95);
        const l = r.leading;
        if (typeof l === "number" && l > sizeMinPt) r.leading = Math.max(sizeMinPt, l * 0.95);
      });
    }
    function trackingStage(target) {
      return story => forEachStoryRange(story, r => {
        const t = typeof r.tracking === "number" ? r.tracking : 0;
        if (t > target) r.tracking = target;
      });
    }

    const stages = [];
    if (opts.tracking && trackingMax < 0) {
      const half = Math.round(trackingMax / 2);
      if (half < 0) stages.push({ name: `tracking ${half}`, apply: trackingStage(half) });
      stages.push({ name: `tracking ${trackingMax}`, apply: trackingStage(trackingMax) });
    }
    if (opts.leading && leadingPct > 0) {
      stages.push({ name: `leading −${leadingPct}%`, apply: story => forEachStoryRange(story, r => {
        const l = r.leading;
        if (typeof l === "number" && l > sizeMinPt) r.leading = Math.max(sizeMinPt, l * leadFactor);
      }) });
    }
    if (opts.size && sizeMaxPct > 0) {
      // ~5% per pass; pass count derived from the user's total budget.
      const passes = Math.min(6, Math.max(1, Math.round(sizeMaxPct / 5)));
      for (let i = 0; i < passes; i++) stages.push({ name: "size −5%", apply: shrinkStage });
    }

    const result = { adjustedStories: 0, stagesUsed: [], stillOverset: 0 };
    const touched = {};
    for (const stage of stages) {
      recompose(doc);
      const overset = collectionToArray(doc.stories).filter(storyIsOverset);
      if (!overset.length) break;
      result.stagesUsed.push(stage.name);
      overset.forEach((story, idx) => {
        try {
          stage.apply(story);
          const key = storyLabel(story, idx);
          if (!touched[key]) { touched[key] = true; result.adjustedStories++; }
        } catch (_) {}
      });
    }
    recompose(doc);
    try { result.stillOverset = collectionToArray(doc.stories).filter(storyIsOverset).length; } catch (_) {}
    return result;
  }

  function countOversetStories(doc) {
    if (!doc) doc = getActiveDocument();
    let count = 0;
    const details = [];
    const stories = collectionToArray(doc.stories);
    stories.forEach((story, index) => {
      let over = false;
      try {
        const frames = collectionToArray(story.textContainers);
        over = frames.some(f => f && f.overflows === true);
      } catch (_) {}
      try { if (story.overflows === true) over = true; } catch (_) {}
      if (over) { count++; details.push(storyLabel(story, index)); }
    });
    return { count, details };
  }

  async function createUntranslatedLanguageCopy(outputFolder, sourceDoc, languageName) {
    if (!outputFolder) throw new Error("Choose an output folder first.");
    if (!sourceDoc) sourceDoc = getActiveDocument();
    const safeLanguage = safeFilePart(languageName);
    const base = safeFilePart(getDocumentBaseName(sourceDoc));
    const fileName = `${base} - ${safeLanguage}.indd`;
    const outFile = await outputFolder.createFile(fileName, { overwrite: true });

    if (typeof sourceDoc.saveACopy === "function") await sourceDoc.saveACopy(outFile, true);
    else if (typeof sourceDoc.saveACopyAs === "function") await sourceDoc.saveACopyAs(outFile);
    else throw new Error("This InDesign host does not expose saveACopy/saveACopyAs to UXP.");

    return outFile;
  }

  async function saveCopyForLanguage(outputFolder, doc, languageName) {
    return await createUntranslatedLanguageCopy(outputFolder, doc, languageName);
  }

  async function openDocumentFile(file) {
    const indesignApp = requireInDesign();
    const attempts = [file];
    try { if (file && file.nativePath) attempts.push(file.nativePath); } catch (_) {}
    try { if (file && file.fsName) attempts.push(file.fsName); } catch (_) {}
    let lastError;
    for (const candidate of attempts) {
      try {
        const opened = indesignApp.open(candidate);
        return opened || indesignApp.activeDocument;
      } catch (err) { lastError = err; }
    }
    throw new Error(`Could not open translated copy: ${lastError && lastError.message ? lastError.message : lastError}`);
  }

  function activateDocument(doc) {
    if (!doc) return;
    try { if (typeof doc.activate === "function") doc.activate(); return; } catch (_) {}
    try { requireInDesign().activeDocument = doc; } catch (_) {}
  }

  async function saveDocument(doc) {
    if (!doc) doc = getActiveDocument();
    try { if (typeof doc.save === "function") return await doc.save(); } catch (err) { throw err; }
    throw new Error("This InDesign host does not expose document.save().");
  }

  // Exports the document as IDML (InDesign Markup — a zip of XML).
  // 1768189292 is the 'idml' four-char code used by ExportFormat.INDESIGN_MARKUP.
  async function exportDocumentToIdml(doc, nativePath) {
    if (!doc) doc = getActiveDocument();
    const IDML_FORMAT = 1768189292;
    try {
      await doc.exportFile(IDML_FORMAT, nativePath);
      return nativePath;
    } catch (err) {
      try {
        const mod = indesignModule || {};
        const fmt = (mod.ExportFormat && (mod.ExportFormat.INDESIGN_MARKUP || mod.ExportFormat.indesignMarkup)) || IDML_FORMAT;
        await doc.exportFile(fmt, nativePath);
        return nativePath;
      } catch (err2) {
        throw new Error(`Could not export the document to IDML: ${(err2 && err2.message) || err2}. If the document has never been saved, save it once and retry.`);
      }
    }
  }

  // Exports the document as PDF using the app's current PDF export settings.
  // 1952403524 is the 'tPDF' four-char code used by ExportFormat.PDF_TYPE.
  async function exportDocumentToPdf(doc, nativePath) {
    if (!doc) doc = getActiveDocument();
    const PDF_FORMAT = 1952403524;
    const mod = indesignModule || {};
    const fmt = (mod.ExportFormat && (mod.ExportFormat.PDF_TYPE || mod.ExportFormat.pdfType)) || PDF_FORMAT;
    try {
      await doc.exportFile(fmt, nativePath);
      return nativePath;
    } catch (err) {
      try {
        await doc.exportFile(PDF_FORMAT, nativePath);
        return nativePath;
      } catch (err2) {
        throw new Error(`Could not export PDF: ${(err2 && err2.message) || err2}`);
      }
    }
  }

  async function saveDocumentAs(doc, fileEntry) {
    if (!doc) throw new Error("No document to save.");
    let lastErr;
    const candidates = [];
    if (fileEntry) candidates.push(fileEntry);
    try { if (fileEntry && fileEntry.nativePath) candidates.push(fileEntry.nativePath); } catch (_) {}
    for (const candidate of candidates) {
      try { return await doc.save(candidate); } catch (err) { lastErr = err; }
    }
    throw new Error(`Could not save document as .indd: ${lastErr && lastErr.message ? lastErr.message : lastErr}`);
  }

  async function closeDocument(doc, saveChanges) {
    if (!doc) return;
    const mod = indesignModule || {};
    const saveOptions = mod.SaveOptions || {};
    const yes = saveOptions.YES || saveOptions.yes || saveOptions.SAVE_CHANGES || saveOptions.saveChanges || 2036691744;
    const no = saveOptions.NO || saveOptions.no || saveOptions.NO_CHANGES || saveOptions.noChanges || 1852776480;
    const opt = saveChanges ? yes : no;
    try { if (typeof doc.close === "function") return await doc.close(opt); } catch (_) {}
    try { if (typeof doc.close === "function") return await doc.close(); } catch (_) {}
  }

  async function writeReportFiles(outputFolder, baseName, report) {
    if (!outputFolder) return [];
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    const safeBase = safeFilePart(baseName);
    const jsonFile = await outputFolder.createFile(`${safeBase} - translation-report-${stamp}.json`, { overwrite: true });
    await jsonFile.write(JSON.stringify(report, null, 2));
    const csvFile = await outputFolder.createFile(`${safeBase} - translation-report-${stamp}.csv`, { overwrite: true });
    await csvFile.write(reportToCsv(report));
    return [jsonFile, csvFile];
  }

  function reportToCsv(report) {
    const rows = [["language", "status", "units", "characters", "overset_count", "output_file", "errors"]];
    for (const item of report.languages || []) {
      rows.push([
        item.language,
        item.status,
        item.units,
        item.characters,
        item.oversetCount,
        item.outputFile || "",
        (item.errors || []).join(" | ")
      ]);
    }
    return rows.map(row => row.map(csvCell).join(",")).join("\n");
  }

  function csvCell(value) {
    const s = String(value == null ? "" : value);
    return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  }

  window.AIT_InDesignDom = {
    chooseOutputFolder,
    getActiveDocument,
    getOpenDocuments,
    listLockedLayers,
    listFonts,
    getDocumentBaseName,
    collectionToArray,
    extractUnits,
    extractUnitsFromDocument,
    restoreUnits,
    applyTranslations,
    verifyApplied,
    countOversetStories,
    autoFitOverset,
    createUntranslatedLanguageCopy,
    openDocumentFile,
    activateDocument,
    saveDocument,
    saveDocumentAs,
    exportDocumentToIdml,
    exportDocumentToPdf,
    applyRtl,
    closeDocument,
    saveCopyForLanguage,
    writeReportFiles,
    safeFilePart,
    recompose
  };
})();

/* ===== FormatFlow Translate — multi-format batch export (PNG/JPEG + PDF presets) ===== */
(function () {
  var NS = window.AIT_InDesignDom;
  if (!NS) return;

  function idLib() { try { return require("indesign"); } catch (e) { return {}; } }
  function host() { var w = idLib(); return (w && (w.app || w)) || null; }
  function pickEnum(obj, names, fallback) {
    if (obj) { for (var i = 0; i < names.length; i++) { if (obj[names[i]] !== undefined) return obj[names[i]]; } }
    return fallback;
  }
  function clampNum(v, lo, hi, dflt) {
    var n = Number(v); if (!isFinite(n)) return dflt;
    return Math.min(hi, Math.max(lo, n));
  }

  // List Adobe PDF export preset names (built-in + custom).
  NS.listPdfPresets = function () {
    var app = host(); var out = [];
    if (!app) return out;
    var arr = [];
    try { arr = NS.collectionToArray(app.pdfExportPresets); } catch (e) {}
    for (var i = 0; i < arr.length; i++) {
      try { if (arr[i] && arr[i].name) out.push(arr[i].name); } catch (e) {}
    }
    return out;
  };

  // PDF export with optional Adobe preset; falls back to the original current-settings export.
  var _origPdf = NS.exportDocumentToPdf;
  NS.exportDocumentToPdf = async function (doc, filePath, opts) {
    opts = opts || {};
    var presetName = opts && opts.preset;
    if (presetName && String(presetName).trim()) {
      var app = host(); var w = idLib();
      var fmt = pickEnum(w.ExportFormat, ["PDF_TYPE", "pdfType"], 1952403524);
      var preset = null;
      try {
        preset = app.pdfExportPresets.itemByName(String(presetName));
        if (preset && preset.isValid === false) preset = null;
      } catch (e) { preset = null; }
      if (preset) {
        try { await doc.exportFile(fmt, filePath, false, preset); return filePath; }
        catch (e) { /* fall through to current-settings export */ }
      }
    }
    return await _origPdf(doc, filePath);
  };

  function qualityNames(q) {
    switch (String(q || "maximum").toLowerCase()) {
      case "low": return ["LOW", "low"];
      case "medium": return ["MEDIUM", "medium"];
      case "high": return ["HIGH", "high"];
      default: return ["MAXIMUM", "maximum"];
    }
  }
  function colorNames(c) {
    switch (String(c || "rgb").toLowerCase()) {
      case "gray": case "grey": return ["GRAY", "gray", "GREY", "grey"];
      case "cmyk": return ["CMYK", "cmyk"];
      default: return ["RGB", "rgb"];
    }
  }
  function countRange(s) {
    var total = 0;
    String(s || "").split(",").forEach(function (part) {
      part = part.trim(); if (!part) return;
      var m = part.match(/^(\d+)\s*-\s*(\d+)$/);
      if (m) { total += Math.abs(parseInt(m[2], 10) - parseInt(m[1], 10)) + 1; }
      else { total += 1; }
    });
    return total || 1;
  }

  // PNG / JPEG export. kind = "png" | "jpeg".
  // Mirrors InDesign's native Export PNG/JPEG dialog and exports the whole
  // scope in ONE pass (fast). InDesign auto-names each page/spread file.
  // Returns an array whose length is the number of images written (for logging).
  NS.exportDocumentToImage = async function (doc, filePath, kind, opts) {
    opts = opts || {};
    var app = host(); var w = idLib();
    if (!app) throw new Error("InDesign API is not available.");
    var isPng = String(kind).toLowerCase() === "png";
    var fmt = isPng
      ? pickEnum(w.ExportFormat, ["PNG_FORMAT", "pngFormat"], 1347571558)
      : pickEnum(w.ExportFormat, ["JPG", "jpg", "JPEG", "jpeg"], 1246774599);
    var prefs = isPng ? app.pngExportPreferences : app.jpegExportPreferences;
    var spreads = !!opts.spreads;
    var res = clampNum(opts.resolution, 36, 2400, 150);

    // Shared settings.
    try { prefs.exportResolution = res; } catch (e) {}
    try { prefs.antiAlias = opts.antiAlias !== false; } catch (e) {}
    try { prefs.exportingSpread = spreads; } catch (e) {}
    try { prefs.useDocumentBleeds = !!opts.bleed; } catch (e) {}
    try { prefs.simulateOverprint = !!opts.overprint; } catch (e) {}

    if (isPng) {
      try { prefs.transparentBackground = !!opts.transparent; } catch (e) {}
      try { prefs.pngQuality = pickEnum(w.PNGQualityEnum, qualityNames(opts.quality), prefs.pngQuality); } catch (e) {}
      try { prefs.pngColorSpace = pickEnum(w.PNGColorSpaceEnum, colorNames(opts.colorSpace), prefs.pngColorSpace); } catch (e) {}
    } else {
      try { prefs.jpegQuality = pickEnum(w.JPEGOptionsQuality, qualityNames(opts.quality), prefs.jpegQuality); } catch (e) {}
      try { prefs.jpegColorSpace = pickEnum(w.JpegColorSpaceEnum, colorNames(opts.colorSpace), prefs.jpegColorSpace); } catch (e) {}
      try { prefs.embedColorProfile = opts.embedProfile !== false; } catch (e) {}
    }

    // Scope: All pages (one fast pass) or a specific range.
    var rangeProp = isPng ? "pngExportRange" : "jpegExportRange";
    var rangeEnum = isPng ? w.PNGExportRangeEnum : w.ExportRangeOrAllPages;
    var RANGE_ALL = pickEnum(rangeEnum, ["EXPORT_ALL", "exportAll"], null);
    var RANGE_SOME = pickEnum(rangeEnum, ["EXPORT_RANGE", "exportRange"], null);
    var wantRange = String(opts.scope || "all").toLowerCase() === "range" && opts.pageRange && String(opts.pageRange).trim();

    if (wantRange && RANGE_SOME !== null) {
      try { prefs[rangeProp] = RANGE_SOME; } catch (e) {}
      try { prefs.pageString = String(opts.pageRange); } catch (e) {}
    } else if (RANGE_ALL !== null) {
      try { prefs[rangeProp] = RANGE_ALL; } catch (e) {}
    }

    // Optional suffix inserted before the extension.
    var outPath = filePath;
    if (opts.suffix && String(opts.suffix).trim()) {
      var sfx = String(opts.suffix).replace(/[\\/:*?"<>|]/g, "-");
      var dot = filePath.lastIndexOf(".");
      outPath = dot < 0 ? (filePath + sfx) : (filePath.slice(0, dot) + sfx + filePath.slice(dot));
    }

    // Best-effort count of images that will be written, for the log.
    var count = 1;
    try {
      if (wantRange) count = countRange(opts.pageRange);
      else count = NS.collectionToArray(spreads ? doc.spreads : doc.pages).length || 1;
    } catch (e) { count = 1; }

    try {
      await doc.exportFile(fmt, outPath, false);
    } catch (err) {
      throw new Error("Could not export " + (isPng ? "PNG" : "JPEG") + ": " + ((err && err.message) || err));
    }
    return new Array(Math.max(1, count));
  };
})();
