const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const source = fs.readFileSync(path.join(__dirname, '..', 'src', 'indesign-dom.js'), 'utf8');
const context = vm.createContext({
  window: {},
  require() { throw new Error('Host module unavailable in overset unit test'); },
  console,
  String,
  Array,
  Object,
  Error
});
vm.runInContext(source, context);
const dom = context.window.AIT_InDesignDom;

function makeDocument(stories) {
  return {
    stories: { getElements: () => stories },
    recompose() {}
  };
}

function makeStory(id, range, isOverflowing) {
  return {
    id,
    get overflows() { return isOverflowing(range); },
    textStyleRanges: { getElements: () => [range] },
    textContainers: { getElements: () => [] }
  };
}

{
  const range = { tracking: 0, leading: 12, pointSize: 10 };
  const story = makeStory(1, range, current => current.tracking > -10);
  const result = dom.autoFitOverset(makeDocument([story]), {
    tracking: true,
    leading: true,
    size: true,
    trackingMax: -25
  });

  assert.strictEqual(result.adjustedStories, 1);
  assert.strictEqual(result.stillOverset, 0);
  assert.ok(range.tracking <= -10, 'tracking should be the first and only adjustment needed');
  assert.strictEqual(range.leading, 12, 'later ladder rungs must not run after text fits');
  assert.strictEqual(range.pointSize, 10, 'point size must remain untouched after a tracking-only fit');
}

{
  const range = { tracking: 0, leading: 12, pointSize: 10 };
  const story = makeStory(2, range, current => current.pointSize > 9.5);
  const result = dom.autoFitOverset(makeDocument([story]), {
    tracking: false,
    leading: true,
    size: true,
    leadingPct: 5,
    sizeMaxPct: 15
  });

  assert.strictEqual(result.adjustedStories, 1);
  assert.strictEqual(result.stillOverset, 0);
  assert.ok(range.leading < 12, 'leading should be reduced before point size');
  assert.strictEqual(range.pointSize, 9.5, 'one size rung should stop as soon as the story fits');
}

{
  const range = { tracking: 0, leading: 12, pointSize: 10 };
  const story = makeStory(3, range, () => true);
  const result = dom.autoFitOverset(makeDocument([story]), {
    tracking: false,
    leading: false,
    size: false
  });

  assert.strictEqual(result.adjustedStories, 0);
  assert.strictEqual(result.stillOverset, 1);
}

console.log('Overset auto-fit ladder tests passed.');
