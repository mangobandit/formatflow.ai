# Commercial hardening notes

This package is built as a complete working plugin project, not a prompt. Before Adobe Marketplace release, verify these host-specific behaviours on your exact InDesign versions:

1. Secure storage: the plugin uses host secure storage when available and falls back with a warning. For paid enterprise release, enforce secure storage or session-only keys.
2. Licensing: add your payment/licensing provider before public distribution.
3. Privacy: add a customer-facing policy explaining BYOK, provider requests, data retention, and document handling.
4. Provider models: keep model names configurable because OpenAI/Anthropic/Gemini model availability changes.
5. Visual regression: test a representative pack of Greif-style brochures, catalogs, manuals, and event decks.
6. Error telemetry: for commercial release, add opt-in anonymous error reporting without document text.
