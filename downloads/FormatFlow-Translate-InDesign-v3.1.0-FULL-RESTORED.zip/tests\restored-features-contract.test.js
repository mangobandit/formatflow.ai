const assert = require('assert');
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const ui = fs.readFileSync(path.join(root, 'src', 'ui.js'), 'utf8');
const dom = fs.readFileSync(path.join(root, 'src', 'indesign-dom.js'), 'utf8');
const idml = fs.readFileSync(path.join(root, 'src', 'idml-engine.js'), 'utf8');

assert.match(html, /id="tabFit"/, 'standalone overset fixer tab must remain present');
assert.match(html, /id="autoFit"/, 'automatic post-translation fitting must remain configurable');
assert.match(html, /value="auto"[\s\S]*value="dark"[\s\S]*value="light"/, 'Auto, Dark, and Light themes must remain available');
assert.match(html, /id="toggleAllLanguages"/, 'language panel must contain one check/uncheck-all checkbox');
assert.match(ui, /toggleAllLanguages/, 'language bulk checkbox must be wired into the UI');
assert.match(ui, /autoFitOverset/, 'standalone fixer must call the real InDesign overset solver');
assert.match(dom, /function autoFitOverset\(/, 'InDesign DOM must contain the working overset solver');
assert.match(dom, /autoFitOverset,/, 'overset solver must be exported to the panel');
assert.match(idml, /dom\.autoFitOverset\(/, 'translated documents must run the overset solver before save/export');

console.log('Restored feature contract tests passed.');
