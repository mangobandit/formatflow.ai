# FormatFlow Translate — Day-1 Fill-in-the-Blanks

The product is finished. The *only* thing standing between it and a live Adobe Marketplace
listing is a handful of values you collect from your own accounts. Fill in every `____`
below, hand it back, and the wiring is a ~15-minute job (it maps 1:1 to
[`CONFIG_PASTE_MAP.md`](CONFIG_PASTE_MAP.md)), then repackage → QA → upload.

> Don't edit code. Just fill in the blanks. Leave a value as `____` if you haven't got it yet —
> the gaps tell us exactly what's still blocking launch.

---

## A. Adobe Developer Distribution (gates the upload)

1. Create the plugin listing in the Adobe Developer Distribution portal.
2. Adobe assigns a plugin ID. Paste it here:

   - **Adobe-assigned plugin ID:** `____`
   - Test InDesign version (must be ≥ 18.5.0): `____`

## B. Lemon Squeezy (gates paid enforcement)

Create one product with three prices that **match the site exactly**: €0 / 14-day trial,
€12 / month, €120 / year. Then grab the checkout URLs.

- **Monthly checkout URL:** `____`
- **Yearly checkout URL:** `____`
- Confirm LS prices match €0 / €12 / €120 (yes/no): `____`

## C. URLs + support (live links the plugin and site point at)

- **Support email** (does `matt@bear-cg.com` exist and route to you? if not, the real one): `____`
- **Live plugin page URL** (on formatflow.ai): `____`
- **FAQ anchor URL:** `____`
- **Docs URL:** `____`

> ⚠️ If the plugin page / FAQ / docs don't exist on formatflow.ai yet, that's a real
> sub-blocker — note it: `____`

## D. QA pass (the launch-gate)

Run `docs/QA_PASS_FAIL.md` end-to-end on a real `.indd` file in InDesign ≥ 18.5:

- Translate a real document, all providers you'll advertise (yes/no each):
  OpenAI `____` · Anthropic `____` · Gemini `____` · Ollama `____`
- Private mode hard-blocks cloud with a local model (yes/no): `____`
- Result: **PASS / FAIL** → `____`  (any failures, list them): `____`

---

## When A–D are filled in, the launch sequence is:

1. **Wire values** into `manifest.json` + `src/license.js` + `docs/site/index.html` (the paste-map — ~15 min).
2. `node scripts/package.js` → rebuilds `formatflow-translate.zip` (minified, runtime-only).
3. Rename to `.ccx` (or UXP Developer Tools → Package).
4. Upload the `.ccx` to the Adobe listing from step A.
5. Submit for review.

## Reality check before you announce (honesty gate)

- Edge is **on-device Ollama + Private mode**, NOT "first to market" (15+ competitors exist — see `PITFALLS_AND_COMPETITION.md`).
- Claim "48 languages," never "50+".
- Private-mode claim is "guaranteed nothing leaves the machine" **only with a local Ollama model installed** — don't drop that caveat.
