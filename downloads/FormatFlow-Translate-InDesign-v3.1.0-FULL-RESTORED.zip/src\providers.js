(function () {
  const DEFAULT_MODELS = {
    deepl: ["prefer_quality_optimized", "quality_optimized", "latency_optimized"],
    openai: ["gpt-5.6-sol", "gpt-5.6-terra", "gpt-5.6-luna"],
    anthropic: ["claude-opus-4-8", "claude-sonnet-4-6", "claude-haiku-4-5"],
    gemini: ["gemini-2.5-pro", "gemini-2.5-flash", "gemini-2.0-flash"],
    ollama: ["aya-expanse", "qwen2.5", "llama3.3", "mistral"],
    mock: ["mock-echo"]
  };

  const MODEL_LABELS = {
    "gpt-5.6-sol": "GPT-5.6 Sol — highest quality",
    "gpt-5.6-terra": "GPT-5.6 Terra — balanced",
    "gpt-5.6-luna": "GPT-5.6 Luna — fastest"
  };

  const OPENAI_MODEL_MIGRATIONS = {
    "gpt-5.6": "gpt-5.6-sol",
    "gpt-5.5": "gpt-5.6-sol",
    "gpt-5.4": "gpt-5.6-sol",
    "gpt-5-mini": "gpt-5.6-terra",
    "gpt-5.4-mini": "gpt-5.6-terra",
    "gpt-4.1": "gpt-5.6-terra",
    "gpt-4.1-mini": "gpt-5.6-terra",
    "gpt-4o": "gpt-5.6-terra",
    "gpt-4o-mini": "gpt-5.6-terra"
  };

  function getDefaultModel(provider) {
    return (DEFAULT_MODELS[provider] || DEFAULT_MODELS.deepl)[0];
  }

  function normalizeModel(provider, model) {
    const requested = String(model || "").trim();
    if (provider === "openai" && OPENAI_MODEL_MIGRATIONS[requested]) {
      return OPENAI_MODEL_MIGRATIONS[requested];
    }
    return requested || getDefaultModel(provider);
  }

  function getModelLabel(provider, model) {
    return provider === "openai" && MODEL_LABELS[model] ? MODEL_LABELS[model] : model;
  }

  const LOCAL_PROVIDERS = ["ollama", "mock"]; // run on this machine; no text leaves
  const DEEPL_MAX_TEXTS_PER_REQUEST = 50;
  const DEEPL_MAX_BODY_BYTES = 118 * 1024; // DeepL hard limit is 128 KiB; leave headroom.

  const DEEPL_TARGET_CODE_MAP = {
    "en": "EN-US",
    "en-us": "EN-US",
    "en-gb": "EN-GB",
    "pt": "PT-PT",
    "pt-br": "PT-BR",
    "es": "ES",
    "es-419": "ES-419",
    "zh": "ZH-HANS",
    "zh-tw": "ZH-HANT",
    "no": "NB"
  };

  const DEEPL_SOURCE_CODE_MAP = {
    "en": "EN",
    "en-us": "EN",
    "en-gb": "EN",
    "pt": "PT",
    "pt-br": "PT",
    "es-419": "ES",
    "zh": "ZH",
    "zh-tw": "ZH",
    "no": "NB"
  };

  async function translateBatch(providerName, input) {
    // Hard privacy gate — every translation path (batch, repair, quick) funnels
    // through here, so this is the one place that can guarantee "nothing leaves
    // the machine". If Private mode is on, refuse any cloud provider BEFORE the
    // provider object is even created — no network call can happen.
    if (input && input.localOnly && LOCAL_PROVIDERS.indexOf(providerName) === -1) {
      throw new Error(
        `Private mode is ON — refusing to send text to "${providerName}" (a cloud provider). ` +
        `Choose Ollama (on-device) or turn off Private mode in Settings.`
      );
    }
    const provider = createProvider(providerName);
    return await provider.translateBatch(input);
  }

  async function getDeepLUsage(apiKey) {
    if (!apiKey) throw new Error("Missing DeepL API key.");
    const url = `${deeplBaseUrl(apiKey)}/v2/usage`;
    const res = await fetchWithRetry(url, {
      method: "GET",
      headers: {
        "Authorization": `DeepL-Auth-Key ${apiKey}`
      }
    }, 2, "DeepL usage");
    return await res.json();
  }

  function createProvider(providerName) {
    if (providerName === "deepl") return new DeepLProvider();
    if (providerName === "openai") return new OpenAIProvider();
    if (providerName === "anthropic") return new AnthropicProvider();
    if (providerName === "gemini") return new GeminiProvider();
    if (providerName === "ollama") return new OllamaProvider();
    if (providerName === "mock") return new MockProvider();
    return new DeepLProvider();
  }

  function buildSystemPrompt(input) {
    const glossaryLines = window.AIT_Glossary.toPromptLines(input.glossary || []);
    const quality = input.qualityMode || "layout-tight";
    const fitRule = "LENGTH RULE: the printed layout is fixed, so the translation must occupy roughly the same space as the source. Stay within ±10% of the source character count for short blocks (headings, labels, callouts, sidebar lines, table cells) and within +15% for body paragraphs. Languages like Dutch, German, and French naturally run longer than English — counter this with tight idiomatic phrasing, shorter synonyms, and no filler words. Compact AND grammatically flawless; never telegraphic, never truncated.";
    const layoutRule = quality === "premium"
      ? `Use high-quality professional localization. Keep meaning complete, tone natural, terminology consistent. ${fitRule}`
      : quality === "balanced"
        ? `Balance accuracy and natural target-language flow. ${fitRule}`
        : fitRule;

    return [
      "You are a senior professional translator producing print-ready copy inside Adobe InDesign documents.",
      "Translate every supplied unit into the target language only.",
      "QUALITY BAR: the translation must read as if it was originally written by an educated native speaker of the target language — flawless grammar, natural word order, idiomatic phrasing, and a register, tone, and terminology that stay consistent across every unit of the document.",
      "Each translated unit must be a complete, grammatical rendering of its entire source unit, from the first word to the last. Never output a sentence fragment. Never drop, abbreviate, or cut words at the start or end of a unit.",
      "Mirror the capitalization style of each source unit: ALL CAPS stays ALL CAPS, Title Case maps to the target language's natural equivalent for headings, sentence case stays sentence case following the target language's own capitalization rules (e.g. German noun capitalization, French accent rules).",
      "Use correct target-language punctuation and typographic conventions (quotation marks, decimal separators, spacing before punctuation where the language requires it).",
      "Never sacrifice grammatical correctness or natural phrasing for brevity.",
      "These units are paragraphs from one continuous document (headings, body copy, bullet list items). Translate each so it reads coherently in that role: headings like headings, bullets like parallel bullets with consistent grammatical form.",
      "Return valid JSON only. No markdown, no comments, no explanations, no surrounding text.",
      "The returned JSON must contain exactly one translated text for every input id.",
      "Never merge units, split units, drop units, duplicate source text, or leave source language attached before/after the translation.",
      "Do not copy the source text unless it is a brand name, product code, URL, email, unit, placeholder, or a term the glossary says to keep.",
      "Preserve IDs exactly. Preserve placeholders like [[[AIT_PH_0000]]] exactly.",
      "Preserve XML-like style tags such as <r id=\"0\">...</r> exactly if they appear, and translate only the human text inside them.",
      "Preserve manual line breaks, bullet/numbering intent, units, product codes, URLs, emails, variables, and bracketed tokens.",
      "Use the user context and glossary as mandatory terminology guidance when terms appear.",
      layoutRule,
      `Industry/tone: ${input.industry || "General business"}.`,
      input.context ? `Client/project context: ${input.context}` : "",
      glossaryLines ? `Glossary, mandatory when terms appear:\n${glossaryLines}` : ""
    ].filter(Boolean).join("\n");
  }

  function buildUserPrompt(input) {
    return JSON.stringify({
      task: "translate_indesign_units",
      source_language: input.sourceLanguageName || input.sourceLang || "auto detect",
      target_language: `${input.targetLanguage.name} (${input.targetLanguage.code})`,
      contract: {
        return_json_only: true,
        required_shape: { translations: [{ id: "same id as input", text: "target language translation only" }] },
        must_return_all_ids: true,
        preserve_placeholders_exactly: true,
        no_source_language_duplicates: true
      },
      units: input.units.map(u => ({ id: u.id, text: u.preparedText }))
    });
  }

  function parseTranslations(raw, expectedIds) {
    const text = window.AIT_Protectors.stripFences(raw);
    let parsed;
    try { parsed = JSON.parse(text); }
    catch (err) {
      const first = text.indexOf("{");
      const last = text.lastIndexOf("}");
      if (first >= 0 && last > first) parsed = JSON.parse(text.slice(first, last + 1));
      else throw new Error("Provider did not return valid JSON.");
    }
    const arr = Array.isArray(parsed) ? parsed : parsed.translations;
    if (!Array.isArray(arr)) throw new Error("Provider JSON missing translations array.");
    const map = {};
    for (const item of arr) {
      if (!item || typeof item.id === "undefined") continue;
      map[String(item.id)] = typeof item.text === "string" ? item.text : String(item.text || "");
    }
    const missing = expectedIds.filter(id => !(id in map));
    if (missing.length) throw new Error(`Provider JSON missing translated unit IDs: ${missing.slice(0, 8).join(", ")}${missing.length > 8 ? "..." : ""}`);
    return map;
  }

  function extractOpenAIText(data) {
    if (typeof data.output_text === "string") return data.output_text;
    const chunks = [];
    for (const item of data.output || []) {
      for (const part of item.content || []) {
        if ((part.type === "output_text" || part.type === "text") && part.text) chunks.push(part.text);
      }
    }
    return chunks.join("\n");
  }

  async function fetchWithRetry(url, options, retries, label) {
    let lastError;
    for (let attempt = 0; attempt <= retries; attempt++) {
      try {
        const res = await fetch(url, options);
        if (res.ok) return res;
        const body = await res.text().catch(() => "");
        const retryable = [408, 409, 425, 429, 500, 502, 503, 504].includes(res.status);
        const err = new Error(`${label} request failed (${res.status}): ${body.slice(0, 1000)}`);
        if (!retryable || attempt === retries) throw err;
        lastError = err;
      } catch (err) {
        lastError = err;
        if (attempt === retries) throw err;
      }
      const wait = Math.min(16000, 900 * Math.pow(2, attempt)) + Math.round(Math.random() * 400);
      await sleep(wait);
    }
    throw lastError;
  }

  function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

  function normalizeCode(code) {
    return String(code || "").trim().replace(/_/g, "-");
  }

  function toDeepLTargetCode(language) {
    const code = normalizeCode(language && language.code);
    if (!code || code === "auto") throw new Error("DeepL needs a concrete target language.");
    return DEEPL_TARGET_CODE_MAP[code.toLowerCase()] || code.toUpperCase();
  }

  function toDeepLSourceCode(input) {
    const code = normalizeCode(input && input.sourceLang);
    if (!code || code === "auto") return "";
    return DEEPL_SOURCE_CODE_MAP[code.toLowerCase()] || code.toUpperCase();
  }

  function getDeepLModelType(model) {
    const allowed = DEFAULT_MODELS.deepl;
    return allowed.indexOf(model) !== -1 ? model : getDefaultModel("deepl");
  }

  function deeplBaseUrl(apiKey) {
    return String(apiKey || "").trim().toLowerCase().endsWith(":fx")
      ? "https://api-free.deepl.com"
      : "https://api.deepl.com";
  }

  function byteLength(value) {
    const text = String(value == null ? "" : value);
    if (typeof TextEncoder !== "undefined") return new TextEncoder().encode(text).length;
    return unescape(encodeURIComponent(text)).length;
  }

  function buildDeepLContext(input) {
    const lines = [];
    const quality = input.qualityMode || "layout-tight";
    lines.push("Translate for print-ready Adobe InDesign copy. Keep the meaning complete, natural, and concise enough to fit the original layout.");
    if (quality === "premium") lines.push("Use polished professional localization with consistent terminology and tone.");
    else if (quality === "balanced") lines.push("Balance accuracy, natural target-language flow, and compact phrasing.");
    else lines.push("Prefer compact idiomatic phrasing for headings, labels, callouts, table cells, and fixed-layout text.");
    if (input.industry) lines.push(`Industry/tone: ${input.industry}.`);
    if (input.context) lines.push(`Project context: ${input.context}`);
    const glossaryLines = window.AIT_Glossary.toPromptLines(input.glossary || []);
    if (glossaryLines) lines.push(`Terminology guidance:\n${glossaryLines}`);
    return lines.join("\n").slice(0, 10000);
  }

  function tokenTagsToXml(text) {
    return String(text == null ? "" : text)
      .replace(/\[\[\[(AIT_PH_\d{4}|AIT_PI_\d+)\]\]\]/g, '<ph data-id="$1"/>');
  }

  function xmlTokenTagsToPlaceholders(text) {
    return String(text == null ? "" : text)
      .replace(/<ph\b[^>]*(?:data-id|id)=["'](AIT_(?:PH_\d{4}|PI_\d+))["'][^>]*>[\s\S]*?<\/ph>/gi, "[[[$1]]]")
      .replace(/<ph\b[^>]*(?:data-id|id)=["'](AIT_(?:PH_\d{4}|PI_\d+))["'][^>]*\/>/gi, "[[[$1]]]");
  }

  function stripDeepLWrapper(text) {
    const source = String(text == null ? "" : text).trim();
    const match = /^<ait\b[^>]*>([\s\S]*)<\/ait>$/i.exec(source);
    if (match) return match[1];
    return source.replace(/^<ait\b[^>]*>/i, "").replace(/<\/ait>$/i, "");
  }

  function toDeepLText(unit) {
    const P = window.AIT_Protectors;
    const raw = unit && unit.mode === "tagged-runs"
      ? String(unit.preparedText || "")
      : P.escapeXmlText(unit && unit.preparedText || "");
    return `<ait>${tokenTagsToXml(raw)}</ait>`;
  }

  function fromDeepLText(unit, raw) {
    const P = window.AIT_Protectors;
    let text = xmlTokenTagsToPlaceholders(stripDeepLWrapper(raw));
    if (!unit || unit.mode !== "tagged-runs") text = P.unescapeXmlText(text);
    return text;
  }

  function buildDeepLPayload(input, texts, targetLang, sourceLang, context, modelType) {
    const payload = {
      text: texts,
      target_lang: targetLang,
      model_type: modelType,
      context,
      tag_handling: "xml",
      tag_handling_version: "v2",
      split_sentences: "nonewlines",
      preserve_formatting: true,
      ignore_tags: ["ph"],
      show_billed_characters: true
    };
    if (sourceLang) payload.source_lang = sourceLang;
    return payload;
  }

  function makeDeepLBatches(input, items, targetLang, sourceLang, context, modelType) {
    const batches = [];
    let current = [];
    for (const item of items) {
      const candidate = current.concat(item);
      const body = JSON.stringify(buildDeepLPayload(input, candidate.map(i => i.text), targetLang, sourceLang, context, modelType));
      if (current.length && (candidate.length > DEEPL_MAX_TEXTS_PER_REQUEST || byteLength(body) > DEEPL_MAX_BODY_BYTES)) {
        batches.push(current);
        current = [item];
      } else {
        current = candidate;
      }
      const singleBody = JSON.stringify(buildDeepLPayload(input, current.map(i => i.text), targetLang, sourceLang, context, modelType));
      if (current.length === 1 && byteLength(singleBody) > DEEPL_MAX_BODY_BYTES) {
        throw new Error(`DeepL request unit ${item.unit.id} is too large for the 128 KiB API request limit.`);
      }
    }
    if (current.length) batches.push(current);
    return batches;
  }

  class DeepLProvider {
    async translateBatch(input) {
      if (!input.apiKey) throw new Error("Missing DeepL API key.");
      const targetLang = toDeepLTargetCode(input.targetLanguage);
      const sourceLang = toDeepLSourceCode(input);
      const modelType = getDeepLModelType(input.model);
      const context = buildDeepLContext(input);
      const items = input.units.map(unit => ({ unit, text: toDeepLText(unit) }));
      const batches = makeDeepLBatches(input, items, targetLang, sourceLang, context, modelType);
      const map = {};
      const url = `${deeplBaseUrl(input.apiKey)}/v2/translate`;

      for (const batch of batches) {
        const payload = buildDeepLPayload(input, batch.map(item => item.text), targetLang, sourceLang, context, modelType);
        const body = JSON.stringify(payload);
        const requestBytes = byteLength(body);
        const startedAt = Date.now();
        if (typeof input.providerLog === "function") {
          input.providerLog(`DeepL POST /v2/translate: ${batch.length} document text unit(s), ${requestBytes.toLocaleString()} request bytes.`);
        }
        const res = await fetchWithRetry(url, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `DeepL-Auth-Key ${input.apiKey}`
          },
          body
        }, 5, "DeepL");
        const data = await res.json();
        const elapsedMs = Date.now() - startedAt;
        const translations = data.translations || [];
        if (translations.length !== batch.length) {
          throw new Error(`DeepL returned ${translations.length} translation(s) for ${batch.length} text unit(s).`);
        }
        // DeepL reports billed_characters on each translation object (when
        // show_billed_characters=true), NOT at the top level of the response.
        // Sum across the batch; fall back to a top-level field only if a future
        // API version ever puts one there.
        const sawBilledCharacters = translations.some(t => t && typeof t.billed_characters === "number")
          || typeof data.billed_characters === "number";
        const billedCharacters = translations.reduce(
          (sum, t) => sum + (t && typeof t.billed_characters === "number" ? t.billed_characters : 0),
          typeof data.billed_characters === "number" ? data.billed_characters : 0
        );
        if (typeof input.providerLog === "function") {
          const billed = sawBilledCharacters
            ? `, ${billedCharacters.toLocaleString()} billed source characters`
            : ", billed source characters not included in this response";
          input.providerLog(`DeepL request accepted: ${batch.length} document text unit(s)${billed}, ${elapsedMs.toLocaleString()} ms.`);
        }
        if (typeof input.deepLRequestAccepted === "function") {
          input.deepLRequestAccepted({
            textUnits: batch.length,
            billedCharacters: sawBilledCharacters ? billedCharacters : null,
            targetLang,
            elapsedMs,
            requestBytes,
            modelType
          });
        }
        translations.forEach((item, index) => {
          map[batch[index].unit.id] = fromDeepLText(batch[index].unit, item.text || "");
        });
      }
      return map;
    }
  }

  class OpenAIProvider {
    async translateBatch(input) {
      if (!input.apiKey) throw new Error("Missing OpenAI API key.");
      const system = buildSystemPrompt(input);
      const user = buildUserPrompt(input);
      const model = normalizeModel("openai", input.model || getDefaultModel("openai"));
      const payload = {
        model,
        input: [
          { role: "system", content: [{ type: "input_text", text: system }] },
          { role: "user", content: [{ type: "input_text", text: user }] }
        ],
        max_output_tokens: Math.min(16000, Math.max(2048, Math.round(input.units.reduce((s, u) => s + String(u.preparedText || "").length, 0) * 2.2)))
      };
      // GPT-5.6 defaults to medium reasoning. The previous translation route was
      // non-reasoning, so keep that latency/cost contract explicit on Responses.
      if (/^gpt-5\.6(?:-|$)/i.test(model)) payload.reasoning = { effort: "none" };
      else if (/^gpt-4/i.test(model)) payload.temperature = 0.1;

      // If the API still rejects a parameter for this model, strip it and retry.
      for (let attempt = 0; attempt < 4; attempt++) {
        try {
          const res = await fetchWithRetry("https://api.openai.com/v1/responses", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${input.apiKey}`
            },
            body: JSON.stringify(payload)
          }, 5, "OpenAI");
          const data = await res.json();
          return parseTranslations(extractOpenAIText(data), input.units.map(u => u.id));
        } catch (err) {
          const unsupported = /Unsupported parameter: '([^']+)'/.exec(err && err.message ? err.message : "");
          if (unsupported && Object.prototype.hasOwnProperty.call(payload, unsupported[1])) {
            delete payload[unsupported[1]];
            continue;
          }
          throw err;
        }
      }
      throw new Error("OpenAI request failed: could not find a parameter set this model accepts.");
    }
  }

  class AnthropicProvider {
    async translateBatch(input) {
      if (!input.apiKey) throw new Error("Missing Anthropic API key.");
      // No temperature: sampling parameters are removed on claude-opus-4-7+ (400 if sent).
      const payload = {
        model: input.model || getDefaultModel("anthropic"),
        max_tokens: Math.min(16000, Math.max(2048, Math.round(input.units.reduce((s, u) => s + String(u.preparedText || "").length, 0) * 2.2))),
        system: buildSystemPrompt(input),
        messages: [{ role: "user", content: buildUserPrompt(input) }]
      };
      const res = await fetchWithRetry("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": input.apiKey,
          "anthropic-version": "2023-06-01"
        },
        body: JSON.stringify(payload)
      }, 5, "Anthropic");
      const data = await res.json();
      const raw = (data.content || []).map(p => p.text || "").join("\n");
      return parseTranslations(raw, input.units.map(u => u.id));
    }
  }

  class GeminiProvider {
    async translateBatch(input) {
      if (!input.apiKey) throw new Error("Missing Gemini API key.");
      const model = encodeURIComponent(input.model || getDefaultModel("gemini"));
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;
      const payload = {
        systemInstruction: { parts: [{ text: buildSystemPrompt(input) }] },
        contents: [{ role: "user", parts: [{ text: buildUserPrompt(input) }] }],
        generationConfig: { responseMimeType: "application/json", temperature: 0.1 }
      };
      const res = await fetchWithRetry(url, {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-goog-api-key": input.apiKey },
        body: JSON.stringify(payload)
      }, 5, "Gemini");
      const data = await res.json();
      const raw = (data.candidates || []).flatMap(c => (c.content && c.content.parts) || []).map(p => p.text || "").join("\n");
      return parseTranslations(raw, input.units.map(u => u.id));
    }
  }

  // Local models via Ollama (https://github.com/ollama/ollama) — free, runs on
  // this machine, OpenAI-compatible API on localhost:11434. No API key needed.
  class OllamaProvider {
    async translateBatch(input) {
      const payload = {
        model: input.model || getDefaultModel("ollama"),
        stream: false,
        temperature: 0.1,
        messages: [
          { role: "system", content: buildSystemPrompt(input) },
          { role: "user", content: buildUserPrompt(input) }
        ]
      };
      let res;
      try {
        res = await fetchWithRetry("http://127.0.0.1:11434/v1/chat/completions", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        }, 2, "Ollama");
      } catch (err) {
        const msg = err && err.message ? err.message : String(err);
        if (/failed|network|fetch|refused|ECONN/i.test(msg)) {
          throw new Error(`Could not reach Ollama at http://127.0.0.1:11434 — is Ollama installed and running, and the model pulled (e.g. "ollama pull ${payload.model}")? (${msg})`);
        }
        throw err;
      }
      const data = await res.json();
      const raw = data.choices && data.choices[0] && data.choices[0].message ? data.choices[0].message.content : "";
      return parseTranslations(raw, input.units.map(u => u.id));
    }
  }

  class MockProvider {
    async translateBatch(input) {
      await sleep(120);
      const map = {};
      for (const unit of input.units) {
        map[unit.id] = `[${input.targetLanguage.name}] ${unit.preparedText}`;
      }
      return map;
    }
  }

  function estimateCost(units, selectedLanguages) {
    const chars = units.reduce((sum, unit) => sum + String(unit.originalText || "").length, 0);
    const approxTokensPerLanguage = Math.ceil(chars / 3.6);
    const totalApproxTokens = approxTokensPerLanguage * Math.max(1, selectedLanguages.length);
    return { chars, approxTokensPerLanguage, totalApproxTokens };
  }

  window.AIT_Providers = {
    DEFAULT_MODELS,
    getDefaultModel,
    normalizeModel,
    getModelLabel,
    getDeepLUsage,
    translateBatch,
    estimateCost,
    buildSystemPrompt
  };
})();
