# Feedback fixes in v1.1

## 1. Safe file-first workflow

The plugin no longer translates the live original and then saves a copy afterwards.

New order for each language:

1. Use the open document only as the source.
2. Save a clean untranslated copy to the selected output folder.
3. Open that copied `.indd` file.
4. Translate inside the copied file only.
5. Save and close the copied file.
6. Reactivate the original document.

This means the original document should not be edited during a batch run.

## 2. Cleaner UI

The language picker is now grouped into regions with tick boxes:

- Europe
- Africa
- Middle East
- Asia
- Americas

Quick batch buttons are generic, not client-personalized:

- Core 20
- Europe
- Africa
- Asia
- Middle East
- Americas

## 3. Better translation control

Changes made to reduce bad/rushed output:

- Smaller chunks: 3,200 characters instead of 9,000.
- Stronger prompt rules: translate into target only, do not duplicate source text, return every ID.
- Layout-tight mode is the default.
- Low temperature is used for supported providers.
- Extra retries are used for temporary provider failures.

## 4. Safer formatting default

Experimental character-style run translation is now off by default.

Why: InDesign often splits one sentence across multiple style ranges. Translating every style range independently can create duplicated fragments such as half-English/half-target-language text. Leaving the option off gives cleaner paragraph-level translation while preserving the page objects, frames, paragraph styling, and layout structure more reliably.

## 5. Selection mode disabled in safe copy mode

Selection mode is disabled for now because the selection belongs to the currently open original document, while the safer workflow opens a copied file before editing. Whole-document translation is the supported production path in this build.
