// Node harness: simulates the IDML extract → translate → apply → verify cycle
// against a synthetic story covering styled runs, entities, paragraph breaks,
// table cells, and processing instructions. Run: node tests/idml-roundtrip.test.js
global.window = global;
global.self = global;
window.fflate = require("../lib/fflate.js");
require("../src/protectors.js");
require("../src/idml-engine.js");

const f = window.fflate;
const P = window.AIT_Protectors;
const E = window.AIT_IdmlEngine;

function assert(cond, msg) {
  if (!cond) { console.error("FAIL:", msg); process.exit(1); }
}

const storyXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<idPkg:Story xmlns:idPkg="http://ns.adobe.com/AdobeInDesign/idml/1.0/packaging">
<Story Self="u1">
<ParagraphStyleRange AppliedParagraphStyle="ParagraphStyle/Title">
<CharacterStyleRange AppliedCharacterStyle="CharacterStyle/Bold"><Content>Safety</Content></CharacterStyleRange>
<CharacterStyleRange AppliedCharacterStyle="CharacterStyle/$ID/[No character style]"><Content> bingo: travel &amp; fun</Content><Br /><Content>Second paragraph here.</Content></CharacterStyleRange>
</ParagraphStyleRange>
<ParagraphStyleRange AppliedParagraphStyle="ParagraphStyle/Body">
<CharacterStyleRange><Content>Page </Content></CharacterStyleRange>
<CharacterStyleRange><Content><?ACE 18?></Content></CharacterStyleRange>
</ParagraphStyleRange>
<ParagraphStyleRange AppliedParagraphStyle="ParagraphStyle/Body">
<CharacterStyleRange><Content>One</Content></CharacterStyleRange>
<CharacterStyleRange><Content> two</Content></CharacterStyleRange>
<CharacterStyleRange><Content> three.</Content></CharacterStyleRange>
</ParagraphStyleRange>
<Table Self="t1"><Cell Name="0:0"><ParagraphStyleRange><CharacterStyleRange><Content>Cell one text</Content></CharacterStyleRange></ParagraphStyleRange></Cell></Table>
</Story>
</idPkg:Story>`;

const files = {
  mimetype: f.strToU8("application/vnd.adobe.indesign-idml-package"),
  "Stories/Story_u1.xml": f.strToU8(storyXml),
  "designmap.xml": f.strToU8("<designmap/>")
};

// ---- Extraction ----
const extraction = E.extractUnits(files, { protectPlaceholders: true });
const ids = extraction.units.map(u => u.id);
console.log("Extracted units:");
extraction.units.forEach(u => console.log(` ${u.id} [${u.mode}] "${u.originalText}"`));

assert(extraction.units.length === 5, `expected 5 units, got ${extraction.units.length}`);
assert(extraction.units[0].mode === "tagged-runs", "para 0 should be tagged-runs (2 styled runs)");
assert(extraction.units[0].originalText === "Safety bingo: travel & fun", "para 0 text incl. decoded entity");
assert(extraction.units[1].mode === "plain", "para 1 should be plain");
assert(extraction.units[1].originalText === "Second paragraph here.", "para 1 text");
assert(extraction.units[2].mode === "tagged-runs", "page-number para should be tagged-runs");
assert(/AIT_PI_0/.test(extraction.units[2].originalText), "PI must be tokenized");
assert(extraction.units[4].originalText === "Cell one text", "table cell text extracted");

// ---- Mock translation (tagged units echo run tags; one unit returns broken tags to test fallback) ----
const map = {};
extraction.units.forEach((u, n) => {
  if (u.id === extraction.units[3].id) {
    map[u.id] = "Mushed translation without tags"; // forces whole-paragraph fallback
  } else if (u.mode === "tagged-runs") {
    map[u.id] = u.runs.map((r, i) => `<r id="${i}">${P.escapeXmlText(i === 0 ? "[XX] " + r.protectedText : r.protectedText)}</r>`).join("");
  } else {
    map[u.id] = "[XX] " + u.preparedText;
  }
});

// ---- Apply + verify (throws on any integrity failure) ----
const built = E.applyTranslations(files, extraction, map);
assert(built.checked === 5, `verify should check 5 blocks, checked ${built.checked}`);
assert(built.fallbackUnits.length === 1, "exactly one fallback unit expected");

const outXml = f.strFromU8(built.files["Stories/Story_u1.xml"]);
assert(outXml.indexOf("<Content>[XX] Safety</Content>") !== -1, "run 0 translated in place");
assert(outXml.indexOf("&amp; fun") !== -1, "ampersand re-escaped in output XML");
assert(outXml.indexOf("<?ACE 18?>") !== -1, "processing instruction preserved");
assert(outXml.indexOf("<Content>[XX] Second paragraph here.</Content>") !== -1, "plain paragraph translated");
assert(outXml.indexOf("<Content>Mushed translation without tags</Content>") !== -1, "fallback text in first run");
assert(outXml.indexOf("<Content>[XX] Cell one text</Content>") !== -1, "table cell translated");
assert(outXml.indexOf("AIT_PI_") === -1, "no internal tokens leaked into the document");

// ---- Zip round-trip (same shape writeIdml uses) ----
const ordered = { mimetype: [built.files.mimetype, { level: 0 }] };
for (const k of Object.keys(built.files)) if (k !== "mimetype") ordered[k] = built.files[k];
const zipped = f.zipSync(ordered);
const reread = f.unzipSync(zipped);
assert(f.strFromU8(reread["Stories/Story_u1.xml"]) === outXml, "zip round-trip preserves story XML");
assert(Object.keys(reread)[0] === "mimetype", "mimetype entry first in package");

console.log("\nAll IDML round-trip assertions passed.");
