# QA pass/fail sheet — run before every Adobe submission

Tick each row. **Any FAIL = do not submit** until fixed. Test on a **duplicate**
of a real `.indd`, never an original. Budget ~30 min.

Build under test: `.ccx` packaged from `node scripts/package.js` (not the dev
folder) — install the packaged build so you test what reviewers/buyers get.

---

## A. Automated gates (run from the plugin folder — all must say PASS)

| # | Command | Expected | Pass? |
|---|---|---|---|
| A1 | `node scripts/validate.js` | `Validation passed.` | ☐ |
| A2 | `node scripts/check-ids.js` | exit 0, `Missing from HTML: (none)` | ☐ |
| A3 | `node tests/idml-roundtrip.test.js` | `All IDML round-trip assertions passed.` | ☐ |
| A4 | `node tests/private-mode.test.js` | `Private-mode gate: 5 passed, 0 failed` | ☐ |

*(All four were GREEN as of 2026-06-12.)*

---

## B. Install & licensing

| # | Check | Expected | Pass? |
|---|---|---|---|
| B1 | Fresh install (unload + load the `.ccx`) | Panel opens, all 6 tabs reachable | ☐ |
| B2 | Settings → Plugin License | Shows trial banner / days left | ☐ |
| B3 | Paste a Lemon Squeezy **test** key → Activate | "License active." | ☐ |
| B4 | Paste a bogus key | Clear, non-crashing error | ☐ |
| B5 | Deactivate the test key in LS → Reload | Reverts to trial/expired within 72 h | ☐ |
| B6 | **Private mode ON** (Settings) + provider = OpenAI/Anthropic/Gemini → run Translate | Blocked with a clear "Private mode is on" message; **no output files, no network** | ☐ |
| B7 | Private mode ON + provider = Ollama (model pulled) → run a 1-language batch | Completes locally; nothing leaves the machine | ☐ |
| B8 | Private mode ON → check the brand: teal accent on active tab + progress bar (not Adobe blue) | FormatFlow teal/gradient visible; panel still matches InDesign light/dark | ☐ |

> B3–B5 only meaningful once `CONFIG.enabled = true` and the store is live.
> For Adobe **review** itself, the auto 14-day trial + Mock provider is enough —
> reviewers don't need a key.

---

## C. Core translation (use Mock first, then one real provider)

| # | Check | Expected | Pass? |
|---|---|---|---|
| C1 | Mock provider, small doc, 1 language | `.indd` (+ `.pdf` if enabled) appears in output folder | ☐ |
| C2 | Real provider (Gemini free tier is cheapest), 1 language end-to-end | Log shows "XML rebuilt and verified", no leftover warnings | ☐ |
| C2b | **Each of the other claimed providers once** (OpenAI, Anthropic, DeepL, Ollama) — the listing claims all five, so all five must work | Each completes a 1-language run without provider errors. If Anthropic returns a CORS/4xx error, tell Claude — it's a one-line header fix | ☐ |
| C3 | Multi-language: tick 3+ languages | One file **set per language**, correctly named | ☐ |
| C4 | Open every output file | All open without "damaged/recover" prompts | ☐ |

---

## D. Layout & formatting fidelity (the whole value prop — be strict)

| # | Check | Expected | Pass? |
|---|---|---|---|
| D1 | Paragraph styles | Still applied in output | ☐ |
| D2 | Mixed character styles (bold/italic/superscript/colored runs) | Preserved per-run | ☐ |
| D3 | Tables & merged cells | Translated, structure intact | ☐ |
| D4 | Hyperlinks & visible URL text | URLs unchanged, links intact | ☐ |
| D5 | Product codes / variables / placeholders | Untranslated, exactly preserved | ☐ |
| D6 | Glossary terms (headings, body, callouts, tables) | Enforced everywhere they appear | ☐ |
| D7 | Locked items | Intentionally skipped | ☐ |
| D8 | Master-page text (if the doc uses it) | Handled as expected | ☐ |

---

## E. Scripts & RTL

| # | Check | Expected | Pass? |
|---|---|---|---|
| E1 | Arabic / Hebrew / Persian | Correct right-to-left reading direction | ☐ |
| E2 | CJK (Chinese / Japanese / Korean) | Renders correctly, no tofu boxes | ☐ |
| E3 | Overset text | Reported in the log; auto-fit attempted (tracking→leading→size) | ☐ |

---

## F. The two standalone tools

| # | Check | Expected | Pass? |
|---|---|---|---|
| F1 | Batch PDF tab — "All open documents" | One PDF per open doc | ☐ |
| F2 | Batch PDF tab — "Choose files" | Works on picked files | ☐ |
| F3 | Overset Fixer — Scan on an overset doc | Reports oversets | ☐ |
| F4 | Overset Fixer — Fix | Resolves or reports remainder honestly | ☐ |

---

## G. UI / theme / sizing

| # | Check | Expected | Pass? |
|---|---|---|---|
| G1 | Match-InDesign theme | Follows Interface brightness | ☐ |
| G2 | Force Light / Dark | Applies correctly | ☐ |
| G3 | Panel at 320px width | Nothing clips; all tabs reachable | ☐ |
| G4 | Copy-log button | Opens / copies log output | ☐ |

---

**Submit only when every box is ticked.** Screenshot opportunities while you're
here (Adobe needs 3–5): C3 mid-batch log, a D-section before/after spread,
F1 Batch PDF, F3 Overset Fixer, and the Translate tab with 10+ languages ticked.
