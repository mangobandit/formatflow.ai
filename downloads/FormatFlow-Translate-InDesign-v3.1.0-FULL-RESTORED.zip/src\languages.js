(function () {
  const languages = [
    { code: "auto", name: "Auto detect", sourceOnly: true, region: "Source" },

    { code: "en", name: "English", region: "Americas" },
    { code: "en-US", name: "English (US)", region: "Americas" },
    { code: "en-GB", name: "English (UK)", region: "Europe" },

    { code: "af", name: "Afrikaans", region: "Africa" },
    { code: "am", name: "Amharic", region: "Africa" },
    { code: "ar", name: "Arabic", rtl: true, region: "Middle East & Africa" },
    { code: "sw", name: "Swahili", region: "Africa" },
    { code: "xh", name: "Xhosa", region: "Africa" },
    { code: "zu", name: "Zulu", region: "Africa" },

    { code: "bg", name: "Bulgarian", region: "Europe" },
    { code: "hr", name: "Croatian", region: "Europe" },
    { code: "cs", name: "Czech", region: "Europe" },
    { code: "da", name: "Danish", region: "Europe" },
    { code: "nl", name: "Dutch", region: "Europe" },
    { code: "et", name: "Estonian", region: "Europe" },
    { code: "fi", name: "Finnish", region: "Europe" },
    { code: "fr", name: "French", region: "Europe" },
    { code: "de", name: "German", region: "Europe" },
    { code: "el", name: "Greek", region: "Europe" },
    { code: "hu", name: "Hungarian", region: "Europe" },
    { code: "it", name: "Italian", region: "Europe" },
    { code: "lv", name: "Latvian", region: "Europe" },
    { code: "lt", name: "Lithuanian", region: "Europe" },
    { code: "no", name: "Norwegian", region: "Europe" },
    { code: "pl", name: "Polish", region: "Europe" },
    { code: "pt", name: "Portuguese", region: "Europe" },
    { code: "ro", name: "Romanian", region: "Europe" },
    { code: "ru", name: "Russian", region: "Europe" },
    { code: "sk", name: "Slovak", region: "Europe" },
    { code: "sl", name: "Slovenian", region: "Europe" },
    { code: "es", name: "Spanish", region: "Europe" },
    { code: "sv", name: "Swedish", region: "Europe" },
    { code: "tr", name: "Turkish", region: "Europe & Middle East" },
    { code: "uk", name: "Ukrainian", region: "Europe" },

    { code: "he", name: "Hebrew", rtl: true, region: "Middle East" },
    { code: "fa", name: "Persian", rtl: true, region: "Middle East" },

    { code: "bn", name: "Bengali", region: "Asia" },
    { code: "zh", name: "Chinese Simplified", region: "Asia" },
    { code: "zh-TW", name: "Chinese Traditional", region: "Asia" },
    { code: "hi", name: "Hindi", region: "Asia" },
    { code: "id", name: "Indonesian", region: "Asia" },
    { code: "ja", name: "Japanese", region: "Asia" },
    { code: "ko", name: "Korean", region: "Asia" },
    { code: "ms", name: "Malay", region: "Asia" },
    { code: "th", name: "Thai", region: "Asia" },
    { code: "vi", name: "Vietnamese", region: "Asia" },

    { code: "es-419", name: "Spanish (Latin America)", region: "Americas" },
    { code: "pt-BR", name: "Portuguese (Brazil)", region: "Americas" }
  ];

  const presets = {
    core20: ["zh", "nl", "fr", "de", "it", "pt", "ru", "es", "ar", "cs", "el", "he", "hi", "hu", "ms", "pl", "sv", "tr", "vi", "fa"],
    europe: ["en-GB", "bg", "hr", "cs", "da", "nl", "et", "fi", "fr", "de", "el", "hu", "it", "lv", "lt", "no", "pl", "pt", "ro", "ru", "sk", "sl", "es", "sv", "tr", "uk"],
    africa: ["af", "am", "ar", "en", "fr", "pt", "sw", "xh", "zu"],
    asia: ["bn", "zh", "zh-TW", "hi", "id", "ja", "ko", "ms", "th", "vi"],
    middleEast: ["ar", "he", "fa", "tr"],
    americas: ["en-US", "es-419", "pt-BR", "fr"],
    rtl: ["ar", "he", "fa"]
  };

  const regionOrder = [
    "Europe",
    "Africa",
    "Middle East & Africa",
    "Middle East",
    "Europe & Middle East",
    "Asia",
    "Americas"
  ];

  window.AIT_LANGUAGES = languages;
  window.AIT_TARGET_LANGUAGES = languages.filter(l => !l.sourceOnly);
  window.AIT_LANGUAGE_PRESETS = presets;
  window.AIT_LANGUAGE_REGION_ORDER = regionOrder;

  window.AIT_getLanguage = function getLanguage(code) {
    return languages.find(l => l.code === code) || { code, name: code };
  };
})();
