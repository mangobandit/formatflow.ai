# FormatFlow Translate — Ship Plan

**Written 2026-07-27. Supersedes the sequencing in `GO_LIVE_SETUP_GUIDE.md` and
`DAY1_FILL_IN_THE_BLANKS.md`** (those remain valid for the Adobe/Lemon Squeezy screen-by-screen
detail — this document is the ordering and the blockers).

Legend: **[YOU]** = only you can do it (your accounts, your identity, your InDesign).
**[CLAUDE]** = hand it back to me and I'll do it. **[BOTH]** = I prepare, you execute.

---

## Phase 0 — Source of truth — ✅ **DONE 2026-07-27**

The project had diverged into two trees. The readable source was missing the batch-export
feature entirely; the minified tree was the only copy that had it, and that was the tree the
shipped `.ccx` was built from. The shipping feature was effectively unmaintainable.

**What was back-ported into the source tree:**

| Piece | Where it went |
|---|---|
| `src/batch-export.js` (format switch, option panels, PDF preset list) | copied — it was never actually minified |
| `listPdfPresets`, `exportDocumentToImage`, PDF-preset wrapper | appended block in `src/indesign-dom.js` |
| Export dispatch handler (minified as `Le`) | `runBatchPdf` in `src/ui.js`, **rewritten readably** |
| Batch export tab UI | `index.html` |
| `.fmt-options` panel rule | `css/styles.css` |
| **Icon dimensions 23 → 24** | `manifest.json` — the source tree still had this bug |

**Verification — the rebuilt package reproduces the shipped artifact.** Same 18 entries,
**15 byte-identical**. The 3 that differ are each explained:

| Entry | Old | New | Why |
|---|---|---|---|
| `src/batch-engine.js` | 7603 | 7611 | the old `.ccx` was minified twice (source → minified tree → packaged) |
| `src/license.js` | 2561 | 2556 | the matt@bear-cg.com email change, made after that `.ccx` was built |
| `src/ui.js` | 23216 | 23179 | renamed locals in the rewritten export handler |

All gates green: `validate.js`, `check-ids.js`, and **all 5 test files** (IDML round-trip,
Private mode 6/6, and 3 DeepL suites).

**Also done:**
- `git init` + first commit (`40d1a9c`, 54 files) with a `.gitignore` covering build artefacts
  and key material. A secret scan of the staged diff came back clean.
- `check-ids.js` now scans `batch-export.js` too — it previously reported 26 export controls as
  "unused" because it only read `ui.js`, which would have masked a real unused id later.
- The minified tree is renamed to `_ARCHIVED-minified-tree-superseded-2026-07-27/` with a
  `_WHY-THIS-IS-ARCHIVED.txt` inside. **Kept, not deleted** — it stays as the known-good
  fallback until the rebuilt package passes live QA (Phase 6). Delete it after that.

### 0.3 [YOU] Still outstanding — move the repo out of OneDrive
Recommended target: `Documents\formatflow-translate`, alongside `formatflow-studio` and
`formatflow-site`.

⚠️ Moving it **breaks the UXP Developer Tool's registered plugin path** — you'll need to remove
and re-add the plugin in UDT afterwards. Do it with InDesign closed.

> **Unrelated but worth knowing:** the Vault folder itself has a `.git` directory that is
> **completely empty** — no HEAD, no objects, 0 bytes. Git reports "not a git repository".
> So nothing else in the Vault (H2Nomad, MDS, Gaviota, matt-bot-3b1, Pulse…) is under version
> control, whatever the folder looks like. Worth a separate session.

---

## Phase 1 — Decisions to lock (30 min, [YOU])

These four gate everything. Nothing downstream can start until they are answers, not options.

### 1.1 Pricing — **DONE, applied 2026-07-27**
Set to **€12/month · €120/year** (annual = 2 months free). Already normalised across
`docs/site/index.html`, all launch docs, and the new legal pages. Rationale:

| Tier | Who | Price |
|---|---|---|
| Free | DeepTranslate, Smartling, FSN, MasterTranslator | €0 |
| Single-provider wrappers | Touzni Translator PRO, deHive | $7 – $9.95/mo |
| **FormatFlow Translate** | **multi-provider BYOK + local Ollama + Private mode** | **€12/mo** |
| AI-tier incumbent | LangoAi (Kreatifart) | €29.90 |

€29 was parity with an established brand you can't yet match on reviews. €5 sat under the entire
paid field and reads as disposable — and since the constraint here is *number of customers* (each
one costs support time) rather than marginal cost (BYOK ≈ zero), pricing low buys you the
expensive half of the business. €12 undercuts the direct AI competitor by ~60% while staying
clearly above the throwaway tier.

> **Optional launch lever:** offer **€9/mo locked for life to the first 100 subscribers.** A new
> listing with zero reviews has a cold-start problem that a discount solves better than a
> permanently low price does.

**If you disagree, change it now** — the number is baked into the Lemon Squeezy product, the
site, the EULA, and the Adobe listing. Changing it after launch means migrating live subscribers.

### 1.2 Legal entity, address, jurisdiction — **RESOLVED 2026-07-27**

| | |
|---|---|
| Legal entity | **Bear Consulting Global** |
| Address | **13B Camino de Escorpio, 11130 Cádiz, Spain** |
| Jurisdiction / governing law | **Spain** |
| All contact email | **matt@bear-cg.com** |

Applied everywhere: both legal pages, `src/license.js` in both trees, the plugin site, and all
launch docs. `support@formatflow.ai` and `requests@formatflow.ai` no longer appear anywhere in
the project. Being Spain-based also fixed two downstream details — the privacy policy now names
the **AEPD** as lead supervisory authority, and the EULA sets the courts of Cádiz with an explicit
carve-out for Spanish/EU consumer law.

**Two things to check before the Adobe trader form:**
1. **Postcode 11130 is Chiclana de la Frontera**, not Cádiz city — both sit in Cádiz province.
   The address is written exactly as you gave it. Since Adobe publishes trader details publicly
   under DSA rules and Lemon Squeezy uses them for tax, confirm the municipality line matches
   your registration.
2. **Adobe's EU trader form and Lemon Squeezy will both want a tax ID** (NIF/CIF, plus your VAT
   number if registered). Have it ready. Whether Bear Consulting Global is a registered company
   or you trading as an *autónomo* changes which number they ask for — and it changes who the
   EULA's "we" legally refers to.

### 1.3 DeepL — **DECIDED 2026-07-27: advertise it**
Folded into the Adobe listing copy, the plugin site (including a new DeepL card in the BYOK
provider section), `LAUNCH.md`, and `PRODUCT_OVERVIEW.md`. The prepared "DeepL variant lines"
block in `ADOBE_LISTING_COPY.md` is now applied rather than optional, and the tag list includes
DeepL.

⚠️ **This creates a QA obligation.** `QA_PASS_FAIL.md` row C2b now reads *all five* providers,
not four. DeepL is wired and the `billed_characters` bug is fixed, but the honesty gate is
unchanged: advertise only what you have personally run in InDesign.

### 1.4 [YOU] Adobe commerce model
In the Developer Distribution portal you choose between letting **Adobe** handle payment (they
take a revenue share) or listing as free-to-install with **your own** licensing (Lemon Squeezy,
which is what `src/license.js` already implements). Your code is built for the second.
**Verify the current rev-share terms in the portal before deciding** — I have not verified
Adobe's 2026 percentages and won't guess at them. Note that if you self-license you must still
disclose in-app purchases on the listing.

---

## Phase 2 — Legal pages live (1–2 h [YOU] + 15 min [CLAUDE])

Adobe **requires a working privacy-policy URL at submission**. Today `formatflow.ai/privacy.html`
is Studio's policy and mentions the plugin zero times — pointing Adobe at it would be inaccurate.

### 2.1 [DONE] Drafts written
Two new pages, styled to match the live site (light/teal, not the old dark Adobe-blue template):
- `formatflow-site/translate-privacy.html`
- `formatflow-site/translate-eula.html`

They replace the `docs/site/privacy.html` and `docs/site/eula.html` templates, which are now
**superseded** — don't deploy those. What's new vs the old drafts: GDPR legal bases and a
retention table, international transfers, CCPA, children's data, an explicit "everything we hold"
table, DeepL named, Private mode and UXP secure storage described, and a price-change notice
clause in the EULA.

### 2.2 [DONE 2026-07-27] Tokens filled
All three placeholders replaced with the Phase 1.2 values, the yellow "unfilled" highlight
removed, and the template-notice comment swapped for a provenance note. Zero `{{TOKEN}}` strings
remain in either page.

### 2.3 [YOU] Lawyer review — before you take money, not after
These are a careful drafting aid. **I am not a lawyer and this is not legal advice.** You are
selling a subscription worldwide, to EU consumers, with auto-renewal and an AI disclaimer — the
clauses most likely to be wrong for your jurisdiction are §4 (withdrawal), §13 (liability cap),
and §16 (governing law). A one-hour review with a lawyer in your country is proportionate here.
`LEGAL_RISK_CHECKLIST.md` has the fuller risk memo.

### 2.4 [DONE] Contact email
Everything now points at **matt@bear-cg.com**. Confirm it accepts mail from strangers and won't
spam-filter support requests — it is the only contact route in the plugin, the legal pages, and
the Adobe listing.

> Also changed: the **live Studio site** (`index.html`, `privacy.html`) used `hello@formatflow.ai`
> for its early-access CTAs and privacy contact. Those now point at matt@bear-cg.com too, per
> "all emails". Uncommitted — say the word if Studio should keep a separate address.

### 2.5 [CLAUDE] Deploy
Commit both pages to `formatflow-site`, add sitemap entries and `vercel.json` rewrites.
Canonical URLs use the `.html` extension deliberately, so they resolve whether the apex is served
by GitHub Pages or Vercel:
- `https://formatflow.ai/translate-privacy.html`
- `https://formatflow.ai/translate-eula.html`

**Done when:** both return HTTP 200 in a private browser window with no `{{TOKEN}}` visible.

---

## Phase 3 — Lemon Squeezy (1 h, [YOU])

**This is the real deadline, and it is not Adobe's.** `src/license.js` has `enabled: true` and a
14-day trial, but `CONFIG.urls.buy` is still the placeholder
`https://formatflow.lemonsqueezy.com/checkout`. Adobe review will pass fine (reviewers use the
trial) — but **every launch-day user hits a dead paywall on day 15.**

1. Create the store (this fixes your `*.lemonsqueezy.com` subdomain).
2. One product, "FormatFlow Translate", subscription type.
3. Two **variants** — each gets its own `/checkout/buy/` URL:
   - Monthly **€12** → **VALUE 2**
   - Yearly **€120** → **VALUE 3**
4. Enable **License keys** on the product. Keys stay active while the subscription is —
   exactly what `revalidateIfDue` (72 h) expects. No extra config.
5. Configure tax/VAT — they act as merchant of record, which is why the legal pages name them
   as a separate controller.
6. **Run one real test purchase and one refund.** Do not skip this.

**Done when:** you have two distinct `/checkout/buy/` URLs and a test licence key that activates.

---

## Phase 4 — Adobe portal → the plugin ID (1–2 h, [YOU])

1. **Publisher profile** — public name, marketing site `https://formatflow.ai`, description, logo.
2. **EU trader details** — mandatory for EUR pricing and EU visibility. Uses 1.2's address, shown
   publicly.
3. **Create the listing** (leave it draft). The moment it exists, Adobe **auto-assigns a plugin
   ID**. Copy it immediately → **VALUE 1**.

> Your manifest currently carries the self-chosen `ai.formatflow.translate.indesign`. If Adobe's
> assigned ID differs, the manifest must change and **the `.ccx` must be rebuilt**. The existing
> `FormatFlow-Translate-3.0.0.ccx` is therefore **not** your final artefact.

4. Note your InDesign version — must be ≥ 18.5 to match `host.minVersion`.

---

## Phase 5 — Wiring + repackage (15 min, [CLAUDE])

Hand me this block:

```
VALUE 1  Adobe plugin ID:        ____        InDesign version: ____
VALUE 2  LS MONTHLY checkout:    ____
VALUE 3  LS YEARLY checkout:     ____
VALUE 4  Support email:          matt@bear-cg.com    ✓ done
VALUE 5  Live plugin page URL:   ____
VALUE 6  FAQ URL: ____           Docs URL: ____
Entity / address / jurisdiction: Bear Consulting Global, Cádiz, Spain    ✓ done
DeepL: advertise? ____
```

I edit per `CONFIG_PASTE_MAP.md` (manifest `id`; `license.js` `CONFIG.urls.*`; both site checkout
buttons split monthly/yearly), then `node scripts/validate.js && node scripts/package.js` → rename
to `.ccx`.

> One correction to that map: it says flip `enabled: false → true`. **It is already `true`** in
> the shipping build — leave it.

---

## Phase 6 — Live QA in InDesign (~1 h, [YOU])

**Your highest rejection risk.** Multi-format batch export has *only* ever been verified by
headless Node tests against a stubbed InDesign DOM. It has never run in real InDesign. Adobe
reviewers run it live.

Work through `QA_PASS_FAIL.md` against the **packaged `.ccx`**, not the dev folder. Any FAIL =
don't submit. The rows that matter most:

- **A1–A4** automated gates green
- **B6/B7** Private mode blocks cloud providers; Ollama path completes locally
- **C2b** every provider you advertise completes a run — if you advertise DeepL (1.3), add it
  here. If Anthropic throws CORS/4xx, that's a one-line header fix
  (`anthropic-dangerous-direct-browser-access`) — tell me
- **Batch export, live** — PDF, PNG and JPEG on a **multi-page** document. The historic bug was
  "only page 1 exports"; the fix uses `EXPORT_ALL`, verified only in stubs. Confirm page counts.
- **B3–B5** activate the Phase 3 test key, then a bogus key
- Panel at 320px — nothing clips

Test on a **duplicate** of a real `.indd`, never an original.

---

## Phase 7 — Listing assets (2–3 h, [YOU])

**Nothing exists today.** The only images in the entire project are two 24px panel icons. This
cannot be faked or generated — it needs real InDesign runs.

- **Publisher logo** — square, FormatFlow teal
- **Plugin icon** — Adobe's listing icon is larger than the 24/48px manifest icons; check the
  portal's required size
- **3–5 screenshots**, per `LAUNCH.md` §3c:
  1. Translate tab, 10+ languages ticked
  2. Progress log mid-batch, per-language ✓ lines
  3. Before/after spread — English vs French `.indd` side by side
  4. Batch export tab
  5. Overset Fixer tab
- **Optional but high-leverage:** a 60–90 s screen recording. In a listing with 15+ competitors,
  a video of one click producing ten print-ready translated files outsells any copy.

Use your own documents. Do not reuse anything of Touzni's — that guardrail stands.

---

## Phase 8 — Submit (30 min, [YOU])

1. Paste listing copy from `ADOBE_LISTING_COPY.md` (now €12/€120).
2. Privacy URL → `https://formatflow.ai/translate-privacy.html`.
3. EULA → "custom", link `https://formatflow.ai/translate-eula.html`.
4. **Reviewer notes** — paste `LAUNCH.md` §3e verbatim. It pre-answers the two things most likely
   to get you rejected: why the plugin needs `network: all` + `localFileSystem: fullAccess`, and
   the AI-generated-content disclosure. Add the line telling reviewers to select
   **Provider → Mock/offline test** so they can run the full workflow with no key and no cost.
5. Upload the Phase 5 `.ccx`. Submit.

**Honesty gate before you write a word of announcement copy:** 48 languages, never "50+". No
first-to-market claims. Private mode is "nothing leaves the machine" **only with a local Ollama
model** — keep the caveat attached.

---

## Phase 9 — After approval

- Deploy the plugin landing page (`docs/site/index.html`) with live checkout buttons → that URL
  becomes VALUE 5. Hold this until Phase 3 is done so the buttons never 404.
- Announce per `LAUNCH_ANNOUNCEMENTS.md` — InDesign user groups, r/indesign, LinkedIn.
- Ask early happy users for honest reviews. On a crowded marketplace, review count is the
  ranking input you control.
- Respond publicly and factually to every review, including bad ones.
- Watch day 15 — the first real subscription conversions. If Phase 3 has any flaw, that's when it
  shows.

---

## Critical path

```
Phase 0 (source of truth)   ✅ DONE
Phase 1 (decisions)         ✅ DONE except 1.4 (Adobe commerce model)
                             ┌─→ Phase 2 (legal: lawyer + deploy) ─┐
                             ├─→ Phase 3 (Lemon Squeezy)          ├─→ Phase 5 (wire+package)
                             └─→ Phase 4 (Adobe → plugin ID)      ┘        │
                                                                        ↓
                                                     Phase 6 (QA) → 7 (assets) → 8 (submit)
```

Phases 2, 3 and 4 are independent — run them in parallel. Phase 5 needs all three.

**Realistic effort remaining:** ~5–7 h of your time, ~30 min of mine (Phase 5 wiring), plus
Adobe review latency (typically days) and the lawyer review.

**The three things most likely to actually bite you now**, in order:
1. Phase 3 — a live paywall with no working checkout on day 15
2. Phase 6 — batch export failing live in front of a reviewer, having only ever passed against
   stubbed InDesign objects. DeepL now has to pass here too.
3. Phase 7 — no listing assets exist at all, and they need real InDesign runs to produce
