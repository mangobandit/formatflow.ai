# FormatFlow Translate 3.1.0 — restored full build

This release is based on the recovered 3.0.0 source-of-truth build, not the
reduced 1.2.x apply-pipeline snapshot.

## Restored

- Standalone Overset Text Fixer tab with Scan and Fix actions.
- Automatic overset fitting after every translated document is rebuilt.
- Least-invasive fit ladder: tracking, leading, then point-size reduction.
- User limits for tracking, leading, maximum size reduction, and minimum point size.
- Auto, Dark, and Light themes.
- Full tabbed interface: Translate, Settings, Quick Translate, Batch Export,
  Overset Fixer, Preflight, Help, and About.
- IDML-safe rebuild workflow, DeepL Document route, local Ollama privacy mode,
  glossary protection, preflight, PDF/PNG/JPEG export, and secure per-provider keys.

## Updated

- OpenAI picker now offers GPT-5.6 Sol, Terra, and Luna.
- OpenAI calls use the Responses API with explicit `none` reasoning to preserve
  the established translation latency and cost behavior.
- Saved older OpenAI model selections migrate to the matching GPT-5.6 tier.
- One three-state checkbox checks or unchecks all 48 target languages.
- InDesign paragraph references are re-enumerated before every write/read-back
  so neighboring edits cannot clip the starts of translated paragraphs.

## Verification

- IDML round-trip and DeepL route tests.
- GPT-5.6 request-contract tests for all three tiers.
- InDesign drifting-range regression test.
- Overset ladder regression test.
- Restored-feature and UI-ID contract tests.
- Private-mode network gate test.
