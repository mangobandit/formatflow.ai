// Verifies DeepL provider wiring without making a real network request:
// endpoint selection, language code mapping, XML placeholder shielding, and
// order-based response mapping back to unit IDs.
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");
const calls = [];
const confirmations = [];

const sandbox = {
  window: {},
  fetch: async (url, options) => {
    const payload = options.body ? JSON.parse(options.body) : null;
    calls.push({ url, options, payload });
    if (options.method === "GET") {
      return {
        ok: true,
        json: async () => ({ character_count: 100, character_limit: 500000 }),
        text: async () => ""
      };
    }
    return {
      ok: true,
      json: async () => ({
        // DeepL returns billed_characters per translation object, not at the
        // top level — mirror that here so the provider's accounting is tested.
        translations: payload.text.map(text => ({ text: text.replace("Hello", "Bonjour"), billed_characters: 13 }))
      }),
      text: async () => ""
    };
  },
  setTimeout, clearTimeout, Math, JSON, String, Number, Array, Object, Date, Promise, console, RegExp,
  TextEncoder
};

vm.createContext(sandbox);
sandbox.window.AIT_Glossary = { toPromptLines: () => "" };
sandbox.window.AIT_Protectors = {
  stripFences: s => s,
  escapeXmlText: value => String(value == null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;"),
  unescapeXmlText: value => String(value == null ? "" : value)
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&")
};
vm.runInContext(fs.readFileSync(path.join(root, "src/providers.js"), "utf8"), sandbox);

function assert(cond, msg) {
  if (!cond) { console.error("FAIL:", msg); process.exit(1); }
}

(async () => {
  const P = sandbox.window.AIT_Providers;
  const result = await P.translateBatch("deepl", {
    apiKey: "free-key:fx",
    sourceLang: "en-US",
    targetLanguage: { name: "Chinese Traditional", code: "zh-TW" },
    model: "quality_optimized",
    qualityMode: "premium",
    units: [
      { id: "u1", mode: "plain", preparedText: "Hello [[[AIT_PH_0000]]] & safety" }
    ],
    glossary: [],
    requireBilledCharacters: true,
    deepLRequestAccepted: info => confirmations.push(info)
  });

  assert(calls.length === 1, "DeepL should make one request for one unit");
  assert(calls[0].url === "https://api-free.deepl.com/v2/translate", "free :fx keys should use api-free.deepl.com");
  assert(calls[0].options.headers.Authorization === "DeepL-Auth-Key free-key:fx", "DeepL auth header");
  assert(calls[0].payload.source_lang === "EN", "source variants should map to EN");
  assert(calls[0].payload.target_lang === "ZH-HANT", "zh-TW should map to ZH-HANT");
  assert(calls[0].payload.model_type === "quality_optimized", "model picker should map to DeepL model_type");
  assert(calls[0].payload.tag_handling === "xml", "DeepL should use XML tag handling");
  assert(calls[0].payload.text[0].includes('<ph data-id="AIT_PH_0000"/>'), "placeholder token should be shielded as XML");
  assert(result.u1 === "Bonjour [[[AIT_PH_0000]]] & safety", "response should map back to unit ID and restore placeholder token");
  assert(confirmations.length === 1, "DeepL request confirmation should be emitted");
  assert(confirmations[0].textUnits === 1, "confirmation should include text unit count");
  // Regression guard: billed_characters lives on each translation object, so the
  // provider must sum from there (not read a nonexistent top-level field).
  assert(confirmations[0].billedCharacters === 13, "confirmation should sum billed_characters from translation objects");

  const usage = await P.getDeepLUsage("free-key:fx");
  assert(calls[1].url === "https://api-free.deepl.com/v2/usage", "usage should use the DeepL usage endpoint");
  assert(calls[1].options.method === "GET", "usage should use GET");
  assert(calls[1].options.headers.Authorization === "DeepL-Auth-Key free-key:fx", "usage auth header");
  assert(usage.character_count === 100, "usage response should be returned");

  console.log("DeepL provider: all assertions passed.");
})();
