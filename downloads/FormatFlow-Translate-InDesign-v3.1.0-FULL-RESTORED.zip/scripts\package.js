const fs = require('fs');
const path = require('path');
const os = require('os');
const child_process = require('child_process');

const root = path.resolve(__dirname, '..');
const out = path.resolve(root, '..', 'formatflow-translate.zip');

// A UXP plugin package (.ccx) is a zip with manifest.json at the ARCHIVE ROOT.
// Ship only what the plugin loads at runtime — everything else (internal docs,
// the marketing site, tests, build scripts, npm metadata) stays out of the
// uploaded package. Runtime set is derived from index.html's <link>/<script>
// references plus the icons named in manifest.json.
//
// src/*.js is MINIFIED into the package (tamper-friction + smaller download).
// This is deterrence, not security — client-side JS can always be reversed.
// Readable source stays in this repo; real enforcement is server-side key
// revalidation (Lemon Squeezy). esbuild runs via npx at BUILD time only — the
// plugin itself stays zero-dependency.
const ESBUILD = 'esbuild@0.25.0';
const copyItems = ['manifest.json', 'index.html', 'css', 'icons', 'lib'];
const minifyDir = 'src';

for (const item of [...copyItems, minifyDir]) {
  if (!fs.existsSync(path.join(root, item))) {
    console.error(`Missing required plugin file: ${item} — aborting.`);
    process.exit(1);
  }
}

// Stage in the system temp dir (not OneDrive — it can corrupt mid-write).
const staging = fs.mkdtempSync(path.join(os.tmpdir(), 'ffx-pkg-'));

function copyRecursive(srcPath, destPath) {
  const stat = fs.statSync(srcPath);
  if (stat.isDirectory()) {
    fs.mkdirSync(destPath, { recursive: true });
    for (const entry of fs.readdirSync(srcPath)) {
      copyRecursive(path.join(srcPath, entry), path.join(destPath, entry));
    }
  } else {
    fs.copyFileSync(srcPath, destPath);
  }
}

try {
  for (const item of copyItems) {
    copyRecursive(path.join(root, item), path.join(staging, item));
  }

  const srcFiles = fs.readdirSync(path.join(root, minifyDir)).filter(f => f.endsWith('.js'));
  fs.mkdirSync(path.join(staging, minifyDir), { recursive: true });
  let minified = false;
  try {
    // One esbuild call for all files. No --bundle: each file is a standalone
    // IIFE attaching to window; esbuild minifies + strips comments per file.
    const inputs = srcFiles.map(f => `"${path.join(minifyDir, f)}"`).join(' ');
    child_process.execSync(
      `npx --yes ${ESBUILD} ${inputs} --minify --target=es2020 --charset=utf8 --outdir="${path.join(staging, minifyDir)}"`,
      { cwd: root, stdio: ['ignore', 'inherit', 'inherit'] }
    );
    minified = true;
  } catch (err) {
    console.warn('\n⚠ esbuild unavailable (offline?) — packaging UNMINIFIED source instead.');
    for (const f of srcFiles) {
      fs.copyFileSync(path.join(root, minifyDir, f), path.join(staging, minifyDir, f));
    }
  }

  // Sanity gate: every staged JS file must still parse, and every runtime file
  // referenced by index.html must exist in staging.
  for (const f of srcFiles) {
    child_process.execFileSync(process.execPath, ['--check', path.join(staging, minifyDir, f)], { stdio: 'inherit' });
  }
  const html = fs.readFileSync(path.join(staging, 'index.html'), 'utf8');
  for (const m of html.matchAll(/(?:src|href)="([^"]+\.(?:js|css))"/g)) {
    if (!fs.existsSync(path.join(staging, m[1]))) {
      throw new Error(`index.html references ${m[1]} but it is missing from the package.`);
    }
  }

  try { fs.rmSync(out, { force: true }); } catch (_) {}

  if (process.platform === 'win32') {
    child_process.execFileSync('powershell.exe', [
      '-NoProfile',
      '-Command',
      `Compress-Archive -Path '${staging}\\*' -DestinationPath '${out}' -Force`
    ], { stdio: 'inherit' });
  } else {
    child_process.execFileSync('zip', ['-r', out, '.', '-x', '*.DS_Store'], { cwd: staging, stdio: 'inherit' });
  }

  console.log(`\nCreated ${out}`);
  console.log(`  • src/*.js ${minified ? 'minified (comments stripped, names mangled)' : 'UNMINIFIED (esbuild unavailable)'}`);
  console.log('  • manifest.json is at the archive root (required by Adobe).');
  console.log('  • Rename to .ccx, or use UXP Developer Tools → Package for the official build.');
  console.log('  • Before upload: set manifest.json "id" to your Developer Distribution plugin ID.');
} finally {
  try { fs.rmSync(staging, { recursive: true, force: true }); } catch (_) {}
}
