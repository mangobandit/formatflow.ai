// Verifies DeepL Document API V3 routing without real network access:
// export IDML -> multipart upload -> status poll -> result download -> open/save.
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");
const calls = [];
const logs = [];
const sourceBytes = new TextEncoder().encode("fake-idml-package").buffer;
const resultBytes = new Uint8Array([80, 75, 3, 4]).buffer;
let writtenBinary = null;
let openedName = "";

function response(ok, data, binary) {
  return {
    ok,
    status: ok ? 200 : 400,
    text: async () => JSON.stringify(data || {}),
    arrayBuffer: async () => binary || resultBytes
  };
}

const sandbox = {
  window: {},
  console,
  Promise,
  Math,
  Date,
  String,
  Array,
  Object,
  Error,
  Uint8Array,
  ArrayBuffer,
  TextEncoder,
  TextDecoder,
  fetch: async (url, options) => {
    calls.push({ url, options });
    if (/\/v2\/document$/.test(url)) {
      const bodyText = new TextDecoder().decode(new Uint8Array(options.body));
      if (!bodyText.includes('name="target_lang"')) throw new Error("multipart missing target_lang");
      if (!bodyText.includes("ES")) throw new Error("multipart missing ES target");
      if (!bodyText.includes('filename="source.idml"')) throw new Error("multipart missing IDML filename");
      return response(true, { document_id: "doc-123", document_key: "secret-key" });
    }
    if (/\/v2\/document\/doc-123$/.test(url)) {
      return response(true, { status: "done", billed_characters: 42 });
    }
    if (/\/v2\/document\/doc-123\/result$/.test(url)) {
      return response(true, {}, resultBytes);
    }
    throw new Error(`Unexpected URL ${url}`);
  },
  require: name => {
    if (name !== "uxp") throw new Error(`Unexpected require ${name}`);
    return {
      storage: {
        formats: { binary: "binary" },
        localFileSystem: {
          getEntryWithUrl: async () => sourceEntry
        }
      }
    };
  }
};

const sourceEntry = {
  read: async () => sourceBytes,
  delete: async () => {}
};

const outputFolder = {
  nativePath: "C:\\tmp",
  getEntry: async () => sourceEntry,
  createFile: async name => ({
    name,
    write: async bytes => { writtenBinary = bytes; },
    delete: async () => {}
  })
};

vm.createContext(sandbox);
sandbox.window.AIT_InDesignDom = {
  getActiveDocument: () => ({ name: "source.indd" }),
  getDocumentBaseName: () => "source",
  safeFilePart: value => String(value || "Output").replace(/[\\/:*?"<>|]/g, "-"),
  exportDocumentToIdml: async () => "C:\\tmp\\source.idml",
  activateDocument: () => {}
};
sandbox.window.AIT_IdmlEngine = {
  openAsIndd: async entry => {
    openedName = entry.name;
    return { oversetCount: 0, keptDoc: null };
  },
  deleteEntry: async () => {}
};

vm.runInContext(fs.readFileSync(path.join(root, "src/deepl-document-engine.js"), "utf8"), sandbox);

function assert(cond, msg) {
  if (!cond) { console.error("FAIL:", msg); process.exit(1); }
}

(async () => {
  await sandbox.window.AIT_DeepLDocumentEngine.runBatch({
    apiKey: "fake-key:fx",
    outputFolder,
    targetLanguages: [{ name: "Spanish", code: "es" }],
    sourceLang: "en",
    keepOpen: false
  }, {
    log: message => logs.push(message),
    progress: () => {},
    cancelled: () => false
  });

  assert(calls.length === 3, "should upload, poll, and download");
  assert(calls[0].url === "https://api-free.deepl.com/v2/document", "free key should use api-free document upload");
  assert(calls[1].url === "https://api-free.deepl.com/v2/document/doc-123", "should poll document status");
  assert(calls[2].url === "https://api-free.deepl.com/v2/document/doc-123/result", "should download document result");
  assert(writtenBinary, "translated IDML bytes should be written");
  assert(/Spanish/.test(openedName), "translated IDML should be opened for target language");
  assert(logs.some(line => /Document API accepted upload/.test(line)), "should log upload acceptance");

  console.log("DeepL document engine: all assertions passed.");
})();
