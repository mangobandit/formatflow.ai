// Verifies that the full batch engine delegates DeepL document runs to the V3
// DeepL Document API engine instead of the old text-unit translation path.
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");
let documentEngineCalled = false;
let textProviderCalled = false;

const sandbox = {
  window: {},
  console,
  Promise,
  Math,
  Date,
  String,
  Array,
  Object,
  Error
};

vm.createContext(sandbox);
sandbox.window.AIT_DeepLDocumentEngine = {
  runBatch: async (settings, hooks) => {
    documentEngineCalled = true;
    hooks.log("V3 document engine called.");
    return { ok: true, provider: settings.provider };
  }
};
sandbox.window.AIT_Providers = {
  estimateCost: units => ({ chars: units.length, approxTokensPerLanguage: units.length, totalApproxTokens: units.length }),
  translateBatch: async () => {
    textProviderCalled = true;
    return {};
  }
};
sandbox.window.AIT_InDesignDom = {
  extractUnits: () => ({ units: [], skipped: [] })
};

vm.runInContext(fs.readFileSync(path.join(root, "src/batch-engine.js"), "utf8"), sandbox);

function assert(cond, msg) {
  if (!cond) { console.error("FAIL:", msg); process.exit(1); }
}

(async () => {
  const logs = [];
  const result = await sandbox.window.AIT_BatchEngine.runBatch({
    provider: "deepl",
    targetLanguages: [{ name: "Spanish", code: "es" }],
    outputFolder: {},
    scope: "document"
  }, {
    log: message => logs.push(message),
    progress: () => {},
    cancelled: () => false
  });

  assert(result && result.ok, "V3 document engine result should be returned");
  assert(documentEngineCalled, "DeepL should route to V3 document engine");
  assert(!textProviderCalled, "DeepL document run must not call text-unit provider");
  assert(logs.includes("V3 document engine called."), "V3 engine log should pass through");

  console.log("DeepL batch route: all assertions passed.");
})();
