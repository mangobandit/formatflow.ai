// Debug helper: cross-checks element IDs referenced by the panel scripts against index.html.
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
// Every script that reaches into the DOM by id. batch-export.js owns the
// export-format controls, so scanning ui.js alone reports them all as unused.
const SCRIPTS = ['src/ui.js', 'src/batch-export.js'];
const ui = SCRIPTS.map(f => fs.readFileSync(path.join(root, f), 'utf8')).join('\n');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');

// Scripts reach elements via $("id") AND via helpers that take the id as their
// first string argument — count both, or wired controls show up as "unused".
const used = new Set([
  ...[...ui.matchAll(/\$\("([A-Za-z0-9_]+)"\)/g)].map(m => m[1]),
  ...[...ui.matchAll(/\b(?:pickerValue|populatePicker|setPicker|miniLog|clearMini|val|chk|num|wireScope)\(\s*"([A-Za-z0-9_]+)"/g)].map(m => m[1]),
]);
const defined = new Set([...html.matchAll(/id="([A-Za-z0-9_]+)"/g)].map(m => m[1]));

const missing = [...used].filter(id => !defined.has(id));
const unused = [...defined].filter(id => !used.has(id) && !/^(tab|Canvas)/.test(id));

console.log('IDs used in ui.js:', used.size);
console.log('Missing from HTML:', missing.length ? missing.join(', ') : '(none)');
console.log('Defined but never used:', unused.length ? unused.join(', ') : '(none)');
if (missing.length) process.exit(1);
