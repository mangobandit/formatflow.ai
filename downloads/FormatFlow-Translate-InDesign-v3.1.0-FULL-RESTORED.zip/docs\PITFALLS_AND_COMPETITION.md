# Pitfalls & competition audit — 2026-06-12

Red-team pass before submission: code audit, licensing weaknesses, Adobe
rejection risks, and the live competitive field. Everything below was verified
against source or live web search, not assumed.

---

## A. Code audit — verified clean (with one fix)

| Area | Verdict |
|---|---|
| `check-ids.js` reported 8 "unused" element IDs (model, industry, qualityMode…) | **False alarm** — all are wired via helper calls (`pickerValue`, `miniLog`, `populatePicker`) the checker's regex missed. **Fixed the checker**; now 72 IDs tracked, 0 missing, 0 unused. |
| License revalidation actually runs? | ✅ `revalidateIfDue()` fires on every panel init (`ui.js:24`); Translate is gated at `ui.js:732`; revoked keys deactivate within 72 h. |
| "Verifies every block / repair retries" marketing claim | ✅ Real: integrity gate → one repair pass → **abort without writing anything** if still incomplete → second gate at XML rebuild (`batch-engine.js`). |
| API key storage | ✅ UXP `secureStorage` when available, localStorage fallback; `writeSettings` strips `apiKey` from the settings blob. |
| Legal pages (`privacy.html`, `eula.html`) | ✅ No placeholder text, privacy wording already honest. |
| Packaging | ✅ Fixed earlier today — manifest at archive root, runtime files only. |

## B. Known weaknesses — accepted deliberately (know them, don't fix them)

1. **Client-side licensing is bypassable — now with friction.** Since
   2026-06-12 the packager ships `src/*.js` **minified** (esbuild at build
   time only: comments stripped, names mangled, license hints like "flip to
   true" gone; readable source stays in this repo). That deters the casual
   open-file-flip-flag tamper, which is the realistic threat. A determined
   cracker still wins — that's true of every JS plugin on the Exchange, and
   they were never going to pay. Real enforcement stays server-side (Lemon
   Squeezy revalidation kills revoked keys ≤72 h); legal backstop is in the
   EULA ("no reverse engineering", "no circumvention of license validation").
   A deeper DRM arms race costs more than the piracy — deliberately declined,
   as is proxying AI traffic through our own server for enforcement (it would
   destroy the "no middleman server" privacy moat that is the product).
2. **Offline-forever keeps a key alive.** If a machine can never reach
   `api.lemonsqueezy.com`, an activated key never revalidates and never
   deactivates. Deliberate "never block the user offline" tradeoff — correct
   for a tool used at print deadlines.
3. **Static `instanceName`** — all activations show the same instance label in
   the Lemon Squeezy dashboard. Cosmetic only.
4. **Default models are premium-priced** (`gpt-4.1`, `claude-opus-4-8`). The
   "costs cents per document" claim holds for typical brochures but a 200-page
   catalog × 20 languages on Opus could run real money. The cost estimator
   shows token counts before a run. *Optional product decision: default
   Anthropic to Sonnet for cost — not changed, Matt's call.*
5. **Repo lives in OneDrive** — same mid-write corruption class as matt-bot.
   The packaged `.ccx` was verified post-build. Recommend `git init` after
   launch week.

## C. Adobe review — rejection risks & mitigations

| Risk | Mitigation (status) |
|---|---|
| Broad permissions: `network: all`, `localFileSystem: fullAccess`, `launchProcess`, `clipboard` | Reviewer pushback is common. Justifications already drafted in LAUNCH.md §3e — paste them into the review-notes box verbatim. |
| AI-generated-content disclosure | Already in §3e review notes. |
| Trademark: plugin name must not lead with "InDesign"/"Adobe" | ✅ "FormatFlow Translate" is clean; "for Adobe InDesign" used descriptively; footer carries Adobe TM attribution. |
| `manifest.json` id ≠ portal-assigned ID | Blocking — wired into CONFIG_PASTE_MAP step 1. |
| Privacy policy URL must be live at submission | Cloudflare Pages deploy is Day-1 step 3. |
| Reviewer can't test (no API key) | Mock/offline provider + auto trial — already explained in §3e notes. |
| A claimed provider fails in the panel (e.g. Anthropic CORS behavior in UXP) | **QA C2b added today: test all four providers with real keys before submitting.** If Anthropic 4xxs, it's a one-line header fix (`anthropic-dangerous-direct-browser-access`). |

## D. Competitive field (live-searched 2026-06-12) & attack vectors

### The players

| Competitor | What they are | Their angle | Our counter |
|---|---|---|---|
| **Smartcat** | Enterprise TMS; just launched an "InDesign Translation Agent" (full packages incl. text in linked images) | Enterprise depth, agents marketing, TM | We're *in the panel*, flat €12 BYOK (no per-word credits), files never uploaded to a third-party platform, local Ollama option |
| **Redokun** | SMB web platform: upload InDesign file → web editor → TM + team workflow | Established brand, translation memory, collaboration | Price (their annual tiers imply €100+/mo), native in-app, no file upload, no per-seat growth tax |
| **Id-Extras "Translate"** | The closest rival: in-InDesign plugin powered by DeepL | DeepL quality brand; existing InDesign-scripts audience | Multi-provider BYOK (incl. free Gemini tier + local Ollama), 48-language single batch → per-language .indd + PDF, glossary enforcement, overset auto-fit, verification gates |
| **Vaga.ai** | Web IDML translator/editor | Simple upload-and-go | Native, no upload, BYOK pricing |
| **DIY / free** | GitHub scripts, manual IDML through DeepL/ChatGPT | Free | Verification + repair, RTL/CJK, glossary, support, no XML surgery by hand |

### Marketplace reality (CORRECTED 2026-06-12 — earlier "empty marketplace" claim was WRONG)

The web search that suggested an empty Exchange was wrong; Matt's in-app
screenshot shows a **crowded, mature category** — 15+ translation plugins:

- **Free:** DeepTranslate (Arts Unique), Translate.photo (Vitra.ai),
  Smartling, FSN Translator ("Translate any .idml document!"), MasterTranslator
  (Jianan, "Multilingual & RTL Toolkit").
- **Paid, DeepL-based:** Oussama Touzni's "Translator PRO" line (batch $7/mo,
  Google $8/mo, DeepL $60), LangoAi Deepl (Kreatifart, €29.90), Reffer ($60).
- **Paid, AI:** LangoAi AI (Kreatifart, €29.90), deHive "Translation Agent"
  ($9.95/mo, "agentic"), and **"AI Translator PRO" (Oussama Touzni), "AI
  translation > 100 languages", 4★ — currently INSTALLED on Matt's machine.**

Implications, honestly:
- **No first-mover position. Red ocean, not green.** Pricing repositioned
  2026-07-27 from €29 → **€12/mo · €120/yr**. That places us deliberately
  *between* the two clusters in this market: above the single-provider
  DeepL/Google wrappers ($7–9.95/mo — Touzni, deHive) and roughly 60% below the
  AI-tier incumbent (LangoAi, €29.90). €29 was parity with an established brand
  we cannot yet match on reviews or track record; €5 (the interim June figure)
  sat below the entire paid field and read as disposable. The gap we price into
  is justified by multi-provider BYOK, local Ollama, Private mode, and the
  verification/repair gates — not by language count.
  Re-verify competitor prices before quoting any of this publicly.
- **"48 languages" looks weak** beside "100+ languages" rivals. Our LLM
  providers support far more than 48 — the list is self-imposed. Either expand
  it (honestly) or stop leading with a language count and lead with the real
  moats.
- **Surviving differentiators:** multi-provider BYOK (most rivals are
  DeepL-only), **local Ollama** (privacy + zero marginal cost — genuinely rare
  here), verification + repair gates, layout-safety framing. These must be the
  headline now, not the language number.
- **Architecture fact-check (verified 2026-06-12):** Touzni's "Translator PRO"
  is **also BYOK** — it sends text to **DeepL** under the user's own DeepL key
  ([IT-TUN setup guide](https://it-tun.com/translate-indesign-plugin/)). So the
  honest framing is NOT "we're local, they're on a server" — in cloud mode both
  are BYOK-to-a-third-party. Our genuine, defensible edge is the **on-device
  Ollama option** (DeepL can't run locally) and now **Private mode** (below).
- **NEW — Private mode (shipped 2026-06-12):** a Settings toggle that hard-blocks
  every cloud provider at the single function all translation funnels through
  (`providers.js → translateBatch`); enforced in code, unit-tested
  (`tests/private-mode.test.js`, 5/5). Marketable as: *"Turn on Private mode and
  your text is guaranteed never to leave this machine — for confidential or
  regulated work."* This is a real, testable claim a DeepL-only rival cannot
  make. Honesty caveat: it requires a local Ollama model; without Ollama the
  user has no provider, which the gate states plainly.
- ⚠️ **Name/IP flag — see §F below.** Our internal code is `AIT_*` / `aitpro_*`
  ("AI Translator PRO"); a same-named competitor is installed on the build
  machine. Provenance must be confirmed before spending on accounts/submission.

### How they attack us, and the counters

1. **Quality FUD** ("AI mistranslates, you'll ship a typo to print") — our
   positioning already concedes translation quality belongs to the model and
   claims only layout-safety + verification. Keep that discipline in every
   reply; it converts the attack into our differentiator.
2. **Price undercut** — we're near the floor already (BYOK = no margin on AI
   usage). Nobody with per-word credit economics can follow us down.
3. **Feature-match** (Smartcat/Redokun add BYOK or a panel) — their business
   models resist BYOK (they sell words). Our durable moat: native panel +
   local Ollama + price. Ship the backlog TM feature before they ship a panel.
4. **Review-bombing / astroturf on the listing** — respond publicly and
   factually to every review; ask early happy users for honest reviews
   (the announcement posts already do this politely).
5. **SEO squatting** ("FormatFlow alternative" pages) — later, own the
   comparison pages ourselves (vs Redokun / vs Id-Extras / vs Smartcat), with
   honest tables. Honesty is the brand; a fair comparison page converts.
6. **Adobe policy shift on AI plugins** — disclosure is already in the review
   notes; BYOK keeps us out of the data-handling blast radius.

### One marketing caution

Do **not** quote competitor prices in public copy without re-checking their
pricing page that week (Redokun's exact tiers weren't fully captured in
search). "Flat €12/mo with your own AI key" is strong enough without naming
their numbers.

---

## F. Name & IP provenance — ✅ RESOLVED 2026-06-12

**Matt confirmed: original code.** He studied Touzni's plugin to understand the
*approach*, then wrote his own implementation (notably, doing the work via the
user's own provider rather than copying the code). Copyright protects specific
expression (code, UI text, screenshots, branding), **not** ideas or
functionality — independent reimplementation of "an InDesign batch translator"
is legitimate. Cleared to launch, with two standing guardrails:
- Keep the **FormatFlow** name (not "AI Translator PRO" — that's Touzni's).
- Do **not** reuse Touzni's listing copy, screenshots, or marketing art.

Original investigation notes retained below for the record.

Surfaced 2026-06-12 from Matt's marketplace screenshot.

**Facts (verified):**
- This project's internal code is named `AIT_*` (AIT_Providers, AIT_Languages,
  AIT_Glossary…) and stores keys under `aitpro_*` — i.e. the project was once
  "**AI Translator PRO**". It was rebranded externally to "FormatFlow Translate"
  (the literal string "AI Translator PRO" no longer appears in source).
- A marketplace plugin **"AI Translator PRO" by Oussama Touzni** ("AI
  translation > 100 languages", 4★) is **installed on the build machine**.
- Touzni also publishes the "Translator PRO" DeepL line (the "original guy"
  Matt referenced).
- No attribution, copyright header, license, or "based on" note found anywhere
  in the repo.

**Why this is blocking:** if any of this code/UI/branding derives from Touzni's
plugin, selling it — under any name — is copyright infringement, will get the
Adobe listing pulled (and the developer account risked), and invites a DMCA or
worse. Adobe's review explicitly checks for IP violations. The "AI Translator
PRO" name itself is generic enough that independent creation is plausible — but
that must be **confirmed by Matt, not assumed.**

**Resolution paths:**
- If **original work** (built fresh, name coincidental): proceed — though
  consider that even the *name* collision is a reason the FormatFlow rebrand was
  smart; keep it.
- If **derived / forked / purchased**: stop the launch until the license/rights
  are documented in writing. Clean-room rewrite or explicit license only.

## E. Net verdict

No blocking defects found. The two real bugs this week (Windows backtest CLI,
packaging structure) are fixed; the checker false-alarm is fixed; licensing,
storage, and verification gates do what the marketing says. Remaining risk
lives in (1) the four-provider QA run on a real machine, and (2) Adobe's
permission review — both covered by existing checklists.
