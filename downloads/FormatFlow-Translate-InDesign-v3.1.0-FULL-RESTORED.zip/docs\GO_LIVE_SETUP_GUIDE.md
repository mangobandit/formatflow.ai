# FormatFlow Translate — Go-Live Setup Guide

The plugin is **finished and passing every launch-gate validator** (`validate.js`,
`check-ids.js`, all 5 test files, incl. Private-mode 6/6 — verified 2026-06-27).
Nothing here is code. This is the ~1–2 hours of account setup that only *you* can do,
because it needs your identity, your Adobe developer account, and your payment account.

Work top to bottom. At the end you'll have the **6 values** that unblock the 15-minute
wiring job (`CONFIG_PASTE_MAP.md`) → repackage → QA → upload.

> Order matters: do **§1 (Adobe)** and **§2 (Lemon Squeezy)** first — they generate
> the values everything else points at. Do them in one sitting if you can.

---

## §1 — Adobe Developer Distribution (gates the upload)

This is where the plugin actually gets listed on the Creative Cloud Plugin Marketplace.

### 1a. Create your Publisher Profile (one-time)
Go to the **Adobe Developer Distribution** portal and create a public Publisher Profile.
You'll be asked for:
- **Public name** — what shows as the plugin's author (e.g. "FormatFlow" or your trading name)
- **Marketing website** — `https://formatflow.ai`
- **Description** — one-liner about you/the brand
- **Publisher logo** — a square logo (you have FormatFlow teal brand assets)

### 1b. ⚠️ EU Trader details (do NOT skip — you price in EUR)
Adobe requires **trader details** (DSA compliance) for your listing to be **visible in the
EU**. Since your pricing is € and Europe is a core market, fill this in. It's displayed
publicly on the listing when viewed from EU countries — use a business address you're
comfortable showing (a registered business / consulting entity address, not your home if
avoidable).

### 1c. Create the listing → grab the plugin ID
- Click **Create a new listing**.
- Adobe **auto-generates a plugin ID**. **Copy and store it immediately** — this is the
  single value that gates the whole upload. → record it as **VALUE 1** below.
- You don't have to finish every field now; the listing can stay in **draft**. But the ID
  is assigned the moment the listing exists.

> The manifest currently carries a self-chosen ID (`ai.formatflow.translate.indesign`).
> If Adobe's assigned ID differs, the manifest ID **must** be changed to match Adobe's, or
> the upload is rejected. That's the §1 → wiring handoff.

### 1d. (Later, after wiring) Package + upload
- Package the wired build to a **`.ccx`** using the **Adobe UXP Developer Tool (UDT) →
  Package**, or run `node scripts/package.js` and rename the zip to `.ccx`.
- Upload the `.ccx` to the listing, finish General / Localizations / Media / Tags / Services,
  then **Submit for review**. (Listing copy is pre-written in `ADOBE_LISTING_COPY.md`.)

---

## §2 — Lemon Squeezy (gates paid enforcement)

The plugin's license check (`src/license.js`) already speaks Lemon Squeezy's License API.
You just need to create the product and get two checkout URLs.

### 2a. Create the store + product
- Create a store at lemonsqueezy.com (this becomes your `*.lemonsqueezy.com` subdomain).
- Create **one product**: "FormatFlow Translate" (subscription type).

### 2b. Create the pricing — must match the site EXACTLY
The site shows **€0 / 14-day trial · €12 / month · €120 / year**. In Lemon Squeezy each
price is a **variant**, and **each variant has its own checkout URL** (they contain
`/checkout/buy/`). Create:
- **Monthly variant** — €12 / month → its checkout URL = **VALUE 2**
- **Yearly variant** — €120 / year → its checkout URL = **VALUE 3**
- The 14-day free trial is configured on the subscription (trial period), not a separate
  paid variant — the plugin already enforces the 14-day local trial via `trialDays: 14`.

> If you'd rather not match exactly, change ONE side so they agree — the honesty gate
> requires the site price and the real checkout price to be identical.

### 2c. Enable License keys
On the product, **enable "License keys."** For a subscription, keys stay active as long as
the subscription is active and expire when it lapses — which is exactly what the plugin's
background re-validation (`revalidateIfDue`, every 72h) expects. No extra config needed.

---

## §3 — Support + live URLs

- **Support email** — confirm `matt@bear-cg.com` exists and routes to you. If it
  doesn't yet, set it up (or give me the real address). → **VALUE 4**
- **Live plugin page** — the page already exists at `docs/site/index.html` but is **not
  deployed**. Once §2 gives us the checkout URLs, I wire them in and we deploy it to
  `formatflow.ai` (e.g. `/translate` or `/indesign`). That deployed URL = **VALUE 5**.
- **FAQ + docs** — `docs/site/index.html#faq` and `docs/site/docs.html` already exist; they
  ship to the same deploy. Their live URLs = **VALUE 6** (FAQ anchor + docs URL).

> ⚠️ Deploy decision: I'd hold the public deploy until VALUES 2–3 exist, so the "Subscribe"
> buttons don't 404 on day one. Alternative: deploy now with buttons set to "Available
> soon." Your call.

---

## When you've got them — paste back this block

```
VALUE 1  Adobe-assigned plugin ID:        ____
         Test InDesign version (≥18.5):   ____

VALUE 2  LS MONTHLY checkout URL:         ____
VALUE 3  LS YEARLY checkout URL:          ____
         LS prices = €0 / €12 / €120?     ____ (yes/no)

VALUE 4  Support email:                   ____
VALUE 5  Live plugin page URL:            ____  (or "deploy it for me")
VALUE 6  FAQ URL: ____      Docs URL: ____
```

Hand that back and I do the wiring (`CONFIG_PASTE_MAP.md`, ~15 min) → repackage → you run
the QA pass (`QA_PASS_FAIL.md` in InDesign ≥18.5) → upload the `.ccx` → submit.

---

## Honesty gate — before you announce anything
- Edge is **on-device Ollama + Private mode**, NOT "first to market" (15+ competitors exist).
- Claim **"48 languages,"** never "50+".
- Private-mode claim is "guaranteed nothing leaves the machine" **only with a local Ollama
  model installed** — keep that caveat.
- **DeepL: RESOLVED 2026-07-27 — we advertise it.** All five providers (OpenAI · Anthropic ·
  Gemini · DeepL · Ollama) are now in the site and listing copy. It must therefore pass
  `QA_PASS_FAIL.md` row C2b in live InDesign before submission.
