# Install and run

## Development install

1. Unzip the plugin folder.
2. Open Adobe InDesign.
3. Open Adobe UXP Developer Tool.
4. Add the plugin using `manifest.json`.
5. Click Load.
6. In InDesign, open the panel from the Plugins menu.

## Recommended live test order

1. Open a copied `.indd` file.
2. Run the plugin with provider `Mock/offline test` on selected text.
3. Confirm output files save correctly.
4. Load a glossary CSV.
5. Switch to your real provider.
6. Run one language.
7. Review overset text, glossary terms, tables, and character styles.
8. Run the full language preset.

## Packaging

The folder can be loaded directly in UXP Developer Tool. For distribution, package it using Adobe's UXP packaging workflow from the UXP Developer Tool.
