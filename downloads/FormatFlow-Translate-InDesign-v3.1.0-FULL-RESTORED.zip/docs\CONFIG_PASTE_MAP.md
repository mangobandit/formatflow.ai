# Config paste-map — go-live wiring

Every value you collect from your accounts, mapped to the **exact file and line**
it goes into. Once you hand me items 1–4 from the priority list, I make these
edits in ~15 min and re-package — but this lets you sanity-check every change.

> Line numbers are accurate as of 2026-06-12. If the files have shifted, search
> for the **old value** shown in each row.

---

## 1. Adobe plugin ID → `manifest.json`

| File | Line | Old value | New value |
|---|---|---|---|
| `manifest.json` | 4 | `"id": "ai.formatflow.translate.indesign"` | `"id": "<ADOBE-ASSIGNED-ID>"` |

> ⚠️ This **must** match the ID Adobe assigns in the Developer Distribution
> portal, or the upload is rejected. It's the single edit that gates submission.

---

## 2. Lemon Squeezy + URLs → `src/license.js` (the `CONFIG` block, lines 13–27)

| Line | Field | Old value | New value |
|---|---|---|---|
| 14 | `enabled` | `false` | `true`  ← turns on trial-gating + paid enforcement |
| 22 | `urls.buy` | `https://formatflow.lemonsqueezy.com/checkout` | your real LS checkout URL |
| 23 | `urls.support` | `mailto:matt@bear-cg.com` | your real support email (if different) |
| 21 | `urls.website` | `https://formatflow.ai` | your live plugin page URL |
| 24 | `urls.faq` | `https://formatflow.ai/#faq` | live FAQ anchor |
| 25 | `urls.docs` | `https://formatflow.ai/docs.html` | live docs URL |

> Note: the comment at the top of the file says "paste into `CONFIG.buyUrl`" —
> the real field is **`CONFIG.urls.buy`** (line 22). I'll fix that stale comment
> when wiring.

---

## 3. Checkout + support links → `docs/site/index.html`

| Line | What | Old value | New value |
|---|---|---|---|
| 194 | Monthly "Subscribe" button | `https://formatflow.lemonsqueezy.com/checkout` | LS **monthly** variant URL |
| 204 | Yearly "Subscribe" button | `https://formatflow.lemonsqueezy.com/checkout` | LS **yearly** variant URL |
| 207 | "Talk to us" (agency) | `mailto:matt@bear-cg.com` | real support email |
| 292 | Footer "Email us" | `mailto:matt@bear-cg.com` | real support email |
| 302 | Footer "Support" | `mailto:matt@bear-cg.com` | real support email |

> Both buy buttons currently point at the **same** placeholder. In Lemon Squeezy,
> monthly and yearly are usually **separate checkout URLs (variants)** — give me
> both and I'll split them so each button buys the right plan.

---

## 4. Verify (no edit, just confirm)

- Pricing cards in `index.html` already show **€0 / 14 days**, **€12 / month**,
  **€120 / year** (lines 175, 185, 198). Make sure your Lemon Squeezy product
  prices **match these exactly**, or change one side so they agree.
- `manifest.json` `host.minVersion` is **18.5.0** — confirm your test InDesign is
  ≥ 18.5.

---

## 5. After wiring — repackage

```
node scripts/package.js      # rebuilds formatflow-translate.zip, manifest at root
```
Then rename to `.ccx` (or use UXP Developer Tools → Package) and that's your
upload artifact. The packager already ships **only runtime files** (manifest,
index.html, css, icons, lib, src) — these docs and the marketing site are
excluded automatically.

Packaging also **minifies `src/*.js`** (via `npx esbuild`, build-time only —
the plugin stays zero-dependency): smaller download + tamper friction; license
wiring comments never ship. Needs internet for the first esbuild fetch; if
offline it falls back to unminified with a loud warning. Every staged file is
re-checked with `node --check` and index.html references are verified before
zipping. **Wire the real values (this map) BEFORE packaging** — the minified
build is what you QA and upload.
