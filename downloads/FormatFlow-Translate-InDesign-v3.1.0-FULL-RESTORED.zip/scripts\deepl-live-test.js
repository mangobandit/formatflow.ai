const key = process.env.DEEPL_API_KEY;

if (!key) {
  console.error("Set DEEPL_API_KEY before running this script.");
  process.exit(2);
}

const baseUrl = key.trim().toLowerCase().endsWith(":fx")
  ? "https://api-free.deepl.com"
  : "https://api.deepl.com";

async function request(path, options) {
  const res = await fetch(`${baseUrl}${path}`, options);
  const text = await res.text();
  let data = {};
  try { data = text ? JSON.parse(text) : {}; } catch (_) { data = { raw: text }; }
  if (!res.ok) {
    throw new Error(`${path} failed (${res.status}): ${text.slice(0, 1000)}`);
  }
  return data;
}

async function usage(label) {
  const data = await request("/v2/usage", {
    method: "GET",
    headers: { "Authorization": `DeepL-Auth-Key ${key}` }
  });
  console.log(`${label}: ${data.character_count} / ${data.character_limit}`);
  return data.character_count;
}

(async () => {
  const before = await usage("before");
  const body = {
    text: [
      "FormatFlow live DeepL verification sentence.",
      "This second sentence proves multiple document units are sent in one request."
    ],
    source_lang: "EN",
    target_lang: "ES",
    model_type: "prefer_quality_optimized",
    show_billed_characters: true
  };
  const started = Date.now();
  const translated = await request("/v2/translate", {
    method: "POST",
    headers: {
      "Authorization": `DeepL-Auth-Key ${key}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
  });
  const elapsed = Date.now() - started;
  // /v2/translate reports billed_characters on each translation object, not at
  // the top level — sum across the array.
  const billed = (translated.translations || []).reduce(
    (sum, t) => sum + (t && typeof t.billed_characters === "number" ? t.billed_characters : 0),
    0
  );
  console.log(`translate elapsed_ms: ${elapsed}`);
  console.log(`billed_characters: ${billed}`);
  console.log(`translations: ${translated.translations.map(t => t.text).join(" | ")}`);
  const after = await usage("after");
  console.log(`usage_delta: ${after - before}`);
  if (!billed || billed <= 0) {
    throw new Error("DeepL response did not report positive billed characters.");
  }
  if (after <= before) {
    throw new Error("DeepL usage did not increase after live translation.");
  }
})().catch(err => {
  console.error(err.message || err);
  process.exit(1);
});
