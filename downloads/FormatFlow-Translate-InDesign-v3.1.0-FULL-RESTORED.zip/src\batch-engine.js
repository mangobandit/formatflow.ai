(function () {
  const DEFAULT_CHUNK_CHARS = 3200;
  const CHUNK_CONCURRENCY = 3; // parallel in-flight translation requests per language

  // Bigger chunks = far fewer round trips. Sized to each provider's reliable
  // output window; local models get small chunks (limited context).
  function chunkSizeFor(settings) {
    if (settings && settings.chunkChars) return settings.chunkChars;
    const provider = settings && settings.provider;
    if (provider === "deepl") return 60000;
    if (provider === "gemini") return 12000;
    if (provider === "openai" || provider === "anthropic") return 9000;
    if (provider === "ollama") return 2500;
    return DEFAULT_CHUNK_CHARS;
  }

  // Simple async pool: runs worker(item, index) over items with at most `limit`
  // requests in flight. Document writes never happen here — network only.
  async function runWithConcurrency(items, limit, worker) {
    let next = 0;
    async function lane() {
      while (next < items.length) {
        const idx = next++;
        await worker(items[idx], idx);
      }
    }
    const lanes = [];
    for (let i = 0; i < Math.min(limit, items.length); i++) lanes.push(lane());
    await Promise.all(lanes);
  }

  function makeChunks(units, maxChars) {
    const chunks = [];
    let current = [];
    let chars = 0;
    for (const unit of units) {
      const len = String(unit.preparedText || "").length;
      if (current.length && chars + len > maxChars) {
        chunks.push(current);
        current = [];
        chars = 0;
      }
      current.push(unit);
      chars += len;
    }
    if (current.length) chunks.push(current);
    return chunks;
  }

  // Document-level integrity gate, run on the complete translation map before
  // anything is built. `repairable` units get re-sent once; if any remain
  // incomplete the language is aborted (nothing is written).
  function validateTranslationMap(units, map, allowEcho) {
    const repairable = [];
    const warnings = [];
    for (const unit of units) {
      const t = map[unit.id];
      const source = String(unit.textForTranslation || "");
      if (typeof t !== "string" || (!t.trim() && source.trim())) {
        repairable.push(unit);
        continue;
      }
      // Untranslated echo: source text returned verbatim. Repair once; if it
      // persists, surface as a warning (can be legitimate for names/codes).
      if (source.trim() === t.trim() && source.trim().split(/\s+/).length >= 4) {
        if (allowEcho) { warnings.push(`${unit.id}: translation identical to source text — may be untranslated.`); }
        else { repairable.push(unit); continue; }
      }
      const sFirst = source.replace(/^\s+/, "").charAt(0);
      const tFirst = t.replace(/^\s+/, "").charAt(0);
      // Cased scripts only by construction: uppercase source start + lowercase
      // translation start is the signature of a clipped first word.
      if (sFirst && tFirst && sFirst.toLowerCase() !== sFirst && tFirst.toUpperCase() !== tFirst) {
        warnings.push(`${unit.id}: translation starts lowercase while source starts uppercase — possible clipped first word.`);
      }
      if (source.length > 60 && t.trim().length < source.length * 0.25) {
        warnings.push(`${unit.id}: translation suspiciously short compared to source.`);
      }
    }
    return { repairable, warnings };
  }

  function validateAfterTranslation(chunk, map) {
    const warnings = [];
    for (const unit of chunk) {
      const translated = map[unit.id] || "";
      if (unit.mode === "tagged-runs") {
        const parsed = window.AIT_Protectors.parseTaggedRuns(translated);
        if (parsed.length !== unit.runs.length) {
          warnings.push(`${unit.id}: style-run tag count changed (${parsed.length}/${unit.runs.length}); whole-paragraph fallback will be used.`);
        }
        parsed.forEach(item => {
          const run = unit.runs[item.index];
          if (!run) return;
          const check = window.AIT_Protectors.validatePlaceholders(item.text, run.placeholders);
          if (!check.ok) warnings.push(`${unit.id}: placeholder missing in style run ${item.index}.`);
        });
      } else {
        const check = window.AIT_Protectors.validatePlaceholders(translated, unit.placeholders);
        if (!check.ok) warnings.push(`${unit.id}: placeholder missing.`);
      }
    }
    return warnings;
  }

  async function translateAllChunks(settings, chunks, language, langReport, hooks, totalLangs, langIndex) {
    const log = hooks.log || function () {};
    const progress = hooks.progress || function () {};
    const cancelled = hooks.cancelled || function () { return false; };

    const fullMap = {};
    let completedChunks = 0;
    await runWithConcurrency(chunks, CHUNK_CONCURRENCY, async (chunk, idx) => {
      if (cancelled()) throw new Error("Batch cancelled by user.");
      const glossary = window.AIT_Glossary.filterGlossaryForText(settings.glossary, chunk.map(u => u.originalText).join("\n"));
      let chunkMap = null;
      let chunkErr = null;
      for (let attempt = 1; attempt <= 2 && !chunkMap; attempt++) {
        try {
          log(`  Provider route: ${settings.provider}; sending chunk ${idx + 1}/${chunks.length} (${chunk.length} text unit(s)).`);
          chunkMap = await window.AIT_Providers.translateBatch(settings.provider, Object.assign({}, settings, {
            targetLanguage: language,
            sourceLanguageName: settings.sourceLanguageName,
            units: chunk,
            glossary,
            providerLog: message => log(`  ${message}`),
            deepLRequestAccepted: settings.deepLRequestAccepted
          }));
        } catch (err) {
          chunkErr = err;
          if (attempt < 2) log(`  ⚠ Chunk ${idx + 1} attempt ${attempt} failed (${err.message || err}); retrying...`);
        }
      }
      if (!chunkMap) throw chunkErr;
      Object.assign(fullMap, chunkMap);
      const warnings = validateAfterTranslation(chunk, chunkMap);
      langReport.warnings.push.apply(langReport.warnings, warnings);
      warnings.forEach(w => log(`  ⚠ ${w}`));
      completedChunks++;
      const withinLanguage = completedChunks / chunks.length;
      const overall = (langIndex + withinLanguage * 0.85) / totalLangs;
      progress(overall, `${language.name}: chunk ${completedChunks}/${chunks.length}`);
      log(`  ${language.name}: chunk ${completedChunks}/${chunks.length} complete.`);
    });
    return fullMap;
  }

  async function translateOneLanguage(settings, pkg, extraction, chunks, language, langReport, hooks, totalLangs, langIndex, baseName) {
    const log = hooks.log || function () {};
    const progress = hooks.progress || function () {};
    const cancelled = hooks.cancelled || function () { return false; };
    const dom = window.AIT_InDesignDom;
    const idml = window.AIT_IdmlEngine;

    try {
      langReport.status = "translating";
      langReport.startedAt = new Date().toISOString();
      log(`\n▶ ${language.name}: translating ${chunks.length} chunk(s)...`);

      const units = extraction.units;
      const fullMap = await translateAllChunks(settings, chunks, language, langReport, hooks, totalLangs, langIndex);
      if (cancelled()) throw new Error("Batch cancelled by user.");

      // Gate 1: the translation map must be complete and sane before any build.
      langReport.status = "validating";
      let integrity = validateTranslationMap(units, fullMap, false);
      if (integrity.repairable.length) {
        log(`  ${integrity.repairable.length} unit(s) missing, empty, or untranslated — requesting repair translation...`);
        const repairChunks = makeChunks(integrity.repairable, chunkSizeFor(settings));
        for (const repairChunk of repairChunks) {
          const repairGlossary = window.AIT_Glossary.filterGlossaryForText(settings.glossary, repairChunk.map(u => u.originalText).join("\n"));
          const repairMap = await window.AIT_Providers.translateBatch(settings.provider, Object.assign({}, settings, {
            targetLanguage: language,
            sourceLanguageName: settings.sourceLanguageName,
            units: repairChunk,
            glossary: repairGlossary,
            providerLog: message => log(`  ${message}`),
            deepLRequestAccepted: settings.deepLRequestAccepted
          }));
          Object.assign(fullMap, repairMap);
        }
      }
      integrity = validateTranslationMap(units, fullMap, true);
      if (integrity.repairable.length) {
        throw new Error(`Translation incomplete after repair attempt (${integrity.repairable.slice(0, 8).map(u => u.id).join(", ")}${integrity.repairable.length > 8 ? "..." : ""}). Stopped before writing anything.`);
      }
      integrity.warnings.forEach(w => { langReport.warnings.push(w); log(`  ⚠ ${w}`); });

      // Gate 2: rebuild the story XML and verify every block inside the engine.
      langReport.status = "building_idml";
      const built = idml.applyTranslations(pkg.files, extraction, fullMap);
      log(`  ✓ XML rebuilt and verified: ${built.checked} block(s) intact.`);
      if (built.fallbackUnits.length) {
        log(`  ⚠ ${built.fallbackUnits.length} styled paragraph(s) used whole-paragraph styling fallback.`);
      }

      const safeBase = dom.safeFilePart(baseName);
      const safeLang = dom.safeFilePart(language.name);
      const idmlName = `${safeBase} - ${safeLang}.idml`;
      const inddName = `${safeBase} - ${safeLang}.indd`;

      langReport.status = "writing";
      progress((langIndex + 0.9) / totalLangs, `${language.name}: building file...`);
      const idmlEntry = await idml.writeIdml(settings.outputFolder, idmlName, built.files);

      // Gate 3: InDesign itself opens the package (a structurally broken IDML
      // fails loudly here) and saves the final .indd.
      langReport.status = "opening_in_indesign";
      log(`  Opening in InDesign and saving as ${inddName}...`);
      const opened = await idml.openAsIndd(idmlEntry, settings.outputFolder, inddName, settings, language);
      if (opened.autoFit && opened.autoFit.adjustedStories > 0) {
        log(`  Auto-fit: ${opened.autoFit.adjustedStories} overset stor${opened.autoFit.adjustedStories === 1 ? "y" : "ies"} fixed via ${opened.autoFit.stagesUsed.join(" → ")}.`);
      }
      if (opened.oversetCount > 0) log(`  ⚠ ${opened.oversetCount} story/frame(s) still overset after auto-fit — check layout manually.`);
      if (opened.pdfName) log(`  ✓ Exported PDF: ${opened.pdfName}`);
      await idml.deleteEntry(idmlEntry);

      langReport.outputFile = inddName;
      langReport.status = "saved";
      langReport.finishedAt = new Date().toISOString();
      log(`  ✓ Saved translated copy: ${inddName}`);
      return opened.keptDoc || null;
    } catch (err) {
      langReport.status = "failed";
      langReport.finishedAt = new Date().toISOString();
      langReport.errors.push(err.message || String(err));
      log(`  ✕ ${language.name} failed: ${err.message || err}`);
      throw err;
    }
  }

  async function runBatch(settings, hooks) {
    hooks = hooks || {};
    const log = hooks.log || function () {};
    const progress = hooks.progress || function () {};
    const cancelled = hooks.cancelled || function () { return false; };
    const dom = window.AIT_InDesignDom;
    const idml = window.AIT_IdmlEngine;

    if (settings.scope === "selection") {
      throw new Error("Selection mode is not available in the IDML workflow yet. Use Whole document so the original is never edited.");
    }

    const selectedLanguages = settings.targetLanguages || [];
    if (!selectedLanguages.length) throw new Error("Select at least one target language.");
    if (!settings.outputFolder) throw new Error("Choose an output folder first.");
    if (settings.provider === "deepl") {
      if (!window.AIT_DeepLDocumentEngine || typeof window.AIT_DeepLDocumentEngine.runBatch !== "function") {
        throw new Error("DeepL Document API V3 engine is not loaded. Reload the plugin.");
      }
      return await window.AIT_DeepLDocumentEngine.runBatch(settings, hooks);
    }

    const sourceDoc = dom.getActiveDocument();
    const baseName = dom.getDocumentBaseName(sourceDoc);

    log(`Document: ${sourceDoc.name || baseName}`);
    log("Workflow: IDML — the document is exported to XML, the XML is translated, and a fresh copy is built per language. The original is never edited.");
    log(`Languages: ${selectedLanguages.map(l => l.name).join(", ")}`);

    progress(0.02, "Exporting IDML...");
    log("Exporting document to IDML...");
    const pkg = await idml.exportAndLoad(settings.outputFolder, sourceDoc, baseName);

    const extraction = idml.extractUnits(pkg.files, settings);
    if (!extraction.units.length) throw new Error("No translatable text found in the document.");
    const totalChars = extraction.units.reduce((sum, u) => sum + String(u.originalText || "").length, 0);
    const chunks = makeChunks(extraction.units, chunkSizeFor(settings));
    log(`Text blocks: ${extraction.units.length} (stories + tables); characters: ${totalChars.toLocaleString()}; chunks per language: ${chunks.length}`);

    const report = { document: sourceDoc.name || baseName, languages: [] };
    let lastKeptOpen = null;
    for (let langIndex = 0; langIndex < selectedLanguages.length; langIndex++) {
      if (cancelled()) throw new Error("Batch cancelled by user.");
      const language = selectedLanguages[langIndex];
      const langReport = { language: language.name, code: language.code, status: "queued", warnings: [], errors: [] };
      report.languages.push(langReport);
      const keptDoc = await translateOneLanguage(settings, pkg, extraction, chunks, language, langReport, hooks, selectedLanguages.length, langIndex, baseName);
      if (keptDoc) lastKeptOpen = keptDoc;
    }

    if (lastKeptOpen) {
      try {
        dom.activateDocument(lastKeptOpen);
        log("\nShowing the last translated copy.");
      } catch (_) {}
    }

    progress(1, "Complete");
    log("\n✓ Batch complete. Original document was not edited.");
    return report;
  }

  function estimate(settings) {
    const extraction = window.AIT_InDesignDom.extractUnits(settings.scope, settings);
    return Object.assign(window.AIT_Providers.estimateCost(extraction.units, settings.targetLanguages || []), {
      units: extraction.units.length,
      skipped: extraction.skipped.length,
      chunkChars: chunkSizeFor(settings),
      estimatedChunksPerLanguage: makeChunks(extraction.units, chunkSizeFor(settings)).length
    });
  }

  window.AIT_BatchEngine = { runBatch, estimate, makeChunks };
})();
