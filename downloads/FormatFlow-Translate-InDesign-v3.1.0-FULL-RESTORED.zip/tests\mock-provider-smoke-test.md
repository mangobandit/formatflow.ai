# Mock provider smoke test

1. Open an InDesign document.
2. Load the plugin in UXP Developer Tool.
3. Set Provider to `Mock/offline test`.
4. Select `French` and `German`.
5. Select a single text frame.
6. Click Translate batch.
7. Confirm the output folder contains two `.indd` files.
8. Confirm the original document text is restored.
