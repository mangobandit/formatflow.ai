# Day 1 — account signup scripts (copy-follow, no guesswork)

Do all three the same sitting; they're independent. Each ends with the **value
to bring back** so I can wire the plugin and re-package. Times are realistic.

> Order tip: start **Adobe** first (its listing-draft + review is the slowest
> link), then Lemon Squeezy, then Cloudflare while the others process.

---

## 1. Adobe Developer Distribution — get your plugin ID  (~30 min)

Goal: a draft listing that assigns your **plugin ID**.

1. Go to **https://developer.adobe.com/distribute** and sign in with your Adobe
   ID (the same one as your Creative Cloud subscription is fine).
2. If asked, complete the **publisher profile** — display/company name, country,
   and the identity/payout details they request (needed before you can be paid;
   you can start the listing before payout is fully verified).
3. Click **Create new listing / plugin** → choose platform **UXP** and host app
   **InDesign**.
4. Give it a working name ("FormatFlow Translate") and save the draft. The portal
   now shows an assigned **plugin ID** (a reverse-domain string).
5. **Copy that ID.** Don't upload anything yet — I swap the ID into `manifest.json`
   first, then you upload the re-packaged `.ccx`.

→ **Bring me:** the **plugin ID** string.
→ Also note: your chosen **publisher name** + **support email** (I need these for
   `license.js` and the listing).

> If a listing fee or developer-program step appears, screenshot it and tell me —
> Creative Cloud plugin listings are normally free, so I want to see anything
> that isn't before you pay.

---

## 2. Lemon Squeezy — store + subscription + license keys  (~45 min)

Goal: a live (test-mode) checkout and your **checkout URLs**. LS is **merchant of
record**, so they handle global VAT/sales tax for you.

1. Go to **https://lemonsqueezy.com** → sign up → create a **store** (store name,
   country, currency **EUR**).
2. **Settings → check if your store needs activation/approval.** New stores can
   sit in test mode until LS verifies you — that's fine for now; you can wire and
   test everything in **test mode**.
3. **Products → New Product → type: Subscription.** Name it
   "FormatFlow Translate — Pro".
4. Add **two variants** (or two prices):
   - **Monthly — €12 / month**
   - **Yearly — €120 / year**
   (These must match the website cards exactly — they already read €12 / €120.)
5. On the product, **enable License keys** → set **activations per key = 1**
   (or 2–3 if you want laptop + desktop — your call).
6. Open the product's **Share / checkout** links and copy the **checkout URL for
   each variant** (monthly and yearly are usually separate URLs).
7. Leave the store in **test mode** for now — you'll do one real test purchase
   during QA to confirm activation works.

→ **Bring me:** the **monthly checkout URL** and the **yearly checkout URL**.

---

## 3. Cloudflare Pages — deploy the marketing site  (~20 min)

Goal: `docs/site/` live on the web with a working **privacy.html** (Adobe
requires the privacy URL). No build step, no git needed.

1. Go to **https://dash.cloudflare.com** → sign up (free) → in the sidebar open
   **Workers & Pages**.
2. **Create → Pages → Upload assets** (the direct-upload option — *not* the Git
   one).
3. Name the project (e.g. `formatflow-translate`). When it asks for files, drag
   in the **contents of**
   `ai-translator-pro-multilang-v1.1-filefirst\…\docs\site\`
   (the `index.html`, `docs.html`, `privacy.html`, `eula.html` — drag the files,
   so `index.html` sits at the site root).
4. Click **Deploy**. Cloudflare gives you a live URL like
   `https://formatflow-translate.pages.dev`.
5. Open `…/privacy.html` and `…/index.html` in a browser — confirm both load.
6. *(Optional, later)* add a custom subdomain (e.g. `translate.formatflow.ai`)
   under the project's **Custom domains** tab.

→ **Bring me:** the **live site URL** (the `.pages.dev` one, or your custom
   domain if you set it).

---

## When you're back, hand me this block (fill the blanks):

```
PLUGIN_ID        = 
PUBLISHER_NAME   = 
SUPPORT_EMAIL    = 
CHECKOUT_MONTHLY = 
CHECKOUT_YEARLY  = 
SITE_URL         = 
ACTIVATIONS/KEY  = 1   (or 2 / 3)
```

I'll paste these into `manifest.json`, `src/license.js`, and
`docs/site/index.html` per the CONFIG_PASTE_MAP, flip licensing live, and
re-package the `.ccx`. Then you run QA_PASS_FAIL and submit.
