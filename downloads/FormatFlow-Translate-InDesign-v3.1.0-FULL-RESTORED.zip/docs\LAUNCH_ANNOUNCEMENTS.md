# Launch announcement copy

Ready-to-post, honest, no overclaims. **Post only after Adobe approval** and
once the live links work. Every factual claim below is verified against the
shipping code (48 languages, 4 providers, IDML round-trip tested).

> Honesty guardrails baked in:
> - "**48 languages**", never "50+".
> - Translation *quality* is the chosen AI model's job — the plugin's claim is
>   **layout-safe round-tripping**, not "perfect translations". Don't promise
>   quality the model owns.
> - Privacy line: "your text goes **directly to your AI provider**, never our
>   servers" (with Ollama, nothing leaves the machine). Never "your data never
>   leaves your computer" for the cloud providers.
> - Always disclose: subscription covers the plugin; **AI usage is billed by
>   your own provider** (free options exist).

---

## 1. Reddit — r/InDesign (and r/graphic_design)

**Title:** I built an InDesign plugin that batch-translates a whole document into 48 languages without breaking the layout

**Body:**

> I do a lot of multilingual layout work and got tired of the copy-paste-reflow
> cycle, so I built **FormatFlow Translate** — a UXP plugin for InDesign 18.5+.
>
> What it does: you tick the languages you want, hit go, and it exports your doc
> to IDML, translates the text *inside the XML*, verifies every paragraph and
> table cell came back, and builds a fresh print-ready `.indd` per language. Your
> original file is never touched. Frames, styles, tables and masters stay put.
>
> A few things that matter if you've been burned by "AI translate" tools:
> - **Bring your own AI key** — OpenAI, Anthropic, Google Gemini (has a free
>   tier), or fully local **Ollama**. Your text goes straight to the provider you
>   pick; it never passes through my servers. With Ollama it never leaves your
>   machine at all.
> - **Layout-safe by construction** — it edits the story XML, not your frames, so
>   nothing reflows into a mess. Overset text gets an auto-fit pass
>   (tracking → leading → size, least-invasive first), and there's a standalone
>   Overset Fixer too.
> - **Glossary enforcement** from a CSV, brand/URL/code protection, RTL for
>   Arabic/Hebrew/Persian, full CJK.
> - Batch PDF export — a print PDF per language in the same run.
>
> It's honest about what it is: the **translation quality is whatever AI model
> you point it at** — the plugin's job is getting all the text out and back in
> without wrecking your layout, and verifying nothing got dropped.
>
> 14-day free trial, every feature unlocked, no card. After that it's €12/mo or
> €120/yr for the plugin; your AI usage is billed by your own provider (Gemini's
> free tier handles most jobs for nothing).
>
> Link in the comments to avoid the spam filter. Happy to answer anything —
> built this for working designers, so real critique welcome.

*(Post the marketplace + site link as your first comment.)*

---

## 2. LinkedIn

> **Translating an InDesign document used to mean rebuilding the layout. Not anymore.**
>
> I just launched **FormatFlow Translate** on the Adobe Marketplace — a plugin
> that takes one InDesign document and produces a print-ready version in up to
> **48 languages**, in a single batch, with the layout intact.
>
> It exports to IDML, translates the text inside the XML, verifies every block,
> and builds a fresh `.indd` per language. Your original is never edited.
>
> What makes it different:
> → **Bring your own AI** — OpenAI, Anthropic, Gemini, or local Ollama. Your
>   content goes directly to your provider, never through our servers.
> → **Layout-safe** — styles, tables, masters and frames stay exactly where they
>   are; overset text gets an automatic fit pass.
> → **Glossary + brand protection**, RTL and CJK support, batch PDF export.
>
> Subscription covers the plugin; AI usage is on your own key (free options
> exist). 14-day full trial, no card.
>
> If you produce multilingual print or packaging, I'd genuinely value your eyes
> on it. Link in comments. #AdobeInDesign #Localization #DesignTools #Translation

---

## 3. Forums / user groups / Discord (short)

> Just shipped **FormatFlow Translate** for InDesign (18.5+): tick your target
> languages → one batch → a print-ready `.indd` per language, layout intact.
> IDML-safe, verifies every block, BYOK (OpenAI / Anthropic / Gemini / local
> Ollama — your text never hits our servers). 48 languages, glossary
> enforcement, RTL + CJK, batch PDF, overset auto-fit. 14-day free trial, no
> card. Built for production work — feedback welcome: <link>

---

## 4. One-line demo hook (for video/GIF captions, tweets)

> One click. Ten print-ready InDesign files, one per language. Layout untouched.
> Your AI key, your data. → FormatFlow Translate

---

## Posting checklist

- [ ] Adobe listing is **live and approved** (don't pre-announce)
- [ ] Marketplace link + site link both load
- [ ] Lemon Squeezy checkout works (you completed one real purchase)
- [ ] A 30–60s demo GIF/video is ready (the "one click → N files" moment)
- [ ] First comment with links queued (Reddit hides link-posts)
- [ ] You're available for ~2 hours after posting to answer replies
