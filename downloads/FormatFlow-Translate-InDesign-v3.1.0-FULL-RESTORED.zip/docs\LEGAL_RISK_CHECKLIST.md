# FormatFlow Translate — Legal Risk Checklist ("how not to get sued")

> ⚠️ **I am not a lawyer and this is not legal advice.** I'm an AI assistant. This is a
> practical risk-reduction checklist written from common software-business patterns, to make
> your eventual conversation with a real solicitor cheaper and faster. Before you take money
> from the public, have a qualified lawyer in **your** country review the EULA, Privacy Policy,
> and the points below. Spending a few hundred euros on a one-hour review now is the single
> cheapest insurance you can buy.

---

## The big picture

You are a (likely) solo EU developer selling a €12/month AI tool worldwide. Your realistic legal
exposures, roughly in order of likelihood:

1. **A customer blames a bad translation for a loss** (mistranslated label, contract, safety notice).
2. **Consumer / tax / billing compliance** across many countries (VAT, refunds, auto-renewal rules).
3. **Trademark or "you're pretending to be Adobe" claims.**
4. **Data-protection (GDPR) complaints.**
5. **An AI provider or Adobe says you breached their terms.**

The good news: the architecture (BYOK, local processing, merchant-of-record billing) already removes
most of the teeth. The rest is paperwork and discipline.

---

## 1. Your biggest shield: sell through a Merchant of Record (Lemon Squeezy)

This is the most important single decision and you've already chosen it.

- **What it does:** Lemon Squeezy becomes the *seller of record*. They collect the money, charge and
  remit **VAT/sales tax in every country**, issue invoices, handle **refunds and chargebacks**, and carry
  the consumer-contract relationship for payment. You are effectively selling to *them*.
- **Why it matters:** VAT-MOSS across the EU + US sales tax + global consumer billing law is the kind of
  thing that sinks solo devs. Outsourcing it to an MoR removes ~80% of your tax/billing legal surface.
- **Do:** keep using LS (or Paddle/Gumroad) as MoR. **Don't** wire up raw Stripe/PayPal direct — that puts
  the entire tax + consumer-billing burden back on you.
- **Action:** confirm your LS store's refund policy is published and link it from checkout.

## 2. Limit liability for translation errors (your #1 lawsuit risk)

A customer ships a mistranslated safety warning and there's a loss → they look for someone to blame.

- ✅ The EULA now has: "as is" disclaimer, **no-reliance-for-high-stakes-use** clause, a duty on the user to
  do **human review**, and a **liability cap** (fees paid in 12 months, or €50).
- ✅ The product is honest that AI translation can contain errors (matches your "no surprises" brand).
- **Reality check:** in the EU you **cannot** fully exclude liability for death/personal injury from
  negligence, fraud, or other mandatory consumer protections — the EULA says so (don't try to over-exclude;
  an over-broad clause can be struck out *entirely*). The cap + human-review duty is the right posture.
- **Action:** keep the in-app and listing copy consistent with this — never claim "perfect", "accurate", or
  "publication-ready without review." Say "review-ready", "draft", "human-in-the-loop".

## 3. The "monthly updates" promise — soften it before it bites

You want to advertise monthly updates. If you bill €12/mo and then go three months without an update, an
unhappy customer (or a consumer authority) could call that a misleading commitment.

- ✅ The EULA §5 frames updates as **best-effort intent, not a contractual guarantee**, and says features/timing
  may change.
- **Action — marketing wording:** say *"regular updates — we aim for monthly"* or *"actively developed, frequent
  updates"* rather than a hard *"you get a new feature every month, guaranteed."* The write-up and requests page
  already use the softer wording. Keep it that way on the Adobe listing and website.

## 4. Trademarks & "not affiliated with Adobe"

- ✅ EULA + write-up + requests page all carry the **"independent, not affiliated with/endorsed by Adobe"**
  disclaimer, and treat Adobe/OpenAI/etc. as trademarks of their owners (nominative use — allowed to say your
  plugin *works with* InDesign; not allowed to imply Adobe made or endorsed it).
- **Action — name check:** confirm "FormatFlow" / "FormatFlow Translate" doesn't collide with an existing
  registered trademark in your class (EUIPO + your national register; a quick search, or a lawyer/TM agent).
  You already use "FormatFlow" for the Studio product too, so consider a basic EU trademark filing to protect
  the brand you're building. Don't put "Adobe", "InDesign", or a provider name *in your product name or logo*.
- **Action — Adobe policy:** the listing must follow Adobe's developer brand guidelines and Developer
  Distribution agreement (you accept this in the portal). Don't use Adobe's logo as your icon.

## 5. GDPR / privacy (lighter than most, because of BYOK)

- ✅ You process almost no personal data: no document content reaches you, no analytics/telemetry, keys stay
  local. The Privacy Policy reflects this. That's a genuinely strong position.
- **Action:** fill in the **data-controller identity** in the Privacy Policy (GDPR requires naming who you are
  and how to reach you). You can use a **business address or a registered-agent/PO box** — you don't have to
  publish your home address, but you must be contactable. If you're a sole trader, a lawyer can advise on the
  minimum disclosure for your country.
- **Action:** keep the provider privacy links current; you already link OpenAI/Anthropic/Google.

## 6. Adobe & AI-provider terms

- **Adobe:** accepting the Developer Distribution agreement binds you to their content/behaviour policies
  (no malware, no hidden data collection, accurate listing, support obligations). Your plugin is clean on all
  of these (the secret-scan confirmed no telemetry, no bundled keys).
- **AI providers:** because it's BYOK, the user — not you — is the provider's customer. The EULA makes the user
  responsible for their provider terms. Good. Just don't *resell* provider output or cache it server-side (you
  don't).

## 7. Company structure (ask your accountant/lawyer)

- Selling as a **sole trader** means personal liability. For a product with worldwide customers, ask whether a
  **limited company / GmbH / Ltd / BV** (whatever fits your country) is worth it to ring-fence personal assets.
  The liability cap helps, but a corporate wrapper is the real firewall. This is a tax + cost trade-off — get
  advice for your situation.

---

## Pre-launch legal checklist (tick before you take public money)

- [ ] EULA & Privacy Policy reviewed by a qualified lawyer in your jurisdiction
- [ ] All `[FILL IN]` placeholders completed (legal name, country/governing law, contact address)
- [ ] EULA + Privacy Policy deployed at public URLs and linked from the Adobe listing **and** checkout
- [ ] Lemon Squeezy (or other MoR) live, refund policy published, VAT handled by them
- [ ] Subscription terms at checkout state: €12/mo, auto-renews, cancel anytime
- [ ] Listing/website/in-app copy contains **no accuracy guarantees**; uses "review-ready", "human review"
- [ ] "Monthly updates" worded as best-effort intent, not a guarantee (done in our drafts)
- [ ] "Not affiliated with Adobe" disclaimer on listing + site + in-app About
- [ ] "FormatFlow" trademark search done (and ideally an application filed)
- [ ] Decide sole-trader vs. company with your accountant
- [ ] Keep a dated copy of each terms version (you may need to prove what a customer agreed to)

---

## What our drafts already cover (so you can tell the lawyer "review these, don't write from scratch")

- `docs/site/eula.html` — EULA & Terms: trial, €12/mo + auto-renew, EU withdrawal, updates-are-best-effort,
  BYOK, high-stakes no-reliance, warranty disclaimer, liability cap with mandatory-rights carve-out, indemnity,
  governing law (placeholder).
- `docs/site/privacy.html` — Privacy Policy: no document content, BYOK keys local, no analytics, license/email
  via MoR, GDPR rights, controller identity (placeholder).
- This memo — the practical risk map.

*Again: not legal advice. Get a human lawyer to bless the final versions before launch.*
