/*
 * Subscription licensing (BYOK stays separate — AI usage is billed by the
 * user's own provider; this license covers the plugin itself).
 *
 * Wired for Lemon Squeezy's public license API (no server of your own needed):
 *   1. Create a store + subscription product at lemonsqueezy.com
 *   2. Enable "License keys" on the product
 *   3. Paste your checkout URL into CONFIG.buyUrl
 *   4. Flip CONFIG.enabled to true
 * Until enabled, the plugin runs fully unlocked (development mode).
 */
(function () {
  const CONFIG = {
    enabled: false, // ← flip to true when your store is live
    trialDays: 14,
    activateUrl: "https://api.lemonsqueezy.com/v1/licenses/activate",
    validateUrl: "https://api.lemonsqueezy.com/v1/licenses/validate",
    instanceName: "formatflow-translate-indesign",
    revalidateHours: 72, // re-check the key against the API at most this often
    urls: {
      website: "https://formatflow.ai",
      buy: "https://formatflow.lemonsqueezy.com/checkout",     // ← your checkout
      support: "mailto:matt@bear-cg.com",
      faq: "https://formatflow.ai/#faq",
      docs: "https://formatflow.ai/docs.html"
    }
  };

  const KEY_LICENSE = "aitpro_license_key";
  const KEY_VALIDATED_AT = "aitpro_license_validated_at";
  const KEY_FIRST_RUN = "aitpro_first_run";

  function now() { return Date.now(); }

  function firstRunAt() {
    let t = parseInt(localStorage.getItem(KEY_FIRST_RUN) || "0", 10);
    if (!t) { t = now(); localStorage.setItem(KEY_FIRST_RUN, String(t)); }
    return t;
  }

  function trialDaysLeft() {
    const elapsed = now() - firstRunAt();
    return Math.max(0, CONFIG.trialDays - Math.floor(elapsed / 86400000));
  }

  function storedKey() { return localStorage.getItem(KEY_LICENSE) || ""; }

  function lastValidatedAt() { return parseInt(localStorage.getItem(KEY_VALIDATED_AT) || "0", 10); }

  // Synchronous snapshot used for gating. Revalidation happens in the background.
  function state() {
    if (!CONFIG.enabled) return { ok: true, mode: "unlocked", message: "Licensing not enforced (development build)." };
    const key = storedKey();
    if (key && lastValidatedAt() > 0) {
      return { ok: true, mode: "active", message: "License active." };
    }
    const days = trialDaysLeft();
    if (days > 0) {
      return { ok: true, mode: "trial", daysLeft: days, message: `Free trial — ${days} day${days === 1 ? "" : "s"} left.` };
    }
    return {
      ok: false,
      mode: "expired",
      message: "Trial ended. Add a license key in Settings to keep translating (your AI provider keys are unaffected)."
    };
  }

  async function callLicenseApi(url, key) {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Accept": "application/json" },
      body: JSON.stringify({ license_key: key, instance_name: CONFIG.instanceName })
    });
    const data = await res.json().catch(() => ({}));
    return { ok: res.ok, data };
  }

  async function activate(key) {
    key = String(key || "").trim();
    if (!key) throw new Error("Enter a license key first.");
    if (!CONFIG.enabled) {
      localStorage.setItem(KEY_LICENSE, key);
      localStorage.setItem(KEY_VALIDATED_AT, String(now()));
      return { ok: true, mode: "active", message: "Key stored (licensing not enforced in this build)." };
    }
    let result = await callLicenseApi(CONFIG.activateUrl, key);
    const activated = result.data && (result.data.activated === true || result.data.valid === true);
    if (!activated) {
      // Already-activated keys fail activation but pass validation.
      result = await callLicenseApi(CONFIG.validateUrl, key);
      if (!(result.data && result.data.valid === true)) {
        const reason = (result.data && result.data.error) || "the key was not accepted";
        throw new Error(`Could not activate license: ${reason}.`);
      }
    }
    localStorage.setItem(KEY_LICENSE, key);
    localStorage.setItem(KEY_VALIDATED_AT, String(now()));
    return { ok: true, mode: "active", message: "License activated on this machine." };
  }

  function deactivate() {
    localStorage.removeItem(KEY_LICENSE);
    localStorage.removeItem(KEY_VALIDATED_AT);
  }

  // Background re-check; never blocks the user on a network hiccup.
  async function revalidateIfDue() {
    if (!CONFIG.enabled) return;
    const key = storedKey();
    if (!key) return;
    if (now() - lastValidatedAt() < CONFIG.revalidateHours * 3600000) return;
    try {
      const result = await callLicenseApi(CONFIG.validateUrl, key);
      if (result.data && result.data.valid === true) {
        localStorage.setItem(KEY_VALIDATED_AT, String(now()));
      } else if (result.ok) {
        deactivate(); // key revoked/expired server-side
      }
    } catch (_) { /* offline — keep last known state */ }
  }

  window.AIT_License = { CONFIG, state, activate, deactivate, revalidateIfDue, trialDaysLeft };
})();
