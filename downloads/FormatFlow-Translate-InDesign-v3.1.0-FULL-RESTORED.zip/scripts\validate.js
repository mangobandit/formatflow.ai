const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const required = [
  'manifest.json',
  'index.html',
  'css/styles.css',
  'lib/fflate.js',
  'src/languages.js',
  'src/storage.js',
  'src/glossary.js',
  'src/protectors.js',
  'src/providers.js',
  'src/indesign-dom.js',
  'src/idml-engine.js',
  'src/deepl-document-engine.js',
  'src/batch-engine.js',
  'src/license.js',
  'src/ui.js'
];

let ok = true;
for (const file of required) {
  const full = path.join(root, file);
  if (!fs.existsSync(full)) {
    console.error(`Missing ${file}`);
    ok = false;
  }
}

const manifest = JSON.parse(fs.readFileSync(path.join(root, 'manifest.json'), 'utf8'));
if (manifest.manifestVersion !== 5) throw new Error('manifestVersion must be 5');
if (!manifest.host || manifest.host.app !== 'ID') throw new Error('manifest host must target InDesign');
if (!manifest.entrypoints || !manifest.entrypoints.length) throw new Error('manifest missing entrypoints');

for (const js of required.filter(f => f.endsWith('.js'))) {
  new Function(fs.readFileSync(path.join(root, js), 'utf8'));
}

if (!ok) process.exit(1);
console.log('Validation passed.');
