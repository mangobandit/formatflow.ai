(function () {
  function parseCsv(text) {
    if (!text || !text.trim()) return [];
    const lines = text.split(/\r?\n/).filter(line => line.trim() && !line.trim().startsWith("#"));
    const items = [];
    for (const line of lines) {
      const cols = splitCsvLine(line).map(s => s.trim());
      if (cols.length < 2) continue;
      const [source, target, note] = cols;
      if (!source || !target || /^source$/i.test(source)) continue;
      items.push({ source, target, note: note || "" });
    }
    return dedupe(items);
  }

  function splitCsvLine(line) {
    const out = [];
    let current = "";
    let quoted = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      const next = line[i + 1];
      if (ch === '"' && quoted && next === '"') { current += '"'; i++; }
      else if (ch === '"') quoted = !quoted;
      else if (ch === "," && !quoted) { out.push(current); current = ""; }
      else current += ch;
    }
    out.push(current);
    return out;
  }

  function dedupe(items) {
    const seen = new Set();
    const out = [];
    for (const item of items) {
      const key = `${item.source}\u0000${item.target}`.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      out.push(item);
    }
    return out;
  }

  function filterGlossaryForText(glossary, text, max = 220) {
    if (!glossary || !glossary.length) return [];
    const lower = String(text || "").toLowerCase();
    const direct = glossary.filter(g => lower.includes(String(g.source).toLowerCase()));
    if (direct.length >= max) return direct.slice(0, max);
    const remaining = glossary.filter(g => !direct.includes(g));
    return direct.concat(remaining.slice(0, Math.max(0, max - direct.length)));
  }

  function toPromptLines(glossary) {
    return (glossary || []).map(item => {
      const note = item.note ? ` (${item.note})` : "";
      return `- ${item.source} => ${item.target}${note}`;
    }).join("\n");
  }

  window.AIT_Glossary = { parseCsv, filterGlossaryForText, toPromptLines };
})();
