/*
 * IDML translation engine — the architecture used by professional InDesign
 * translation tools: export the document to IDML (a zip of XML), translate the
 * text inside the XML, rebuild the package, and let InDesign open the result.
 * The live document is never edited, so layout/styles/tables are preserved by
 * construction and live-DOM corruption is structurally impossible.
 */
(function () {
  const PI_TOKEN = i => `[[[AIT_PI_${i}]]]`;
  const PI_TOKEN_RE = /\[\[\[AIT_PI_\d+\]\]\]/g;

  function getFflate() {
    const f = (typeof window !== "undefined" && window.fflate) || (typeof self !== "undefined" && self.fflate);
    if (!f) throw new Error("Zip library (lib/fflate.js) failed to load.");
    return f;
  }

  function getUxpStorage() {
    const uxp = require("uxp");
    return { fsProvider: uxp.storage.localFileSystem, formats: uxp.storage.formats };
  }

  /* ---------- XML text helpers ---------- */

  function decodeXml(s) {
    return String(s == null ? "" : s)
      .replace(/&#x([0-9a-fA-F]+);/g, (m, h) => String.fromCodePoint(parseInt(h, 16)))
      .replace(/&#(\d+);/g, (m, d) => String.fromCodePoint(parseInt(d, 10)))
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace(/&quot;/g, '"')
      .replace(/&apos;/g, "'")
      .replace(/&amp;/g, "&");
  }

  function encodeXml(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  function normForCompare(s) {
    return String(s == null ? "" : s)
      .replace(PI_TOKEN_RE, "")
      .replace(/[‘’]/g, "'")
      .replace(/[“”]/g, '"');
  }

  /* ---------- Export + load ---------- */

  async function exportAndLoad(outputFolder, doc, baseName) {
    const dom = window.AIT_InDesignDom;
    const { fsProvider, formats } = getUxpStorage();
    const sep = String(outputFolder.nativePath || "").indexOf("\\") !== -1 ? "\\" : "/";
    const tmpName = `${dom.safeFilePart(baseName)}.ait-tmp.idml`;
    const tmpPath = `${outputFolder.nativePath}${sep}${tmpName}`;

    await dom.exportDocumentToIdml(doc, tmpPath);

    let entry = null;
    try { entry = await outputFolder.getEntry(tmpName); } catch (_) {}
    if (!entry) entry = await fsProvider.getEntryWithUrl(tmpPath);

    const buf = await entry.read({ format: formats.binary });
    const files = getFflate().unzipSync(new Uint8Array(buf));
    await deleteEntry(entry, tmpPath);
    return { files };
  }

  async function deleteEntry(entry, nativePath) {
    try { if (entry && typeof entry.delete === "function") { await entry.delete(); return; } } catch (_) {}
    try {
      const fs = require("fs");
      await fs.unlink(nativePath || entry.nativePath);
    } catch (_) {}
  }

  /* ---------- Extraction ---------- */

  function listStoryFiles(files) {
    return Object.keys(files)
      .filter(n => /^Stories\/[^/]+\.xml$/i.test(n) || /^XML\/BackingStory\.xml$/i.test(n))
      .sort();
  }

  // Walks story XML: <Content> runs grouped into logical paragraphs, with <Br/>
  // and ParagraphStyleRange closes as paragraph boundaries. Table cell text
  // lives in the same story XML, so tables are covered automatically.
  function parseParagraphs(xml) {
    const re = /<Content>([\s\S]*?)<\/Content>|<Br\b[^>]*\/>|<\/ParagraphStyleRange>/g;
    const paras = [];
    let current = [];
    let m;
    while ((m = re.exec(xml))) {
      if (m[1] !== undefined) {
        current.push({ start: m.index, end: m.index + m[0].length, raw: m[1] });
      } else {
        if (current.length) paras.push({ runs: current });
        current = [];
      }
    }
    if (current.length) paras.push({ runs: current });

    for (const p of paras) {
      p.runs.forEach(run => {
        run.pis = [];
        // Processing instructions (auto page numbers, footnote markers, etc.)
        // become opaque tokens the model must preserve verbatim.
        const tokenized = run.raw.replace(/<\?[\s\S]*?\?>/g, mm => {
          run.pis.push(mm);
          return PI_TOKEN(run.pis.length - 1);
        });
        run.working = decodeXml(tokenized);
      });
    }
    return paras;
  }

  function extractUnits(files, options) {
    const fflate = getFflate();
    const units = [];
    const stories = {};
    let storyIndex = 0;
    for (const name of listStoryFiles(files)) {
      const xml = fflate.strFromU8(files[name]);
      stories[name] = xml;
      const paras = parseParagraphs(xml);
      paras.forEach((para, paraIndex) => {
        const joined = para.runs.map(r => r.working).join("");
        if (!joined.replace(PI_TOKEN_RE, "").replace(/[\s﻿]+/g, "").length) return; // nothing human-translatable
        units.push(buildUnit(name, storyIndex, paraIndex, para, options));
      });
      storyIndex++;
    }
    return { units, stories };
  }

  function buildUnit(fileName, storyIndex, paraIndex, para, options) {
    const P = window.AIT_Protectors;
    const protect = !options || options.protectPlaceholders !== false;
    const originalText = para.runs.map(r => r.working).join("");
    let mode = "plain";
    let preparedText = "";
    let placeholders = [];
    let runs = [];

    if (para.runs.length > 1) {
      // Styled spans: translate the whole paragraph with inline run tags so the
      // model sees full sentences but styling boundaries survive.
      mode = "tagged-runs";
      runs = para.runs.map(r => {
        const prot = protect ? P.protectText(r.working) : { text: r.working, placeholders: [] };
        return { originalText: r.working, protectedText: prot.text, placeholders: prot.placeholders };
      });
      preparedText = P.makeTaggedRuns(runs);
    } else {
      const prot = protect ? P.protectText(originalText) : { text: originalText, placeholders: [] };
      preparedText = prot.text;
      placeholders = prot.placeholders;
    }

    return {
      id: `s${String(storyIndex).padStart(3, "0")}-p${String(paraIndex).padStart(4, "0")}`,
      fileName,
      paraIndex,
      para,
      originalText,
      textForTranslation: originalText,
      preparedText,
      placeholders,
      runs,
      mode,
      sourceLabel: `${fileName} ¶${paraIndex + 1}`
    };
  }

  /* ---------- Apply ---------- */

  function computeRunOutputs(unit, translated) {
    const P = window.AIT_Protectors;
    if (unit.mode === "tagged-runs") {
      const parsed = P.parseTaggedRuns(translated);
      if (parsed.length === unit.runs.length) {
        const ordered = new Array(unit.runs.length).fill(null);
        let clean = true;
        parsed.forEach(item => {
          if (item.index >= 0 && item.index < unit.runs.length && ordered[item.index] == null) ordered[item.index] = item.text;
          else clean = false;
        });
        if (clean && ordered.every(t => typeof t === "string")) {
          return { outputs: ordered.map((t, i) => P.restoreText(t, unit.runs[i].placeholders)), fallback: false };
        }
      }
      // Fallback: keep the text correct even if styling boundaries were lost —
      // the whole translation goes into the first run with its styling.
      let plain;
      if (parsed.length) {
        plain = parsed.sort((a, b) => a.index - b.index).map(item => {
          const run = unit.runs[item.index];
          return run ? P.restoreText(item.text, run.placeholders) : item.text;
        }).join("");
      } else {
        let t = String(translated == null ? "" : translated).replace(/<\/?r\b[^>]*>/gi, "");
        unit.runs.forEach(run => { t = P.restoreText(t, run.placeholders); });
        plain = t;
      }
      const outputs = unit.runs.map(() => "");
      outputs[0] = plain;
      return { outputs, fallback: true };
    }
    let out = P.restoreText(translated, unit.placeholders);
    out = P.normalizeWhitespace(unit.textForTranslation, out);
    return { outputs: [out], fallback: false };
  }

  // Builds new story XML with translations swapped in, then re-parses the result
  // and verifies every unit before returning. Throws on any integrity failure.
  function applyTranslations(files, extraction, translationMap) {
    const fflate = getFflate();
    const replacementsByFile = {};
    const expectedById = {};
    const fallbackUnits = [];
    const missing = [];

    for (const unit of extraction.units) {
      const translated = translationMap[unit.id];
      if (typeof translated !== "string") { missing.push(unit.id); continue; }
      const computed = computeRunOutputs(unit, translated);
      if (computed.fallback) fallbackUnits.push(unit.id);
      expectedById[unit.id] = computed.outputs.join("");
      const list = replacementsByFile[unit.fileName] || (replacementsByFile[unit.fileName] = []);
      unit.para.runs.forEach((run, i) => {
        let xmlText = encodeXml(computed.outputs[i] != null ? computed.outputs[i] : "");
        // Re-insert this run's processing instructions; append any the model dropped.
        run.pis.forEach((pi, k) => {
          const token = PI_TOKEN(k);
          if (xmlText.indexOf(token) !== -1) xmlText = xmlText.split(token).join(pi);
          else xmlText += pi;
        });
        xmlText = xmlText.replace(PI_TOKEN_RE, ""); // never leak tokens into the document
        list.push({ start: run.start, end: run.end, replacement: `<Content>${xmlText}</Content>` });
      });
    }
    if (missing.length) {
      throw new Error(`Missing translations for ${missing.length} block(s): ${missing.slice(0, 8).join(", ")}`);
    }

    const outFiles = {};
    for (const name of Object.keys(files)) outFiles[name] = files[name];
    for (const fileName of Object.keys(replacementsByFile)) {
      let xml = extraction.stories[fileName];
      const list = replacementsByFile[fileName].sort((a, b) => b.start - a.start);
      for (const r of list) xml = xml.slice(0, r.start) + r.replacement + xml.slice(r.end);
      outFiles[fileName] = fflate.strToU8(xml);
    }

    const verification = verifyFiles(outFiles, extraction, expectedById);
    if (verification.failed.length) {
      const sample = verification.failed.slice(0, 5).map(f => f.id).join(", ");
      throw new Error(`IDML verification failed for ${verification.failed.length} of ${verification.checked} block(s) (${sample}). Nothing was written.`);
    }
    return { files: outFiles, checked: verification.checked, fallbackUnits };
  }

  function verifyFiles(outFiles, extraction, expectedById) {
    const fflate = getFflate();
    const failed = [];
    let checked = 0;
    const parsedCache = {};
    for (const unit of extraction.units) {
      const expected = expectedById[unit.id];
      if (typeof expected !== "string") continue;
      let paras = parsedCache[unit.fileName];
      if (!paras) paras = parsedCache[unit.fileName] = parseParagraphs(fflate.strFromU8(outFiles[unit.fileName]));
      checked++;
      const para = paras[unit.paraIndex];
      if (!para || para.runs.length !== unit.para.runs.length) {
        failed.push({ id: unit.id, reason: "paragraph structure changed" });
        continue;
      }
      const actual = para.runs.map(r => r.working).join("");
      if (normForCompare(actual) !== normForCompare(expected)) {
        failed.push({ id: unit.id, reason: "text mismatch", expected: expected.slice(0, 60), actual: actual.slice(0, 60) });
      }
    }
    return { checked, failed };
  }

  /* ---------- Build + write + open ---------- */

  async function writeIdml(outputFolder, name, filesObj) {
    const fflate = getFflate();
    const { formats } = getUxpStorage();
    // IDML packages expect the mimetype entry first and uncompressed.
    const ordered = {};
    if (filesObj.mimetype) ordered.mimetype = [filesObj.mimetype, { level: 0 }];
    for (const key of Object.keys(filesObj)) {
      if (key !== "mimetype") ordered[key] = filesObj[key];
    }
    const bytes = fflate.zipSync(ordered);
    const arrayBuffer = (bytes.byteOffset === 0 && bytes.byteLength === bytes.buffer.byteLength)
      ? bytes.buffer
      : bytes.slice().buffer;
    const file = await outputFolder.createFile(name, { overwrite: true });
    await file.write(arrayBuffer, { format: formats.binary });
    return file;
  }

  async function openAsIndd(idmlEntry, outputFolder, inddName, settings, language) {
    const dom = window.AIT_InDesignDom;
    const doc = await dom.openDocumentFile(idmlEntry);
    try {
      if (settings && settings.rtlSupport && language && language.rtl) {
        try { dom.applyRtl(doc, language); } catch (_) {}
      }
      try { dom.recompose(doc); } catch (_) {}
      let autoFit = null;
      if (!settings || settings.autoFit !== false) {
        try { autoFit = dom.autoFitOverset(doc, settings && settings.fitOptions); } catch (_) {}
      }
      let overset = { count: 0, details: [] };
      try { overset = dom.countOversetStories(doc); } catch (_) {}
      const outFile = await outputFolder.createFile(inddName, { overwrite: true });
      await dom.saveDocumentAs(doc, outFile);

      // Batch PDF: export a print PDF per language using the app's current
      // PDF export settings.
      let pdfName = null;
      if (settings && settings.exportPdf) {
        const sep = String(outputFolder.nativePath || "").indexOf("\\") !== -1 ? "\\" : "/";
        pdfName = inddName.replace(/\.indd$/i, ".pdf");
        await dom.exportDocumentToPdf(doc, `${outputFolder.nativePath}${sep}${pdfName}`);
      }

      let keptDoc = null;
      if (!settings || settings.keepOpen !== false) keptDoc = doc;
      else await dom.closeDocument(doc, false);
      return { keptDoc, oversetCount: overset.count, oversetDetails: overset.details, autoFit, pdfName };
    } catch (err) {
      try { await dom.closeDocument(doc, false); } catch (_) {}
      throw err;
    }
  }

  window.AIT_IdmlEngine = {
    exportAndLoad,
    extractUnits,
    applyTranslations,
    writeIdml,
    openAsIndd,
    deleteEntry
  };
})();
