# QA checklist before selling or using on critical client work

- Run on a duplicate of the original `.indd` file.
- Check all output files open correctly.
- Check that paragraph styles remain applied.
- Check mixed bold/italic/superscript/colored character styles.
- Check tables and merged cells.
- Check hyperlinks and URL text.
- Check product codes and variables.
- Check Arabic, Hebrew, and Persian reading direction.
- Check overset text warnings in the report.
- Check glossary terms in headings, body copy, callouts, and tables.
- Check locked items were intentionally skipped.
- Check master-page text if the document relies on master-page content.
