(function () {
  const TARGET_CODE_MAP = {
    "en": "EN-US",
    "en-us": "EN-US",
    "en-gb": "EN-GB",
    "pt": "PT-PT",
    "pt-br": "PT-BR",
    "es": "ES",
    "es-419": "ES-419",
    "zh": "ZH-HANS",
    "zh-tw": "ZH-HANT",
    "no": "NB"
  };

  const SOURCE_CODE_MAP = {
    "en": "EN",
    "en-us": "EN",
    "en-gb": "EN",
    "pt": "PT",
    "pt-br": "PT",
    "es-419": "ES",
    "zh": "ZH",
    "zh-tw": "ZH",
    "no": "NB"
  };

  function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

  function baseUrl(apiKey) {
    return String(apiKey || "").trim().toLowerCase().endsWith(":fx")
      ? "https://api-free.deepl.com"
      : "https://api.deepl.com";
  }

  function normalizeCode(code) {
    return String(code || "").trim().replace(/_/g, "-");
  }

  function targetCode(language) {
    const code = normalizeCode(language && language.code);
    if (!code || code === "auto") throw new Error("DeepL Document API needs a concrete target language.");
    return TARGET_CODE_MAP[code.toLowerCase()] || code.toUpperCase();
  }

  function sourceCode(settings) {
    const code = normalizeCode(settings && settings.sourceLang);
    if (!code || code === "auto") return "";
    return SOURCE_CODE_MAP[code.toLowerCase()] || code.toUpperCase();
  }

  function getUxpStorage() {
    const uxp = require("uxp");
    return { fsProvider: uxp.storage.localFileSystem, formats: uxp.storage.formats };
  }

  function encodeUtf8(text) {
    if (typeof TextEncoder !== "undefined") return new TextEncoder().encode(String(text));
    const encoded = unescape(encodeURIComponent(String(text)));
    const out = new Uint8Array(encoded.length);
    for (let i = 0; i < encoded.length; i++) out[i] = encoded.charCodeAt(i);
    return out;
  }

  function toBytes(value) {
    if (value instanceof Uint8Array) return value;
    if (value && value.buffer instanceof ArrayBuffer) return new Uint8Array(value.buffer, value.byteOffset || 0, value.byteLength);
    if (value instanceof ArrayBuffer) return new Uint8Array(value);
    return encodeUtf8(value || "");
  }

  function concatBytes(parts) {
    let total = 0;
    parts.forEach(part => { total += toBytes(part).byteLength; });
    const out = new Uint8Array(total);
    let offset = 0;
    parts.forEach(part => {
      const bytes = toBytes(part);
      out.set(bytes, offset);
      offset += bytes.byteLength;
    });
    return out;
  }

  function multipartBody(fields, file) {
    const boundary = `----formatflow-deepl-${Date.now()}-${Math.round(Math.random() * 1e9)}`;
    const parts = [];
    Object.keys(fields).forEach(name => {
      if (fields[name] == null || fields[name] === "") return;
      parts.push(`--${boundary}\r\n`);
      parts.push(`Content-Disposition: form-data; name="${name}"\r\n\r\n`);
      parts.push(`${fields[name]}\r\n`);
    });
    parts.push(`--${boundary}\r\n`);
    parts.push(`Content-Disposition: form-data; name="file"; filename="${file.name}"\r\n`);
    parts.push("Content-Type: application/vnd.adobe.indesign-idml-package\r\n\r\n");
    parts.push(file.bytes);
    parts.push("\r\n");
    parts.push(`--${boundary}--\r\n`);
    return { boundary, bytes: concatBytes(parts) };
  }

  async function fetchJson(url, options, label) {
    const res = await fetch(url, options);
    const text = await res.text();
    let data = {};
    try { data = text ? JSON.parse(text) : {}; } catch (_) { data = { raw: text }; }
    if (!res.ok) throw new Error(`${label} failed (${res.status}): ${text.slice(0, 1000)}`);
    return data;
  }

  async function fetchBinary(url, options, label) {
    const res = await fetch(url, options);
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      throw new Error(`${label} failed (${res.status}): ${text.slice(0, 1000)}`);
    }
    return await res.arrayBuffer();
  }

  async function exportSourceIdml(outputFolder, doc, baseName) {
    const dom = window.AIT_InDesignDom;
    const { fsProvider, formats } = getUxpStorage();
    const sep = String(outputFolder.nativePath || "").indexOf("\\") !== -1 ? "\\" : "/";
    const safeBase = dom.safeFilePart(baseName);
    const tmpName = `${safeBase} - deepl-upload-source.idml`;
    const tmpPath = `${outputFolder.nativePath}${sep}${tmpName}`;
    await dom.exportDocumentToIdml(doc, tmpPath);
    let entry = null;
    try { entry = await outputFolder.getEntry(tmpName); } catch (_) {}
    if (!entry) entry = await fsProvider.getEntryWithUrl(tmpPath);
    const bytes = await entry.read({ format: formats.binary });
    return { entry, bytes: toBytes(bytes), filename: `${safeBase}.idml`, tmpPath };
  }

  async function uploadDocument(apiKey, source, settings, language, log) {
    const fields = {
      target_lang: targetCode(language),
      source_lang: sourceCode(settings)
    };
    const body = multipartBody(fields, { name: source.filename, bytes: source.bytes });
    log(`DeepL Document API upload: ${source.filename}, ${source.bytes.byteLength.toLocaleString()} IDML bytes, target ${fields.target_lang}.`);
    const data = await fetchJson(`${baseUrl(apiKey)}/v2/document`, {
      method: "POST",
      headers: {
        "Authorization": `DeepL-Auth-Key ${apiKey}`,
        "Content-Type": `multipart/form-data; boundary=${body.boundary}`
      },
      body: body.bytes.buffer
    }, "DeepL document upload");
    if (!data.document_id || !data.document_key) throw new Error("DeepL document upload response missing document_id/document_key.");
    log(`DeepL Document API accepted upload: document_id=${data.document_id}.`);
    return data;
  }

  async function pollDocument(apiKey, document, log, progressText) {
    const url = `${baseUrl(apiKey)}/v2/document/${encodeURIComponent(document.document_id)}`;
    let lastStatus = "";
    for (let attempt = 0; attempt < 90; attempt++) {
      const data = await fetchJson(url, {
        method: "POST",
        headers: {
          "Authorization": `DeepL-Auth-Key ${apiKey}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ document_key: document.document_key })
      }, "DeepL document status");
      const status = data.status || "unknown";
      if (status !== lastStatus || attempt % 5 === 0) {
        const billed = typeof data.billed_characters === "number" ? `, billed ${data.billed_characters.toLocaleString()} characters` : "";
        const eta = typeof data.seconds_remaining === "number" ? `, eta ${data.seconds_remaining}s` : "";
        log(`DeepL Document API status: ${status}${billed}${eta}.`);
        lastStatus = status;
      }
      if (status === "done") return data;
      if (status === "error") throw new Error(`DeepL document translation failed: ${data.message || "unknown error"}`);
      progressText(status);
      await sleep(Math.min(10000, 1200 + attempt * 600));
    }
    throw new Error("DeepL document translation timed out while waiting for status=done.");
  }

  async function downloadDocument(apiKey, document, log) {
    const url = `${baseUrl(apiKey)}/v2/document/${encodeURIComponent(document.document_id)}/result`;
    const bytes = await fetchBinary(url, {
      method: "POST",
      headers: {
        "Authorization": `DeepL-Auth-Key ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ document_key: document.document_key })
    }, "DeepL document download");
    log(`DeepL Document API downloaded translated IDML: ${bytes.byteLength.toLocaleString()} bytes.`);
    return bytes;
  }

  async function writeBinaryFile(outputFolder, name, bytes) {
    const { formats } = getUxpStorage();
    const file = await outputFolder.createFile(name, { overwrite: true });
    await file.write(bytes, { format: formats.binary });
    return file;
  }

  async function runBatch(settings, hooks) {
    hooks = hooks || {};
    const log = hooks.log || function () {};
    const progress = hooks.progress || function () {};
    const cancelled = hooks.cancelled || function () { return false; };
    const dom = window.AIT_InDesignDom;
    const idml = window.AIT_IdmlEngine;
    const languages = settings.targetLanguages || [];

    if (!settings.apiKey) throw new Error("Missing DeepL API key.");
    if (!languages.length) throw new Error("Select at least one target language.");
    if (!settings.outputFolder) throw new Error("Choose an output folder first.");

    const sourceDoc = dom.getActiveDocument();
    const baseName = dom.getDocumentBaseName(sourceDoc);
    const safeBase = dom.safeFilePart(baseName);
    log(`Document: ${sourceDoc.name || baseName}`);
    log("Workflow: DeepL Document API V3 - export IDML, upload full document to DeepL, poll, download translated IDML, then save INDD.");

    progress(0.03, "Exporting IDML...");
    const source = await exportSourceIdml(settings.outputFolder, sourceDoc, baseName);
    const report = { document: sourceDoc.name || baseName, languages: [] };
    let lastKeptOpen = null;

    try {
      for (let i = 0; i < languages.length; i++) {
        if (cancelled()) throw new Error("Batch cancelled by user.");
        const language = languages[i];
        const safeLang = dom.safeFilePart(language.name);
        const langReport = { language: language.name, code: language.code, status: "queued", warnings: [], errors: [] };
        report.languages.push(langReport);
        log(`\nDeepL Document API: ${language.name}`);
        progress((i + 0.05) / languages.length, `${language.name}: uploading IDML to DeepL...`);
        langReport.status = "uploading";
        const document = await uploadDocument(settings.apiKey, source, settings, language, log);
        langReport.documentId = document.document_id;

        langReport.status = "translating";
        const status = await pollDocument(settings.apiKey, document, log, statusText => {
          progress((i + 0.45) / languages.length, `${language.name}: DeepL ${statusText}...`);
        });
        if (typeof status.billed_characters === "number") langReport.billedCharacters = status.billed_characters;

        progress((i + 0.75) / languages.length, `${language.name}: downloading translated IDML...`);
        langReport.status = "downloading";
        const translatedBytes = await downloadDocument(settings.apiKey, document, log);
        const idmlName = `${safeBase} - ${safeLang} - DeepL.idml`;
        const inddName = `${safeBase} - ${safeLang}.indd`;
        const idmlEntry = await writeBinaryFile(settings.outputFolder, idmlName, translatedBytes);
        log(`Saved translated IDML from DeepL: ${idmlName}`);

        langReport.status = "opening_in_indesign";
        progress((i + 0.9) / languages.length, `${language.name}: opening translated IDML...`);
        const opened = await idml.openAsIndd(idmlEntry, settings.outputFolder, inddName, settings, language);
        if (opened.autoFit && opened.autoFit.adjustedStories > 0) {
          log(`Auto-fit: ${opened.autoFit.adjustedStories} overset story/frame(s) adjusted.`);
        }
        if (opened.oversetCount > 0) log(`Warning: ${opened.oversetCount} story/frame(s) still overset after auto-fit.`);
        if (opened.pdfName) log(`Exported PDF: ${opened.pdfName}`);
        try { await idml.deleteEntry(idmlEntry); } catch (_) {}
        if (opened.keptDoc) lastKeptOpen = opened.keptDoc;
        langReport.outputFile = inddName;
        langReport.status = "saved";
        log(`Saved translated copy: ${inddName}`);
      }
    } finally {
      try { await idml.deleteEntry(source.entry, source.tmpPath); } catch (_) {}
    }

    if (lastKeptOpen) {
      try { dom.activateDocument(lastKeptOpen); } catch (_) {}
    }
    progress(1, "Complete");
    log("\nDeepL Document API batch complete. Original document was not edited.");
    return report;
  }

  window.AIT_DeepLDocumentEngine = {
    runBatch,
    _private: { multipartBody, targetCode, sourceCode, baseUrl }
  };
})();
