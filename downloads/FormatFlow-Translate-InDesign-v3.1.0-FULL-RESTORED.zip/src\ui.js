(function () {
  const $ = id => document.getElementById(id);
  let outputFolder = null;
  let pdfFolder = null;
  let glossary = [];
  let running = false;
  let cancelling = false;
  let sessionApiKey = "";
  let selectedLanguageCodes = new Set();
  let currentProvider = "deepl";
  let currentModel = "";
  const BUILD_ID = "v3.1.0-restored-overset-gpt-5.6";

  document.addEventListener("DOMContentLoaded", init);

  async function init() {
    try {
      applyTheme();
      renderSourceLanguages();
      renderQuickLanguages();
      renderLanguages();
      hydrateModelList();
      bindEvents();
      await restoreSettings();
      watchThemeChanges();
      renderLicenseStatus();
      window.AIT_License.revalidateIfDue().then(renderLicenseStatus).catch(() => {});
      log(`Build: ${BUILD_ID}`);
      log("Ready.");
    } catch (err) {
      fail(err);
    }
  }

  /* ---------- Spectrum picker helpers (sp-picker + sp-menu-item) ---------- */

  function populatePicker(id, items, selectedValue) {
    const picker = $(id);
    if (!picker) return;
    if (picker.tagName && picker.tagName.toLowerCase() === "select") {
      picker.innerHTML = "";
      items.forEach(item => {
        const option = document.createElement("option");
        option.value = item.value;
        option.textContent = item.label;
        if (selectedValue != null && item.value === selectedValue) option.selected = true;
        picker.appendChild(option);
      });
      if (selectedValue != null) picker.value = selectedValue;
      return;
    }
    const menu = picker.querySelector("sp-menu");
    if (!menu) return;
    menu.innerHTML = "";
    let selIdx = -1;
    items.forEach((item, i) => {
      const mi = document.createElement("sp-menu-item");
      mi.textContent = item.label;
      mi.setAttribute("value", item.value);
      if (selectedValue != null && item.value === selectedValue) {
        mi.setAttribute("selected", "");
        selIdx = i;
      }
      menu.appendChild(mi);
    });
    if (selIdx >= 0) {
      try { picker.selectedIndex = selIdx; } catch (_) {}
    }
  }

  function pickerValue(id) {
    const picker = $(id);
    if (!picker) return "";
    try {
      if (typeof picker.value === "string" && picker.value) return picker.value;
    } catch (_) {}
    try {
      const selectedItem = picker.selectedItem || picker.selectedElement;
      if (selectedItem) return selectedItem.getAttribute("value") || selectedItem.value || selectedItem.textContent || "";
    } catch (_) {}
    try {
      const idx = picker.selectedIndex;
      if (typeof idx === "number" && idx >= 0 && picker.options && picker.options[idx]) {
        return picker.options[idx].value || picker.options[idx].getAttribute("value") || "";
      }
    } catch (_) {}
    try {
      const sel = picker.querySelector("sp-menu-item[selected]");
      if (sel) return sel.getAttribute("value") || "";
    } catch (_) {}
    return "";
  }

  function eventPickerValue(event, fallbackId) {
    try {
      if (event && event.detail && typeof event.detail.value === "string" && event.detail.value) return event.detail.value;
    } catch (_) {}
    try {
      if (event && event.target && typeof event.target.value === "string" && event.target.value) return event.target.value;
    } catch (_) {}
    return pickerValue(fallbackId);
  }

  function selectedProviderValue() {
    const value = pickerValue("provider") || currentProvider || "deepl";
    currentProvider = value;
    return value;
  }

  function setPicker(id, value) {
    const picker = $(id);
    if (!picker || value == null) return;
    if (picker.tagName && picker.tagName.toLowerCase() === "select") {
      picker.value = value;
      return;
    }
    const menu = picker.querySelector("sp-menu");
    if (!menu) return;
    const items = Array.prototype.slice.call(menu.querySelectorAll("sp-menu-item"));
    let idx = -1;
    items.forEach((mi, i) => {
      const match = (mi.getAttribute("value") || "") === value;
      if (match) { mi.setAttribute("selected", ""); idx = i; }
      else mi.removeAttribute("selected");
    });
    if (idx >= 0) {
      try { picker.selectedIndex = idx; } catch (_) {}
      try { picker.value = value; } catch (_) {}
    }
  }

  function setDisabled(id, disabled) {
    const el = $(id);
    if (!el) return;
    if (disabled) el.setAttribute("disabled", "");
    else el.removeAttribute("disabled");
  }

  // SVG-safe class toggling (SVGElement.classList can be flaky in UXP).
  function setClassState(el, cls, on) {
    const cur = (el.getAttribute("class") || "").split(/\s+/).filter(Boolean);
    const has = cur.indexOf(cls) !== -1;
    if (on && !has) cur.push(cls);
    if (!on && has) cur.splice(cur.indexOf(cls), 1);
    el.setAttribute("class", cur.join(" "));
  }

  /* ---------- Theme ---------- */

  // Returns true (dark) / false (light) from InDesign's UI brightness setting, or null if unavailable.
  function detectInDesignDarkness() {
    try {
      const indesign = require("indesign");
      const app = indesign.app || indesign;
      const prefs = app && app.generalPreferences;
      const brightness = prefs ? prefs.uiBrightnessPreference : undefined;
      if (typeof brightness === "number") return brightness < 0.5;
    } catch (_) {}
    return null;
  }

  function applyTheme() {
    const mode = pickerValue("theme") || "auto";
    let dark = true;
    if (mode === "dark") dark = true;
    else if (mode === "light") dark = false;
    else {
      const hostDark = detectInDesignDarkness();
      if (hostDark !== null) dark = hostDark;
      else if (window.matchMedia) dark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    }
    document.documentElement.setAttribute("data-theme", dark ? "dark" : "light");
  }

  function watchThemeChanges() {
    try {
      if (window.matchMedia) {
        const mq = window.matchMedia("(prefers-color-scheme: dark)");
        if (typeof mq.addEventListener === "function") mq.addEventListener("change", applyTheme);
        else if (typeof mq.addListener === "function") mq.addListener(applyTheme);
      }
    } catch (_) {}
    // Re-check InDesign brightness when the user returns to the panel.
    window.addEventListener("focus", applyTheme);
    document.addEventListener("visibilitychange", applyTheme);
  }

  /* ---------- Event binding ---------- */

  function bindEvents() {
    document.querySelectorAll(".tab-icon").forEach(icon => {
      icon.addEventListener("click", () => switchTab(icon.getAttribute("data-tab")));
    });
    $("resetForm").addEventListener("click", resetForm);
    $("langToggle").addEventListener("click", toggleLanguagePanel);
    $("provider").addEventListener("change", async event => {
      currentProvider = eventPickerValue(event, "provider") || currentProvider || "deepl";
      hydrateModelList();
      await restoreApiKeyForProvider();
      log(`Provider selected: ${providerLabel(currentProvider)}.`);
    });
    $("model").addEventListener("change", event => { currentModel = eventPickerValue(event, "model") || currentModel; });
    // Persist the key the moment it's entered — no separate Save click needed.
    $("apiKey").addEventListener("change", persistApiKey);
    $("rememberKey").addEventListener("change", persistApiKey);
    $("testDeepL").addEventListener("click", testDeepLKey);
    $("theme").addEventListener("change", applyTheme);
    $("saveSettings").addEventListener("click", saveSettings);
    $("chooseFolder").addEventListener("click", chooseFolder);
    $("loadGlossary").addEventListener("click", loadGlossary);
    $("selectCore").addEventListener("click", () => selectPreset("core20"));
    $("selectEuro").addEventListener("click", () => selectPreset("europe"));
    $("selectAfrica").addEventListener("click", () => selectPreset("africa"));
    $("selectAsia").addEventListener("click", () => selectPreset("asia"));
    $("selectMiddleEast").addEventListener("click", () => selectPreset("middleEast"));
    $("selectAmericas").addEventListener("click", () => selectPreset("americas"));
    $("clearLangs").addEventListener("click", clearLanguages);
    $("toggleAllLanguages").addEventListener("change", toggleAllLanguages);
    $("languageSearch").addEventListener("input", renderLanguages);
    $("languageSearch").addEventListener("change", renderLanguages);
    $("estimate").addEventListener("click", estimate);
    $("translate").addEventListener("click", translateBatch);
    $("cancel").addEventListener("click", () => { cancelling = true; log("Cancellation requested. Finishing current request safely..."); });
    // Batch PDF tool
    $("pdfChooseFolder").addEventListener("click", choosePdfFolder);
    $("pdfRun").addEventListener("click", runBatchPdf);
    // Overset fixer tool
    $("fitScan").addEventListener("click", scanOverset);
    $("fitRun").addEventListener("click", fixOverset);
    // Quick translate tool
    $("quickRun").addEventListener("click", quickTranslate);
    $("quickCopy").addEventListener("click", copyQuickResult);
    // Preflight tool
    $("preflightRun").addEventListener("click", runPreflight);
    // License + external links
    $("licenseActivate").addEventListener("click", activateLicense);
    $("licenseBuy").addEventListener("click", () => openUrl(window.AIT_License.CONFIG.urls.buy));
    $("aboutWebsite").addEventListener("click", () => openUrl(window.AIT_License.CONFIG.urls.website));
    $("aboutFaq").addEventListener("click", () => openUrl(window.AIT_License.CONFIG.urls.faq));
    $("aboutSupport").addEventListener("click", () => openUrl(window.AIT_License.CONFIG.urls.support));
  }

  async function openUrl(url) {
    try { await require("uxp").shell.openExternal(url); } catch (err) { fail(err); }
  }

  /* ---------- License ---------- */

  function renderLicenseStatus() {
    const el = $("licenseStatus");
    if (!el) return;
    const s = window.AIT_License.state();
    el.textContent = s.message;
  }

  async function activateLicense() {
    try {
      setDisabled("licenseActivate", true);
      const result = await window.AIT_License.activate($("licenseKey").value);
      $("licenseStatus").textContent = result.message;
      log(result.message);
    } catch (err) {
      $("licenseStatus").textContent = err.message || String(err);
    } finally {
      setDisabled("licenseActivate", false);
    }
  }

  /* ---------- Tool tabs: shared mini-log ---------- */

  function miniLog(id, message) {
    const box = $(id);
    const prefix = box.textContent ? "\n" : "";
    box.textContent += `${prefix}${message}`;
    box.scrollTop = box.scrollHeight;
  }

  function clearMini(id) { $(id).textContent = ""; }

  /* ---------- Quick Translate tool ---------- */

  function renderQuickLanguages() {
    populatePicker("quickLang", window.AIT_TARGET_LANGUAGES.map(l => ({ value: l.code, label: l.name })), null);
  }

  async function quickTranslate() {
    try {
      const license = window.AIT_License.state();
      if (!license.ok) { $("quickOut").value = license.message; switchTab("tabSettings"); renderLicenseStatus(); return; }
      const text = ($("quickIn").value || "").trim();
      if (!text) throw new Error("Enter some text to translate.");
      const code = pickerValue("quickLang");
      if (!code) throw new Error("Pick a target language first.");
      const language = window.AIT_getLanguage(code);
      const settings = collectUiSettings(true);
      const keyless = ["mock", "ollama"];
      if (settings.localOnly && keyless.indexOf(settings.provider) === -1) throw new Error(`Private mode is on: "${settings.provider}" is a cloud provider. Switch to Ollama or turn Private mode off in Settings.`);
      if (keyless.indexOf(settings.provider) === -1 && !settings.apiKey) throw new Error(`Missing API key for ${providerLabel(settings.provider)} — add it in Settings.`);

      setDisabled("quickRun", true);
      $("quickOut").value = "Translating...";
      const prot = settings.protectPlaceholders
        ? window.AIT_Protectors.protectText(text)
        : { text, placeholders: [] };
      const unit = { id: "q-0001", originalText: text, textForTranslation: text, preparedText: prot.text, placeholders: prot.placeholders, runs: [], mode: "plain" };
      const map = await window.AIT_Providers.translateBatch(settings.provider, Object.assign({}, settings, {
        targetLanguage: language,
        units: [unit],
        glossary: window.AIT_Glossary.filterGlossaryForText(settings.glossary, text)
      }));
      $("quickOut").value = window.AIT_Protectors.restoreText(map[unit.id] || "", prot.placeholders);
    } catch (err) {
      $("quickOut").value = `ERROR: ${err.message || err}`;
    } finally {
      setDisabled("quickRun", false);
    }
  }

  async function copyQuickResult() {
    try {
      const text = $("quickOut").value || "";
      const clip = navigator.clipboard;
      if (clip && typeof clip.setContent === "function") await clip.setContent({ "text/plain": text });
      else if (clip && typeof clip.writeText === "function") await clip.writeText(text);
    } catch (err) { fail(err); }
  }

  function formatDeepLUsage(usage) {
    if (!usage) return "usage unavailable";
    const total = typeof usage.character_count === "number"
      ? usage.character_count.toLocaleString()
      : "unknown";
    const limit = typeof usage.character_limit === "number"
      ? usage.character_limit.toLocaleString()
      : "unknown";
    let apiKeyTotal = "";
    if (Array.isArray(usage.products)) {
      usage.products.forEach(product => {
        if (typeof product.api_key_character_count === "number") {
          apiKeyTotal = `; this key ${product.api_key_character_count.toLocaleString()}`;
        }
      });
    }
    return `${total} / ${limit} characters${apiKeyTotal}`;
  }

  function deepLCharacterCount(usage) {
    return usage && typeof usage.character_count === "number" ? usage.character_count : null;
  }

  async function logDeepLUsage(apiKey, label) {
    const usage = await window.AIT_Providers.getDeepLUsage(apiKey);
    log(`${label}: ${formatDeepLUsage(usage)}`);
    return usage;
  }

  function createDeepLConfirmationTracker() {
    return {
      requests: 0,
      textUnits: 0,
      billedCharacters: 0,
      requestBytes: 0,
      elapsedMs: 0,
      sawBilledCharacters: false,
      accept(info) {
        this.requests += 1;
        this.textUnits += info && typeof info.textUnits === "number" ? info.textUnits : 0;
        this.requestBytes += info && typeof info.requestBytes === "number" ? info.requestBytes : 0;
        this.elapsedMs += info && typeof info.elapsedMs === "number" ? info.elapsedMs : 0;
        if (info && typeof info.billedCharacters === "number") {
          this.sawBilledCharacters = true;
          this.billedCharacters += info.billedCharacters;
        }
      }
    };
  }

  function activateDeepLForDocumentTranslation() {
    currentProvider = "deepl";
    setPicker("provider", "deepl");
    hydrateModelList("prefer_quality_optimized");
    if ($("localOnly").checked) {
      $("localOnly").checked = false;
      log("Private mode turned off because DeepL is a cloud provider.");
    }
  }

  async function testDeepLKey() {
    try {
      const apiKey = ($("apiKey").value || "").trim() || sessionApiKey;
      if (!apiKey) throw new Error("Paste your DeepL API key first.");
      setDisabled("testDeepL", true);
      log(`DeepL key check starting (${BUILD_ID})...`);
      await logDeepLUsage(apiKey, "DeepL usage check");
      activateDeepLForDocumentTranslation();
      sessionApiKey = apiKey;
      const result = await window.AIT_Storage.saveApiKey("deepl", apiKey, $("rememberKey").checked);
      renderSecureHint(result);
      await saveSettings();
      log("DeepL key authenticated. No translation characters were spent by this button; only the document Translate button will call /v2/translate.");
    } catch (err) {
      fail(err);
    } finally {
      setDisabled("testDeepL", false);
    }
  }

  /* ---------- Preflight tool ---------- */

  function runPreflight() {
    try {
      const dom = window.AIT_InDesignDom;
      const doc = dom.getActiveDocument();
      clearMini("preflightLog");
      const p = m => miniLog("preflightLog", m);
      p(`Document: ${doc.name || "(untitled)"}`);

      const extraction = dom.extractUnits("document", { protectPlaceholders: false, skipLocked: false });
      const chars = extraction.units.reduce((s, u) => s + String(u.originalText || "").length, 0);
      const words = extraction.units.reduce((s, u) => s + String(u.originalText || "").trim().split(/\s+/).filter(Boolean).length, 0);
      p(`Text blocks: ${extraction.units.length}   Words: ${words.toLocaleString()}   Characters: ${chars.toLocaleString()}`);

      const overset = dom.countOversetStories(doc);
      p(overset.count ? `⚠ Overset BEFORE translation: ${overset.count} story/frame(s) — fix these first or expect tighter fits.` : "Overset frames: none ✓");

      const lockedLayers = dom.listLockedLayers(doc);
      p(lockedLayers.length ? `⚠ Locked layers (${lockedLayers.length}): ${lockedLayers.join(", ")}` : "Locked layers: none ✓");

      const fonts = dom.listFonts(doc);
      const problem = fonts.filter(f => f.status === "missing" || f.status === "substituted");
      if (problem.length) p(`⚠ Fonts not installed (${problem.length}): ${problem.slice(0, 6).map(f => f.name).join(", ")}${problem.length > 6 ? "..." : ""}`);
      else p(`Fonts used: ${fonts.length} ✓`);
      p("Tip: for CJK / Arabic / Hebrew targets, confirm your fonts cover those scripts.");

      const langs = Math.max(1, selectedLanguageCodes.size);
      const tokens = Math.ceil(chars / 3.6) * 2 * langs;
      p(`Estimated translation volume for ${langs} language(s): ${chars.toLocaleString()} source characters per language. DeepL bills source characters; LLM providers bill roughly ~${tokens.toLocaleString()} tokens in+out.`);
      p("Preflight complete.");
    } catch (err) {
      clearMini("preflightLog");
      miniLog("preflightLog", `ERROR: ${err.message || err}`);
    }
  }

  /* ---------- Batch PDF tool ---------- */

  async function choosePdfFolder() {
    try {
      pdfFolder = await window.AIT_InDesignDom.chooseOutputFolder();
      $("pdfFolderName").textContent = pdfFolder.name || "Selected folder";
    } catch (err) { miniLog("pdfLog", `ERROR: ${err.message || err}`); }
  }

  async function runBatchPdf() {
    if (running) { miniLog("pdfLog", "A translation batch is running — try again when it finishes."); return; }
    const dom = window.AIT_InDesignDom;
    try {
      setDisabled("pdfRun", true);
      clearMini("pdfLog");
      let folder = pdfFolder || outputFolder;
      if (!folder) {
        folder = await dom.chooseOutputFolder();
        pdfFolder = folder;
        $("pdfFolderName").textContent = folder.name || "Selected folder";
      }
      const sep = String(folder.nativePath || "").indexOf("\\") !== -1 ? "\\" : "/";

      // Format switch and its per-format options come from batch-export.js.
      const format = ($("exportFormat") && $("exportFormat").value) || "pdf";
      const exportOpts = window.__ffExportOpts ? window.__ffExportOpts(format) : {};
      const ext = format === "png" ? "png" : format === "jpeg" ? "jpg" : "pdf";
      const label = format === "png" ? "PNG" : format === "jpeg" ? "JPEG" : "PDF";

      // The image path returns one entry per page/spread written; PDF returns a single path.
      const writtenCount = (result) => (Array.isArray(result) ? result.length : 1);

      async function exportOne(doc, base) {
        const filePath = `${folder.nativePath}${sep}${base}.${ext}`;
        return format === "pdf"
          ? dom.exportDocumentToPdf(doc, filePath, exportOpts)
          : dom.exportDocumentToImage(doc, filePath, format, exportOpts);
      }

      const mode = ($("pdfSource") && $("pdfSource").value) || "open";

      if (mode === "files") {
        const uxp = require("uxp");
        const picked = await uxp.storage.localFileSystem.getFileForOpening({ types: ["indd", "idml"], allowMultiple: true });
        const files = Array.isArray(picked) ? picked : (picked ? [picked] : []);
        if (!files.length) { miniLog("pdfLog", "No files chosen."); return; }
        for (const file of files) {
          miniLog("pdfLog", `Opening ${file.name}...`);
          const doc = await dom.openDocumentFile(file);
          try {
            const base = dom.safeFilePart(dom.getDocumentBaseName(doc));
            const count = writtenCount(await exportOne(doc, base));
            miniLog("pdfLog", count > 1 ? `✓ ${base} — ${count} ${ext} files` : `✓ ${base}.${ext}`);
          } finally {
            try { await dom.closeDocument(doc, false); } catch (_) {}
          }
        }
      } else {
        const docs = dom.getOpenDocuments();
        if (!docs.length) throw new Error("No documents are open.");
        for (const doc of docs) {
          const base = dom.safeFilePart(dom.getDocumentBaseName(doc));
          miniLog("pdfLog", `Exporting ${base} (${label})...`);
          const count = writtenCount(await exportOne(doc, base));
          miniLog("pdfLog", count > 1 ? `✓ ${base} — ${count} ${ext} files` : `✓ ${base}.${ext}`);
        }
      }
      miniLog("pdfLog", "Done.");
    } catch (err) {
      miniLog("pdfLog", `ERROR: ${err.message || err}`);
    } finally {
      setDisabled("pdfRun", false);
    }
  }

  /* ---------- Overset fixer tool ---------- */

  function numField(id, def, min, max) {
    const raw = ($(id) && $(id).value || "").replace(",", ".");
    const v = parseFloat(raw);
    const n = isFinite(v) ? v : def;
    return Math.min(max, Math.max(min, n));
  }

  // User-defined fit limits — shared by the Fixer tab and the automatic
  // post-translation fit.
  function getFitOptions() {
    return {
      tracking: $("fitTracking").checked,
      leading: $("fitLeading").checked,
      size: $("fitSize").checked,
      trackingMax: numField("fitTrackingMax", -25, -200, 0),
      leadingPct: numField("fitLeadingPct", 5, 0, 20),
      sizeMaxPct: numField("fitSizeMaxPct", 15, 0, 50),
      sizeMinPt: numField("fitSizeMinPt", 4, 1, 24)
    };
  }

  function scanOverset() {
    try {
      const dom = window.AIT_InDesignDom;
      const result = dom.countOversetStories(dom.getActiveDocument());
      clearMini("fitLog");
      if (result.count === 0) miniLog("fitLog", "No overset text found. ✓");
      else miniLog("fitLog", `${result.count} overset stor${result.count === 1 ? "y" : "ies"}: ${result.details.slice(0, 8).join(", ")}${result.details.length > 8 ? "..." : ""}`);
    } catch (err) { clearMini("fitLog"); miniLog("fitLog", `ERROR: ${err.message || err}`); }
  }

  function fixOverset() {
    if (running) { miniLog("fitLog", "A translation batch is running — try again when it finishes."); return; }
    try {
      const dom = window.AIT_InDesignDom;
      const doc = dom.getActiveDocument();
      clearMini("fitLog");
      miniLog("fitLog", "Fixing overset text...");
      const result = dom.autoFitOverset(doc, getFitOptions());
      if (!result.adjustedStories) {
        miniLog("fitLog", "Nothing to fix — no overset stories. ✓");
      } else {
        miniLog("fitLog", `Adjusted ${result.adjustedStories} stor${result.adjustedStories === 1 ? "y" : "ies"} via ${result.stagesUsed.join(" → ")}.`);
        if (result.stillOverset > 0) miniLog("fitLog", `⚠ ${result.stillOverset} still overset — needs manual layout (or enable more adjustments above).`);
        else miniLog("fitLog", "All text now fits. ✓ Remember to save the document.");
      }
    } catch (err) { miniLog("fitLog", `ERROR: ${err.message || err}`); }
  }

  function switchTab(tabId) {
    if (!tabId) return;
    document.querySelectorAll(".tab-page").forEach(page => {
      page.classList.toggle("active", page.id === tabId);
    });
    document.querySelectorAll(".tab-icon").forEach(icon => {
      setClassState(icon, "active", icon.getAttribute("data-tab") === tabId);
    });
  }

  function resetForm() {
    if (running) return;
    selectedLanguageCodes.clear();
    $("languageSearch").value = "";
    $("context").value = "";
    glossary = [];
    $("glossaryName").textContent = "No glossary loaded";
    renderLanguages();
    setProgress(0, "Ready.");
    clearLog();
    log("Form reset. Provider, model, API key, and saved settings kept.");
  }

  /* ---------- Language pickers ---------- */

  function renderSourceLanguages() {
    const items = window.AIT_LANGUAGES
      .filter(l => l.sourceOnly || l.code === "en" || !/^en-/.test(l.code))
      .map(l => ({ value: l.code, label: l.name }));
    populatePicker("sourceLang", items, "auto");
  }

  function renderLanguages() {
    const container = $("languageGroups");
    const query = ($("languageSearch").value || "").trim().toLowerCase();
    container.innerHTML = "";

    const groups = new Map();
    for (const lang of window.AIT_TARGET_LANGUAGES) {
      if (query && !lang.name.toLowerCase().includes(query) && !lang.code.toLowerCase().includes(query)) continue;
      const region = lang.region || "Other";
      if (!groups.has(region)) groups.set(region, []);
      groups.get(region).push(lang);
    }

    const ordered = Array.from(groups.keys()).sort((a, b) => {
      const ai = window.AIT_LANGUAGE_REGION_ORDER.indexOf(a);
      const bi = window.AIT_LANGUAGE_REGION_ORDER.indexOf(b);
      if (ai === -1 && bi === -1) return a.localeCompare(b);
      if (ai === -1) return 1;
      if (bi === -1) return -1;
      return ai - bi || a.localeCompare(b);
    });

    for (const region of ordered) {
      const langs = groups.get(region).sort((a, b) => a.name.localeCompare(b.name));
      const section = document.createElement("section");
      section.className = "lang-group";

      const head = document.createElement("div");
      head.className = "lang-group-head";
      const title = document.createElement("h3");
      title.textContent = region;
      const actions = document.createElement("div");
      // Divs, not <button> — UXP forces native pill chrome on buttons.
      const addBtn = document.createElement("div");
      addBtn.className = "mini-btn";
      addBtn.textContent = "Tick all";
      addBtn.addEventListener("click", () => selectCodes(langs.map(l => l.code), true));
      const removeBtn = document.createElement("div");
      removeBtn.className = "mini-btn";
      removeBtn.textContent = "Untick";
      removeBtn.addEventListener("click", () => selectCodes(langs.map(l => l.code), false));
      actions.appendChild(addBtn);
      actions.appendChild(removeBtn);
      head.appendChild(title);
      head.appendChild(actions);
      section.appendChild(head);

      const grid = document.createElement("div");
      grid.className = "language-grid";
      for (const lang of langs) {
        // Native input, not sp-checkbox — InDesign's UXP misrenders sp-checkbox
        // (box and label stack and overlap following content).
        const wrap = document.createElement("label");
        wrap.className = "inline-check lang-check";
        const cb = document.createElement("input");
        cb.type = "checkbox";
        cb.value = lang.code;
        cb.checked = selectedLanguageCodes.has(lang.code);
        cb.addEventListener("change", () => {
          if (cb.checked) selectedLanguageCodes.add(lang.code);
          else selectedLanguageCodes.delete(lang.code);
          updateSelectedCount();
        });
        wrap.appendChild(cb);
        wrap.appendChild(document.createTextNode(`${lang.name}${lang.rtl ? " ↔" : ""}`));
        grid.appendChild(wrap);
      }
      section.appendChild(grid);
      container.appendChild(section);
    }

    updateSelectedCount();
  }

  function selectPreset(name) {
    selectedLanguageCodes = new Set(window.AIT_LANGUAGE_PRESETS[name] || []);
    renderLanguages();
  }

  function selectCodes(codes, checked) {
    for (const code of codes) {
      if (checked) selectedLanguageCodes.add(code);
      else selectedLanguageCodes.delete(code);
    }
    renderLanguages();
  }

  function clearLanguages() {
    selectedLanguageCodes.clear();
    renderLanguages();
  }

  function toggleAllLanguages(event) {
    const checked = Boolean(event && event.target && event.target.checked);
    selectedLanguageCodes = checked
      ? new Set(window.AIT_TARGET_LANGUAGES.map(lang => lang.code))
      : new Set();
    renderLanguages();
  }

  function syncToggleAllLanguages() {
    const checkbox = $("toggleAllLanguages");
    const label = $("toggleAllLanguagesLabel");
    if (!checkbox) return;
    const total = window.AIT_TARGET_LANGUAGES.length;
    const selected = getSelectedLanguages().length;
    checkbox.checked = total > 0 && selected === total;
    checkbox.indeterminate = selected > 0 && selected < total;
    checkbox.setAttribute("aria-checked", checkbox.indeterminate ? "mixed" : String(checkbox.checked));
    if (label) label.textContent = checkbox.checked ? "Uncheck all languages" : "Check all languages";
  }

  function providerLabel(provider) {
    const labels = {
      deepl: "DeepL",
      openai: "OpenAI",
      anthropic: "Anthropic",
      gemini: "Google Gemini",
      ollama: "Ollama (local)",
      mock: "Mock/offline test"
    };
    return labels[provider] || provider || "DeepL";
  }

  function getSelectedLanguages() {
    return window.AIT_TARGET_LANGUAGES.filter(lang => selectedLanguageCodes.has(lang.code));
  }

  function toggleLanguagePanel() {
    const panel = $("langPanel");
    const isOpen = panel.style.display !== "none";
    panel.style.display = isOpen ? "none" : "block";
    setClassState($("langToggle"), "open", !isOpen);
  }

  function updateSelectedCount() {
    const el = $("selectedCount");
    const names = getSelectedLanguages().map(l => l.name);
    if (!names.length) {
      el.textContent = "Select languages...";
      el.className = "lang-toggle-text placeholder";
    } else {
      el.textContent = names.length <= 3
        ? names.join(", ")
        : `${names.length} selected — ${names.slice(0, 2).join(", ")}, ...`;
      el.className = "lang-toggle-text";
    }
    syncToggleAllLanguages();
  }

  /* ---------- Models ---------- */

  function hydrateModelList(preferredValue) {
    const provider = selectedProviderValue();
    const models = (window.AIT_Providers.DEFAULT_MODELS[provider] || []).slice();
    let target = window.AIT_Providers.normalizeModel
      ? window.AIT_Providers.normalizeModel(provider, preferredValue || currentModel || pickerValue("model"))
      : (preferredValue || currentModel || pickerValue("model"));
    if (target && models.indexOf(target) === -1) {
      if (preferredValue) models.push(target); // saved custom model from an earlier session
      else target = null; // provider changed — previous model not valid here
    }
    if (!target) target = window.AIT_Providers.getDefaultModel(provider);
    currentModel = target;
    populatePicker("model", models.map(m => ({
      value: m,
      label: window.AIT_Providers.getModelLabel ? window.AIT_Providers.getModelLabel(provider, m) : m
    })), target);
  }

  /* ---------- Settings persistence ---------- */

  async function restoreSettings() {
    const settings = window.AIT_Storage.readSettings();
    currentProvider = settings.provider || "deepl";
    setPicker("provider", currentProvider);
    hydrateModelList(settings.model || null);
    setPicker("sourceLang", settings.sourceLang || "auto");
    setPicker("industry", settings.industry || "Industrial packaging");
    setPicker("qualityMode", settings.qualityMode || "layout-tight");
    setPicker("theme", settings.theme || "auto");
    $("context").value = settings.context || "";
    $("preserveCharStyles").checked = settings.preserveCharStyles === true;
    $("protectPlaceholders").checked = settings.protectPlaceholders !== false;
    $("skipLocked").checked = settings.skipLocked !== false;
    $("rtlSupport").checked = settings.rtlSupport !== false;
    $("autoFit").checked = settings.autoFit !== false;
    const fit = settings.fitOptions || {};
    $("fitTracking").checked = fit.tracking !== false;
    $("fitLeading").checked = fit.leading !== false;
    $("fitSize").checked = fit.size !== false;
    if (fit.trackingMax != null) $("fitTrackingMax").value = String(fit.trackingMax);
    if (fit.leadingPct != null) $("fitLeadingPct").value = String(fit.leadingPct);
    if (fit.sizeMaxPct != null) $("fitSizeMaxPct").value = String(fit.sizeMaxPct);
    if (fit.sizeMinPt != null) $("fitSizeMinPt").value = String(fit.sizeMinPt);
    $("exportPdf").checked = settings.exportPdf !== false;
    $("keepOpen").checked = settings.keepOpen !== false;
    $("rememberKey").checked = settings.rememberKey !== false; // remember by default
    $("localOnly").checked = settings.localOnly === true; // privacy gate off by default
    applyTheme();
    if (Array.isArray(settings.selectedLanguageCodes)) {
      selectedLanguageCodes = new Set(settings.selectedLanguageCodes);
      renderLanguages();
    }
    await restoreApiKeyForProvider();
    log(`Provider restored: ${providerLabel(currentProvider)}.`);
  }

  async function persistApiKey() {
    try {
      sessionApiKey = ($("apiKey").value || "").trim();
      const result = await window.AIT_Storage.saveApiKey(selectedProviderValue(), sessionApiKey, $("rememberKey").checked);
      renderSecureHint(result);
      if (result.remembered) log("API key saved for this machine.");
    } catch (err) { fail(err); }
  }

  async function restoreApiKeyForProvider() {
    const provider = selectedProviderValue();
    if (!$("rememberKey").checked) {
      $("apiKey").value = sessionApiKey || "";
      return;
    }
    const result = await window.AIT_Storage.loadApiKey(provider);
    $("apiKey").value = result.value || "";
    renderSecureHint(result);
  }

  function renderSecureHint(result) {
    const hint = $("secureHint");
    if (result && result.value && result.secure) hint.textContent = "API key loaded from host secure storage. Keys are never logged.";
    else if (result && result.value && result.fallback) hint.textContent = "Warning: host secure storage was unavailable; key was loaded from local plugin storage.";
    else hint.textContent = "Keys are never logged. If host secure storage is unavailable, the plugin falls back to local plugin storage and warns you.";
  }

  async function saveSettings() {
    const settings = collectUiSettings(false);
    settings.selectedLanguageCodes = Array.from(selectedLanguageCodes);
    window.AIT_Storage.writeSettings(settings);
    sessionApiKey = ($("apiKey").value || "").trim();
    const keyResult = await window.AIT_Storage.saveApiKey(settings.provider, sessionApiKey, settings.rememberKey);
    renderSecureHint(keyResult);
    log(`Settings saved. Provider: ${providerLabel(settings.provider)}.`);
  }

  /* ---------- File pickers ---------- */

  async function chooseFolder() {
    try {
      outputFolder = await window.AIT_InDesignDom.chooseOutputFolder();
      $("folderName").textContent = outputFolder.name || "Selected folder";
      log(`Output folder selected: ${outputFolder.name || "folder"}`);
    } catch (err) { fail(err); }
  }

  async function loadGlossary() {
    try {
      const uxp = require("uxp");
      const file = await uxp.storage.localFileSystem.getFileForOpening({ types: ["csv", "txt", "tsv"] });
      if (!file) return;
      const text = await file.read();
      glossary = window.AIT_Glossary.parseCsv(text);
      $("glossaryName").textContent = `${file.name} (${glossary.length} terms)`;
      log(`Glossary loaded: ${glossary.length} terms.`);
    } catch (err) { fail(err); }
  }

  /* ---------- Settings collection ---------- */

  function selectedScope() {
    const group = $("scopeGroup");
    return (group && group.value) || "document";
  }

  function collectUiSettings(includeApiKey) {
    const provider = selectedProviderValue();
    const modelValue = pickerValue("model");
    const providerModels = window.AIT_Providers.DEFAULT_MODELS[provider] || [];
    const sourceLang = pickerValue("sourceLang") || "auto";
    const source = window.AIT_getLanguage(sourceLang);
    const settings = {
      provider,
      model: window.AIT_Providers.normalizeModel
        ? window.AIT_Providers.normalizeModel(provider, providerModels.indexOf(modelValue) !== -1
          ? modelValue
          : (providerModels.indexOf(currentModel) !== -1 ? currentModel : window.AIT_Providers.getDefaultModel(provider)))
        : modelValue,
      providerLabel: providerLabel(provider),
      sourceLang,
      sourceLanguageName: source.name || sourceLang,
      industry: pickerValue("industry") || "General business",
      qualityMode: pickerValue("qualityMode") || "layout-tight",
      context: ($("context").value || "").trim(),
      preserveCharStyles: $("preserveCharStyles").checked,
      protectPlaceholders: $("protectPlaceholders").checked,
      skipLocked: $("skipLocked").checked,
      rtlSupport: $("rtlSupport").checked,
      autoFit: $("autoFit").checked,
      fitOptions: getFitOptions(),
      exportPdf: $("exportPdf").checked,
      saveReport: false, // no JSON/CSV report files
      keepOpen: $("keepOpen").checked,
      rememberKey: $("rememberKey").checked,
      localOnly: $("localOnly").checked,
      theme: pickerValue("theme") || "auto",
      scope: selectedScope(),
      glossary,
      targetLanguages: getSelectedLanguages(),
      outputFolder
      // chunkChars intentionally not set — the engine picks a size per provider
    };
    if (includeApiKey) settings.apiKey = ($("apiKey").value || "").trim() || sessionApiKey;
    return settings;
  }

  /* ---------- Actions ---------- */

  async function estimate() {
    if (running) return;
    try {
      const settings = collectUiSettings(false);
      if (!settings.targetLanguages.length) throw new Error("Select at least one target language first.");
      const estimateResult = window.AIT_BatchEngine.estimate(settings);
      log(`Estimate: ${estimateResult.units} text units, ${estimateResult.skipped} skipped, ${estimateResult.chars.toLocaleString()} chars per language, ${estimateResult.estimatedChunksPerLanguage} chunks per language, approx ${estimateResult.totalApproxTokens.toLocaleString()} total tokens across ${settings.targetLanguages.length} language(s).`);
    } catch (err) { fail(err); }
  }

  async function translateBatch() {
    if (running) return;
    const license = window.AIT_License.state();
    if (!license.ok) {
      log(license.message);
      switchTab("tabSettings");
      renderLicenseStatus();
      return;
    }
    if (license.mode === "trial") log(license.message);
    running = true;
    cancelling = false;
    setBusy(true);
    setProgress(0, "Starting...");

    try {
      const settings = collectUiSettings(true);
      if (!settings.targetLanguages.length) throw new Error("Select at least one target language.");
      if (settings.localOnly && settings.provider !== "ollama" && settings.provider !== "mock") {
        throw new Error(`Private mode is on: "${settings.provider}" is a cloud provider. Switch to Ollama (on-device) in Settings, or turn Private mode off.`);
      }
      if (!settings.outputFolder) {
        outputFolder = await window.AIT_InDesignDom.chooseOutputFolder();
        settings.outputFolder = outputFolder;
        $("folderName").textContent = outputFolder.name || "Selected folder";
      }
      const keylessProviders = ["mock", "ollama"]; // local providers need no API key
      if (keylessProviders.indexOf(settings.provider) === -1 && !settings.apiKey) throw new Error(`Missing API key for ${providerLabel(settings.provider)}. Open Settings and add it.`);
      await saveSettings();
      clearLog();
      log(`Provider: ${providerLabel(settings.provider)}   Model: ${settings.model}`);
      // DeepL is just another provider: send text, get the translation, build
      // the file. We attach a tracker only to print an informational summary —
      // it never blocks or aborts a run that DeepL actually translated.
      if (settings.provider === "deepl") {
        settings.deepLMode = "document-api-v3";
        log("DeepL Document API V3 active: the exported IDML file will be uploaded to DeepL, translated, downloaded, and opened in InDesign.");
      }
      await window.AIT_BatchEngine.runBatch(settings, {
        log,
        progress: setProgress,
        cancelled: () => cancelling
      });
    } catch (err) { fail(err); }
    finally {
      setBusy(false);
      running = false;
    }
  }

  function setBusy(value) {
    setDisabled("translate", value);
    setDisabled("estimate", value);
    setDisabled("resetForm", value);
    setDisabled("cancel", !value);
  }

  function setProgress(value, status) {
    const pct = Math.max(0, Math.min(100, Math.round(value * 100)));
    $("bar").style.width = `${pct}%`;
    $("percentText").textContent = `${pct}%`;
    if (status) $("statusText").textContent = status;
  }

  function clearLog() { $("log").textContent = ""; }

  function log(message) {
    const box = $("log");
    const prefix = box.textContent ? "\n" : "";
    box.textContent += `${prefix}${message}`;
    box.scrollTop = box.scrollHeight;
  }

  function fail(err) {
    const msg = err && err.message ? err.message : String(err);
    log(`ERROR: ${msg}`);
    setProgress(0, "Error");
    console.error(err);
  }
})();
