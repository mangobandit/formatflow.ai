# FormatFlow Translate — Product Overview

*The InDesign plugin that translates a whole document into 48 languages in one batch — layout-safe, on your own AI key, for €12/month.*

---

## The one-liner

Translate an entire InDesign document into French, German, Japanese, Arabic — and 44 more — in a single batch, without breaking the layout and without sending your files to anyone's server.

## Who it's for

Studios, freelancers, and in-house design teams who produce the same document in many languages — packaging, manuals, marketing decks, catalogues, signage — and currently lose hours copy-pasting translations back into InDesign and rebuilding the layout by hand.

---

## How it works (the safe-by-design workflow)

1. **You pick languages and a provider.** Tick any of 48 target languages (with regional presets — Core 20, Europe, Asia, Middle East, Africa, Americas). Choose your AI engine: OpenAI, Anthropic Claude, Google Gemini, DeepL, or a 100% local Ollama model.
2. **The plugin exports your document to IDML** — Adobe's open interchange format — and translates the text *inside the XML*, not by retyping it into frames.
3. **Every block is verified.** Each paragraph and table cell is checked after translation; anything incomplete is automatically re-requested, so you don't get half-translated frames.
4. **A fresh, press-ready `.indd` is built per language.** Your original file is never touched. Optionally a print **PDF per language** is produced too.
5. **Overset text is auto-fitted** — least-invasive first (tracking → leading → size), within limits you set — and a standalone **Overset Fixer** can clean up any document.

The result: drop in one English document, get back ten clean, on-brand, ready-to-output language versions.

---

## Key features

- **48 languages, true batch** — one click, one output file set per language.
- **Layout preserved by construction** — frames, paragraph/character styles, tables, and master pages stay intact because translation happens in the IDML, not by hand.
- **Bring your own key (BYOK)** — OpenAI, Anthropic, Google Gemini, DeepL, or local Ollama. Your text goes **directly** from your machine to the provider you chose, on your key. We run no server in that path. With Ollama, nothing leaves your computer at all.
- **Verification & auto-repair** — every text block confirmed; incomplete translations re-requested automatically.
- **Multi-format batch export** — PDF, **PNG, and JPEG**, each with the same options as InDesign's native export dialog (scope, pages/spreads, quality, resolution, colour space, bleed, overprint).
- **Overset auto-fit + standalone fixer** — keep translated text inside its frames, on your terms.
- **Glossary enforcement** — load a CSV of source/target terms; brand names, product names, and URLs are protected.
- **Right-to-left & complex scripts** — Arabic, Hebrew, Persian, plus full CJK support.
- **Private by design** — no analytics, no telemetry, no document content ever reaching us.

---

## Pricing

**€12 / month. Bring your own AI key.**

- A **14-day free trial**, full-featured, starts automatically — no card, no key required.
- After the trial, a €12/month subscription keeps it running. The subscription covers **the plugin**; the AI itself is billed by your own provider (and Gemini/Ollama have free options, so many users pay only the €12).
- Cancel anytime; you keep access to the end of the paid period.
- Billing, invoices, and VAT are handled by our payment provider (Lemon Squeezy) as merchant of record.

> Why BYOK + a flat low price? You're never marked up on AI usage, your content never passes through us, and you only pay for the tool that saves you the hours — not a per-word tax on every translation.

---

## Always improving — monthly updates

FormatFlow Translate is actively developed. We ship **regular updates — we aim for a meaningful improvement every month** — driven by what users actually ask for. Recent additions include multi-format batch export (PNG/JPEG) and the standalone overset fixer.

**Your subscription includes every update during your active period.** (Specific features and timing are roadmap-driven and may change — see "Request a feature" below to influence what ships next.)

---

## Request a feature / vote on the roadmap

We build what subscribers ask for. Tell us what you need next:

- **In-app:** About tab → *Request a feature*
- **Web:** the *Roadmap & Requests* page on formatflow.ai
- **Email:** [matt@bear-cg.com](mailto:matt@bear-cg.com)

Popular requests on the radar: selection-only translation, per-language model overrides, translation memory across document versions, and direct `.idml` input.

---

## Not affiliated with Adobe

FormatFlow Translate is an independent third-party plugin. Adobe, InDesign, and Creative Cloud are trademarks of Adobe Inc. OpenAI, Anthropic, Google Gemini, DeepL, and Ollama are trademarks of their respective owners. We are not endorsed by or affiliated with any of them; all translation is produced by the AI provider you choose and credential.
