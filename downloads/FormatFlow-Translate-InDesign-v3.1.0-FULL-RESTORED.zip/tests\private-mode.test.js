// Verifies the Private-mode (localOnly) gate in providers.js: every translation
// path funnels through AIT_Providers.translateBatch, so blocking cloud providers
// there guarantees "nothing leaves the machine" when Private mode is on.
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");
let networkCalled = false;
const sandbox = {
  window: {},
  fetch: async () => { networkCalled = true; throw new Error("NETWORK CALLED"); },
  setTimeout, clearTimeout, Math, JSON, String, Number, Array, Object, Date, Promise, console, RegExp
};
vm.createContext(sandbox);
sandbox.window.AIT_Glossary = { toPromptLines: () => "" };
sandbox.window.AIT_Protectors = { stripFences: (s) => s };
vm.runInContext(fs.readFileSync(path.join(root, "src/providers.js"), "utf8"), sandbox);
const P = sandbox.window.AIT_Providers;

const input = (extra) => Object.assign({
  units: [{ id: "u1", preparedText: "Hello", originalText: "Hello" }],
  targetLanguage: { name: "French", code: "fr" },
  apiKey: "sk-test"
}, extra);

(async () => {
  let pass = 0, fail = 0;
  const ok = (c, m) => { if (c) pass++; else { fail++; console.log("  FAIL:", m); } };

  // Private mode + each cloud provider => MUST throw, MUST NOT touch network
  for (const prov of ["deepl", "openai", "anthropic", "gemini"]) {
    networkCalled = false;
    try { await P.translateBatch(prov, input({ localOnly: true })); ok(false, prov + "+private should throw"); }
    catch (e) { ok(/Private mode/i.test(e.message) && !networkCalled, prov + "+private blocked, zero network"); }
  }

  // Private mode + local (mock) => allowed, no network
  networkCalled = false;
  try { const r = await P.translateBatch("mock", input({ localOnly: true })); ok(r && r.u1 && !networkCalled, "mock+private allowed, no network"); }
  catch (e) { ok(false, "mock+private should not throw: " + e.message); }

  // Private mode OFF + cloud => gate opens, reaches network stub
  networkCalled = false;
  try { await P.translateBatch("openai", input({ localOnly: false })); ok(false, "should reach network"); }
  catch (e) { ok(networkCalled === true, "private OFF: cloud reaches network (gate open)"); }

  console.log(`Private-mode gate: ${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
