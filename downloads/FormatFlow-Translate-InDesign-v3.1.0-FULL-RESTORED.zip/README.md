# FormatFlow Translate — for Adobe InDesign

IDML-safe multi-language AI document translation. https://formatflow.ai

## What it does

Translate an entire InDesign document into 48 languages in one batch. The
document is exported to IDML (InDesign's XML format), the text is translated
inside the XML with your own AI key, every block is verified, and a fresh
press-ready `.indd` (plus optional PDF) is built per language. The original
document is never edited.

## Key features

- **Multi-language batch** — tick any number of languages; regional presets included
- **Check/uncheck all** — one three-state checkbox selects or clears all 48 target languages
- **BYOK** — DeepL, OpenAI, Anthropic Claude, Google Gemini (free tier), or 100% local Ollama
- **GPT-5.6 family** — Sol for highest quality, Terra for balance, Luna for high-volume speed
- **Verified output** — stable block IDs, automatic repair of incomplete translations,
  nothing broken is ever written to disk
- **Auto-fit** — overset text resolved by tracking → leading → size, least invasive first
- **Standalone overset fixer** — scan and fix any open document with user-controlled limits
- **Quick Translate** — instant text translation in its own tab
- **Preflight** — document health check (fonts, locked layers, overset, cost estimate)
- **Batch PDF** — a print PDF per language, or batch-PDF any documents
- **Glossary** — CSV terminology enforcement; URLs/codes/placeholders protected
- **RTL + CJK** — Arabic/Hebrew/Persian direction handling; full complex-script support

## Development

```
node scripts/validate.js          # structure + syntax validation
node scripts/check-ids.js         # UI binding cross-check
npm test                          # all provider, IDML, privacy, overset, and UI contracts
node tests/idml-roundtrip.test.js # IDML engine regression test
node tests/deepl-provider.test.js # DeepL provider request/placeholder test
npm run zip                       # build distributable
```

Load `manifest.json` via Adobe UXP Developer Tools with InDesign 18.5+ running.

Version 3.1.0 restores the complete 3.0 feature set and themed tabbed UI, adds
GPT-5.6 Sol/Terra/Luna and check/uncheck-all languages, and retains the fresh
InDesign text-range fix that prevents translated paragraph starts being clipped.

## Launch

See `docs/LAUNCH.md` for the marketplace submission playbook and
`docs/site/` for the formatflow.ai website sources.

© FormatFlow. Adobe and InDesign are trademarks of Adobe Inc.
